(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-action-sheet-controller_8.entry.js",
		"common",
		2
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		3
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		4
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		5
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		6
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		0,
		"common",
		7
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		0,
		"common",
		8
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		9
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		10
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		11
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		12
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		13
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		14
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		15
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		16
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		17
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		18
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		19
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		20
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		21
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		22
	],
	"./ion-col_3.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		23
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		24
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		25
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		26
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		27
	],
	"./ion-img.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-img.entry.js",
		28
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		29
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		30
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		31
	],
	"./ion-input-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		32
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		33
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		34
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		35
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		36
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		37
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		38
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-menu_4-ios.entry.js",
		"common",
		39
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-menu_4-md.entry.js",
		"common",
		40
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		0,
		"common",
		41
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		0,
		"common",
		42
	],
	"./ion-nav_5.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-nav_5.entry.js",
		0,
		"common",
		43
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		0,
		"common",
		44
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		0,
		"common",
		45
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		46
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		47
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		48
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		49
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		50
	],
	"./ion-range-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		51
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		52
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		53
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		54
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		55
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		56
	],
	"./ion-route_4.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		57
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		58
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		59
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		60
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		61
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		62
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		63
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		64
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		65
	],
	"./ion-spinner.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		66
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		67
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		68
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		69
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		70
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		1
	],
	"./ion-text.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		71
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		72
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		73
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		74
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		75
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		76
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		77
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		78
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/_@ionic_core@4.11.13@@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n    <ion-split-pane when=\"lg\">\n        <ion-menu [hidden]=\"showMenu != true\" class=\"menu\" max-edge-start=\"120\" style=\"--width: 200px;\">\n            <ion-header>\n                <ion-toolbar>\n                    <ion-title>鹰眼</ion-title>\n                </ion-toolbar>\n            </ion-header>\n            <ion-content>\n                <ion-list>\n                     <ion-menu-toggle menu=\"\" auto-hide=\"false\" *ngFor=\"let p of appPages\">\n                        <!--爬坑 menu='' 导致初始化的时候点不动菜单按钮 并且router-outlet上多有一个menu-content-open的类-->\n                        <div\n                            class=\"parent-menu pos-r\"\n                            [routerLink]=\"p.notModify ? p.url : 'dashboard/' + p.url\"\n                            (click)=\"choice(p)\"\n                            *ngIf=\"p.type == 'link'\"\n                            [ngClass]=\"!p.active ? 'border-bottom' : ''\"\n                        >\n                            <div\n                                class=\"item-active-bar pos-a\"\n                                [ngClass]=\"currentParentItem.url == p.url ? 'active' : ''\"\n                            ></div>\n                            <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n                            <span>{{ p.title }}</span>\n                        </div>\n\n                        <div\n                            class=\"parent-menu\"\n                            (click)=\"menuBtn(p)\"\n                            *ngIf=\"p.type == 'btn'\"\n                            [ngClass]=\"!p.active ? 'border-bottom' : ''\"\n                        >\n                            <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n                            <span>{{ p.title }}</span>\n                        </div>\n\n                        <ul class=\"son-menu\" *ngIf=\"p.active\">\n                            <ion-item\n                                *ngFor=\"let item of p.children\"\n                                (click)=\"menuBtn(item)\"\n                                [ngClass]=\"currentSonItem.url == item.url ? 'son-active' : ''\"\n                            >\n                                <ion-icon slot=\"start\" [name]=\"item.icon\"></ion-icon>\n                                <ion-label>\n                                    {{ item.title }}\n                                </ion-label>\n                            </ion-item>\n                        </ul>\n                    </ion-menu-toggle>\n                </ion-list>\n            </ion-content>\n        </ion-menu>\n        <ion-router-outlet main></ion-router-outlet>\n    </ion-split-pane>\n    <app-loadding *ngIf=\"loading\"></app-loadding>\n</ion-app>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/commit-reply/commit-reply.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/commit-reply/commit-reply.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div #screen id=\"screen\">\n    <ng-template #commentTemplateRef let-comment=\"comment\">\n        <!-- {{comment.user.name}} -->\n        <nz-comment\n            (click)=\"onReply.emit(true)\"\n            [nzAuthor]=\"(comment.user && comment.user.name) || '未知'\"\n            [nzDatetime]=\"(comment.created_at | date: 'yyyy-MM-dd HH:mm:ss') || '几天前'\"\n        >\n\n            <nz-avatar nz-comment-avatar nzIcon=\"user\" [nzSrc]=\"'https://oa.xdrlgroup.com/'\"></nz-avatar>\n\n            <nz-comment-action>\n                <span (click)=\"reply(comment); onReply.emit(true)\">回复</span>\n                <app-editor\n                    *ngIf=\"currentComment.id === comment.id && commitCtrl.Index === index && !pushComplete\"\n                    (onData)=\"editorDataComplete($event, comment.id)\"\n                ></app-editor>\n            </nz-comment-action>\n\n            <ng-container>\n                <ng-template ngFor let-child [ngForOf]=\"comment.son\">\n                    <ng-template [ngTemplateOutlet]=\"commentTemplateRef\" [ngTemplateOutletContext]=\"{ comment: child }\">\n                    </ng-template>\n                </ng-template>\n            </ng-container>\n\n            <nz-comment-content>\n                <div [innerHtml]=\"comment.contents\" imgGallery></div>\n            </nz-comment-content>\n        </nz-comment>\n    </ng-template>\n    <ng-template [ngTemplateOutlet]=\"commentTemplateRef\" [ngTemplateOutletContext]=\"{ comment: _data }\"> </ng-template>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/confirmed-inspect/confirmed-inspect.component.html":
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/confirmed-inspect/confirmed-inspect.component.html ***!
  \**************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <div class=\"clearfix close-box\">\n        <button style=\"float: right;\" nz-button nzSize=\"small\" (click)=\"effectCtrl.modalCtrl.dismiss()\" class=\"nz-danger f-r\">\n            关闭\n        </button> \n    </div>\n\n    <div class=\"swiper-container\" [swiper]=\"swiperConfig\" *ngIf=\"group && group.length != 0\">\n        <div class=\"swiper-wrapper\">\n            <div class=\"swiper-slide\">\n                <table\n                    id=\"table1\"\n                    style=\"table-layout: fixed;\"\n                    class=\"table table-striped table-condensed table-hover table-condensed table-text-no-break\"\n                >\n                    <thead>\n                        <tr>\n                            <td class=\"w100\">验货人</td>\n                            <td class=\"w120\">流水号</td>\n                            <td class=\"w100\">最早可验货时间</td>\n                            <td class=\"w180\" Chipboard>工厂名称</td>\n                            <td class=\"w200\">工厂地址</td>\n                            <td class=\"w90\">验货SKU数</td>\n                            <td class=\"w200\">计划验货时间</td>\n                            <td class=\"w150\">货号</td>\n                            <td class=\"w200\">货号备注</td>\n                        </tr>\n                    </thead>\n                    <tbody>\n                        <tr *ngFor=\"let item of group; let i = index\">\n                            <td class=\"w100 pos-r chip-text\" Chipboard>\n                                {{ item.user.join(',') }}\n                            </td>\n\n                            <td class=\"w120\">{{ item.inspection_group_no }}</td>\n\n                            <td colspan=\"7\" style=\"width: 1020px !important;\">\n                                <table class=\"table2\" style=\"table-layout: fixed; width: 1220px;\">\n                                    <tbody>\n                                        <tr\n                                            *ngFor=\"let sItem of item.apply_inspections\"\n                                            (mouseenter)=\"currentHoverItem = sItem\"\n                                            (mouseleave)=\"currentHoverItem = null\"\n                                        >\n                                            <td class=\"w100 pos-r\">\n                                                {{\n                                                    sItem.inspection_date\n                                                        ? (sItem.inspection_date | date: 'yyyy-MM-dd')\n                                                        : ''\n                                                }}\n                                            </td>\n                                            <td\n                                                class=\"pos-r w180\"\n                                                title=\"{{ sItem.factory_name }}\"\n                                                style=\"overflow: visible !important;\"\n                                            >\n                                                {{\n                                                    sItem.factory_name.length > 12\n                                                        ? sItem.factory_name.substring(0, 12) + '…'\n                                                        : sItem.factory_name\n                                                }}\n                                            </td>\n\n                                            <td class=\"w200 pos-r\">\n                                                {{ sItem.factory_address }}\n                                            </td>\n\n                                            <td class=\"chip-text w90 pos-r\" Chipboard>{{ sItem.sku_count }}</td>\n                                            <td class=\"w200 pos-r\">\n                                                <div\n                                                    class=\"probable-date-div pos-a chip-text\"\n                                                    Chipboard\n                                                    [ngStyle]=\"{ 'line-height': 36 * sItem.sku_group.length + 'px' }\"\n                                                >\n                                                    {{\n                                                        (sItem.date\n                                                            ? (sItem.date.probable_inspection_date_start\n                                                              | date: 'yyyy-MM-dd'\n                                                              | filterText)\n                                                            : '') +\n                                                            ' - ' +\n                                                            (sItem.date\n                                                                ? (sItem.date.probable_inspection_date_end\n                                                                  | date: 'yyyy-MM-dd'\n                                                                  | filterText)\n                                                                : '')\n                                                    }}\n                                                </div>\n                                            </td>\n\n                                            <td colspan=\"2\" style=\"width: 350px !important;\">\n                                                <table class=\"three-table\">\n                                                    <tbody>\n                                                        <tr *ngFor=\"let tItem of sItem.sku_group\">\n                                                            <td class=\"w150\">{{ tItem.sku_k }}</td>\n                                                            <td class=\"w200\">{{ tItem.g_item }}</td>\n                                                        </tr>\n                                                    </tbody>\n                                                </table>\n                                            </td>\n                                        </tr>\n                                    </tbody>\n                                </table>\n                            </td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n        </div>\n        <div class=\"swiper-scrollbar\"></div>\n    </div>\n\n    <div class=\"bot-box mt-10\">\n        <button nz-button nzSize=\"small\" class=\"f-r\" (click)=\"enterReceiving()\">确认</button>\n    </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/confirmed-popupbox/confirmed-popupbox.component.html":
/*!****************************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/confirmed-popupbox/confirmed-popupbox.component.html ***!
  \****************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"root\">\n    <ion-list class=\"f-l\">\n        <ion-item>\n            <ion-label>申请人：</ion-label>\n            <ion-text>{{ contract.apply_name }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>跟单人：</ion-label>\n            <ion-text>{{ contract.buyer_user }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>采购人：</ion-label>\n            <ion-text>{{ contract.schedule_name && contract.schedule_name.user.name }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>合同号：</ion-label>\n            <ion-text>{{ contract.contract_no }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>流水号：</ion-label>\n            <ion-text>{{ contract.apply_inspection_no }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>工厂名称：</ion-label>\n            <ion-text>{{ contract.factory_name }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>工厂地址：</ion-label>\n            <ion-text>{{ contract.factory_address }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>合同SKU数：</ion-label>\n            <ion-text>{{ contract.total_quantity }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>验货SKU数：</ion-label>\n            <ion-text>{{ contract.quantity }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>新品SKU数：</ion-label>\n            <ion-text>{{ contract.new_quantity }}</ion-text>\n        </ion-item>\n    </ion-list>\n\n    <ion-list class=\"f-l\">\n        <ion-item>\n            <ion-label>是否是新工厂：</ion-label>\n            <ion-text>{{ contract.is_new_factory && contract.is_new_factory == 1 ? '是' : '否' }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>申请时间：</ion-label>\n            <ion-text>{{ contract.created_at | date: 'yyyy-MM-dd' }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>最早可验货时间：</ion-label>\n            <ion-text>{{ contract.inspection_date | date: 'yyyy-MM-dd' }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>预计装柜时间：</ion-label>\n            <ion-text>{{ contract.estimated_loading_time | date: 'yyyy-MM-dd' }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>备注：</ion-label>\n            <ion-text>{{ contract.contract_desc }}</ion-text>\n        </ion-item>\n    </ion-list>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/custom-popup/custom-popup.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/custom-popup/custom-popup.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"pos-r\">\n    <div class=\"clearfix close-box\">\n        <div class=\"f-l\">\n            <h3 class=\"text-c color-666 mr-20\" *ngIf=\"showType == 'list'\">SKU列表</h3>\n            <h6 class=\"text-c color-666 mr-20\" *ngIf=\"showType == 'list'\">\n                {{ _contract.factory_address }}\n            </h6>\n            <p class=\"text-c color-666 mr-20\" *ngIf=\"showType == 'input'\">合同号：{{ _contract._contract_no }}</p>\n            <p class=\"text-c color-666 mr-20\" *ngIf=\"showType == 'input'\">工厂名称：{{ _contract.manufacturer }}</p>\n            <p class=\"text-c color-666 mr-20\" *ngIf=\"showType == 'input'\">\n                工厂地址：{{ _contract.manufacturer_address }}\n            </p>\n        </div>\n\n        <button\n            nz-button\n            style=\"float: right; margin-top: 15px;\"\n            (click)=\"enter('cancel')\"\n            nzSize=\"small\"\n            nzType=\"primary\"\n            class=\"f-r nz-danger\"\n            nzDanger\n        >\n            关闭\n        </button>\n    </div>\n    <div class=\"container pd-0\">\n        <div class=\"info\"></div>\n        <div class=\"box pos-r\" [ngClass]=\"showType == 'input' ? 'has-mb' : ''\" (scroll)=\"onscroll($event)\">\n            <nz-table\n                #virtualTable\n                [nzShowPagination]=\"false\"\n                [nzFrontPagination]=\"false\"\n                nzVirtualScroll\n                [nzScroll]=\"{\n                    x: showType == 'input' ? '2260px' : showBtnGroup ? '1800px' : '1600px',\n                    y: '500px'\n                }\"\n                [nzData]=\"data.data.content\"\n                [nzSize]=\"'small'\"\n            >\n                <thead>\n                    <tr>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"50px\" nzLeft=\"0px\">序号</th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"60px\" nzLeft=\"50px\">\n                            缩略图\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"90px\" nzLeft=\"110px\">\n                            SKU\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"150px\" nzLeft=\"200px\">\n                            中文名称\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"80px\" *ngIf=\"showType == 'input'\">\n                            合同数量\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"80px\" *ngIf=\"showType == 'input'\">\n                            剩余数量\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '50px' : '100px'\">\n                            验货数量\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '50px' : '100px'\">\n                            抽检数量\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '50px' : '100px'\">\n                            {{ showType == 'list' ? '仓库' : '仓储地' }}\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"180px\" *ngIf=\"showType == 'list'\">\n                            备注\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"100px\" *ngIf=\"showType == 'input'\">\n                            分组\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"250px\" *ngIf=\"showType == 'input'\">\n                            验货产品状态\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '80px' : '100px'\">logo情况</th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '90px' : '120px'\">\n                            是否需要摔箱\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '80px' : '120px'\">有无打包带</th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '100px' : '130px'\">\n                            是否需要当场寄样\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '100px' : '150px'\">\n                            是否需要带回说明书\n                            <span class=\"important\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" [nzWidth]=\"showType == 'list' ? '70px' : '100px'\">\n                            新品/返单\n\n                            <span class=\"important\" *ngIf=\"showType == 'input'\">*</span>\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"50px\" *ngIf=\"showType == 'list'\">\n                            箱率\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"50px\" *ngIf=\"showType == 'list'\">\n                            箱数\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"100px\">货物照片</th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"280px\" *ngIf=\"showType == 'input'\">\n                            备注\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"200px\" *ngIf=\"showType == 'list'\">\n                            完成情况\n                        </th>\n                        <th [nzAlign]=\"'center'\" nzWidth=\"200px\" *ngIf=\"showBtnGroup\">\n                            操作\n                        </th>\n                    </tr>\n                </thead>\n                <tbody>\n                    <ng-template nz-virtual-scroll let-data let-index=\"index\">\n                        <tr>\n                            <td [nzAlign]=\"'center'\" nzLeft=\"0px\">\n                                {{ data.index + 1 }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" nzLeft=\"50px\">\n                                <img class=\"thumbnail\" [src]=\"baseData.fileUrl + data.pic\" alt=\"\" imgGallery />\n                            </td>\n                            <td [nzAlign]=\"'center'\" nzLeft=\"110px\">\n                                {{ data.sku }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" nzLeft=\"200px\">\n                                {{ data.sku_chinese_name ? data.sku_chinese_name : data.name }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'input'\">\n                                {{ data.detail_counts }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'input'\">\n                                {{ data.inspection_left_num ? data.inspection_left_num : 0 }}\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <span *ngIf=\"showType == 'list'\">{{ data.quantity }}</span>\n                                <input\n                                    nz-input\n                                    *ngIf=\"showType == 'input'\"\n                                    (blur)=\"inspectIptVer(data, 'num')\"\n                                    [(ngModel)]=\"data.num\"\n                                    type=\"number\"\n                                    (change)=\"regValid($event)\"\n                                    placeholder=\"输入数量\"\n                                />\n                            </td>\n                            <td>\n                                <span\n                                    *ngIf=\"showType == 'list'\"\n                                    class=\"chip-text\"\n                                    Chipboard\n                                    (chipboardDestroy)=\"setChipboardDestroy($event)\"\n                                    >{{ data.must_quantity ? data.must_quantity : '暂无' }}</span\n                                >\n                                <p *ngIf=\"showType == 'input' && !chipboardDestroy\" class=\"wd-he-150\">\n                                    请输入数量\n                                </p>\n                                <input\n                                    nz-input\n                                    *ngIf=\"showType == 'input' && chipboardDestroy\"\n                                    (blur)=\"inspectIptVer(data, 'must_quantity')\"\n                                    [(ngModel)]=\"data.must_quantity\"\n                                    type=\"number\"\n                                    (change)=\"regValid($event)\"\n                                    placeholder=\"请输入数量\"\n                                />\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <!-- <nz-select\n                                    [(ngModel)]=\"data.warehouse\"\n                                    nzPlaceHolder=\"请选择\"\n                                    *ngIf=\"showType == 'input'\"\n                                >\n                                    <nz-option nzValue=\"USA\" nzLabel=\"美国\" checked></nz-option>\n                                    <nz-option nzValue=\"AUE\" nzLabel=\"澳洲\"></nz-option>\n                                </nz-select> -->\n                                <span>{{ data.warehouse }}</span>\n                            </td>\n                            <td *ngIf=\"showType == 'list'\">\n                                <ng-container>\n                                    <div\n                                        [title]=\"sItem\"\n                                        class=\"text-c desc-show\"\n                                        class=\"chip-text\"\n                                        Chipboard\n                                        *ngFor=\"let sItem of data.description; let i = index\"\n                                        (chipboardDestroy)=\"setChipboardDestroy($event)\"\n                                    >\n                                        {{ i + 1 + '.' + (sItem ? sItem : '无') }}\n                                    </div>\n                                </ng-container>\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'input'\">\n                                <nz-select [(ngModel)]=\"data.group\" nzPlaceHolder=\"请选择\">\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\"></nz-option>\n                                    <nz-option nzValue=\"A\" nzLabel=\"A\"></nz-option>\n                                    <nz-option nzValue=\"B\" nzLabel=\"B\"></nz-option>\n                                    <nz-option nzValue=\"C\" nzLabel=\"C\"></nz-option>\n                                    <nz-option nzValue=\"D\" nzLabel=\"D\"></nz-option>\n                                    <nz-option nzValue=\"E\" nzLabel=\"E\"></nz-option>\n                                </nz-select>\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'input'\">\n                                <nz-select style=\"width: 240px;\" [(ngModel)]=\"data.numIsCom\" nzPlaceHolder=\"请选择\">\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\"></nz-option>\n                                    <nz-option nzValue=\"1\" nzLabel=\"产品生产未完成，包装未完成\"></nz-option>\n                                    <nz-option nzValue=\"2\" nzLabel=\"产品生产完成，包装完成30%以下\"></nz-option>\n                                    <nz-option nzValue=\"3\" nzLabel=\"产品生产完成，包装完成30%-80%\"></nz-option>\n                                    <nz-option nzValue=\"4\" nzLabel=\"产品生产完成，包装完成80%以上\"></nz-option>\n                                </nz-select>\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <nz-select\n                                    *ngIf=\"showType == 'input'\"\n                                    [(ngModel)]=\"data.logo_desc\"\n                                    class=\"w100\"\n                                    nzAllowClear\n                                    nzPlaceHolder=\"选择logo\"\n                                >\n                                    <nz-option nzValue=\"JAXPETY\" nzLabel=\"JAXPETY\"></nz-option>\n                                    <nz-option nzValue=\"TOBBI\" nzLabel=\"TOBBI\"></nz-option>\n                                    <nz-option nzValue=\"SANDINRAYLI\" nzLabel=\"SANDINRAYLI\"></nz-option>\n                                    <nz-option nzValue=\"JAXSUNNY\" nzLabel=\"JAXSUNNY\"></nz-option>\n                                    <nz-option nzValue=\"COZIWOW\" nzLabel=\"COZIWOW\"></nz-option>\n                                    <nz-option nzValue=\"授权车\" nzLabel=\"授权车\"></nz-option>\n                                </nz-select>\n                                <p *ngIf=\"showType == 'list'\">\n                                    {{ data.logo_desc ? data.logo_desc : '暂无' }}\n                                </p>\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <nz-select\n                                    class=\"select-text-c\"\n                                    [(ngModel)]=\"data.is_need_drop_test\"\n                                    *ngIf=\"showType == 'input'\"\n                                    nzPlaceHolder=\"请选择\"\n                                >\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\">请选择</nz-option>\n                                    <nz-option nzValue=\"0\" nzLabel=\"否\">否</nz-option>\n                                    <nz-option nzValue=\"1\" nzLabel=\"是\">是</nz-option>\n                                </nz-select>\n                                <p *ngIf=\"showType == 'list'\">\n                                    {{ data.is_need_drop_test == 1 ? '是' : '否' }}\n                                </p>\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <nz-select\n                                    class=\"select-text-c\"\n                                    [(ngModel)]=\"data.has_strap\"\n                                    *ngIf=\"showType == 'input'\"\n                                    nzPlaceHolder=\"请选择\"\n                                >\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\">请选择</nz-option>\n                                    <nz-option nzValue=\"0\" nzLabel=\"否\">否</nz-option>\n                                    <nz-option nzValue=\"1\" nzLabel=\"是\">是</nz-option>\n                                </nz-select>\n                                <p *ngIf=\"showType == 'list'\">\n                                    {{ data.has_strap == 1 ? '是' : '否' }}\n                                </p>\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <nz-select\n                                    class=\"select-text-c\"\n                                    [(ngModel)]=\"data.is_need_sample\"\n                                    *ngIf=\"showType == 'input'\"\n                                    nzPlaceHolder=\"请选择\"\n                                >\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\">请选择</nz-option>\n                                    <nz-option nzValue=\"0\" nzLabel=\"否\">否</nz-option>\n                                    <nz-option nzValue=\"1\" nzLabel=\"是\">是</nz-option>\n                                </nz-select>\n                                <p *ngIf=\"showType == 'list'\">\n                                    {{ data.is_need_sample == 1 ? '是' : '否' }}\n                                </p>\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <nz-select\n                                    class=\"select-text-c\"\n                                    [(ngModel)]=\"data.need_bring_back_instructor\"\n                                    *ngIf=\"showType == 'input'\"\n                                    nzPlaceHolder=\"请选择\"\n                                >\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\">请选择</nz-option>\n                                    <nz-option nzValue=\"0\" nzLabel=\"否\">否</nz-option>\n                                    <nz-option nzValue=\"1\" nzLabel=\"是\">是</nz-option>\n                                </nz-select>\n                                <p *ngIf=\"showType == 'list'\">\n                                    {{ data.need_bring_back_instructor == 1 ? '是' : '否' }}\n                                </p>\n                            </td>\n                            <td [nzAlign]=\"'center'\">\n                                <nz-select\n                                    class=\"select-text-c\"\n                                    *ngIf=\"showType == 'input'\"\n                                    [(ngModel)]=\"data.news_or_return_product\"\n                                    nzPlaceHolder=\"请选择\"\n                                >\n                                    <nz-option nzValue=\"\" nzLabel=\"请选择\">请选择</nz-option>\n                                    <nz-option nzValue=\"news\" nzLabel=\"新品\">新品</nz-option>\n                                    <nz-option nzValue=\"return\" nzLabel=\"返单\">返单</nz-option>\n                                </nz-select>\n\n                                <p *ngIf=\"showType == 'list'\">\n                                    {{ data.news_or_return_product == 'news' ? '新品' : '返单' }}\n                                </p>\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'list'\">\n                                {{ data.rate_container }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'list'\">\n                                {{ data.quantity }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" imgGallery class=\"clearfix uploadfile\">\n                                <div class=\"pos-r\" *ngIf=\"showType == 'input'\">\n                                    <button nz-button nzType=\"primary\" nzSize=\"small\">\n                                        选择图片\n                                    </button>\n                                    <input\n                                        class=\"pos-a file-image\"\n                                        multiple\n                                        type=\"file\"\n                                        accept=\"image/*\"\n                                        (change)=\"choice($event, data)\"\n                                    />\n                                </div>\n                                <div *ngFor=\"let sItem of data.photo; let idx = index\" class=\"f-l mt-10 load-img\">\n                                    <img\n                                        [ngClass]=\"{ 'wd-50': idx == 0, 'wd-5': idx != 0 }\"\n                                        [src]=\"showType == 'input' ? sItem : baseData.usFileUrl + sItem\"\n                                        class=\"img-responsive\"\n                                        alt=\"预览图\"\n                                    />\n                                </div>\n                            </td>\n                            <td [nzAlign]=\"'center'\" class=\"remark text-c\" *ngIf=\"showType == 'input'\">\n                                <nz-input-group>\n                                    <div class=\"desc-item mb-2\" *ngFor=\"let sItem of data.description; let j = index\">\n                                        <input\n                                            type=\"text\"\n                                            nz-input\n                                            [placeholder]=\"'请输入备注' + (j + 1)\"\n                                            [(ngModel)]=\"_descriptionAry[data.index][j]\"\n                                            [disabled]=\"data.numIsCom == 1\"\n                                        />\n                                        <button\n                                            *ngIf=\"j == data.description.length - 1\"\n                                            class=\"ml-10\"\n                                            nz-button\n                                            nzType=\"primary\"\n                                            nzSize=\"small\"\n                                            [disabled]=\"!_descriptionAry[data.index][j]\"\n                                            (click)=\"data.description.push('')\"\n                                        >\n                                            添加\n                                        </button>\n                                    </div>\n                                </nz-input-group>\n                            </td>\n                            <td [nzAlign]=\"'center'\" *ngIf=\"showType == 'list'\">\n                                {{ data.complete ? data.complete : '暂无' }}\n                            </td>\n                            <td [nzAlign]=\"'center'\" nzWidth=\"200px\" *ngIf=\"showBtnGroup\">\n                                <button \n                                    *ngIf=\"showBtnGroup && showBtnGroup['revoke'] === true\"\n                                    nz-button \n                                    nzType=\"danger\" \n                                    nzSize=\"small\" \n                                    nz-popconfirm\n                                    nzPopconfirmTitle=\"确定要撤销吗？\"\n                                    nzPopconfirmPlacement=\"bottom\"\n                                    (nzOnConfirm)=\"revoke(data,index)\"\n                                    >\n                                    撤销\n                                </button>  \n                            </td>\n                        </tr>\n                    </ng-template>\n                </tbody>\n            </nz-table>\n        </div>\n    </div>\n    <div class=\"bot-box\" *ngIf=\"showType == 'input'\">\n        <div class=\"choice-date row pl-20\">\n            <ion-label class=\"col-sm-1 control-label\">选择验货时间:</ion-label>\n            <nz-date-picker\n                nzSize=\"small\"\n                [nzFormat]=\"'yyyy/MM/dd'\"\n                nzShowTime\n                [(ngModel)]=\"currentTime\"\n                (ngModelChange)=\"timeChange = true\"\n            ></nz-date-picker>\n\n            <ion-label class=\"col-sm-1 control-label ml-50\">预计装柜时间:</ion-label>\n            <nz-date-picker\n                nzSize=\"small\"\n                [disabled]=\"!use_estimated_loading_time\"\n                [nzFormat]=\"'yyyy/MM/dd'\"\n                nzShowTime\n                [(ngModel)]=\"estimated_loading_time\"\n            ></nz-date-picker>\n            <span *ngIf=\"!estimated_loading_time\">暂无安排选项</span>\n\n            <ion-label class=\"col-sm-1 control-label ml-50\">是否是新工厂:</ion-label>\n            <select [(ngModel)]=\"is_new_factory\">\n                <option value=\"\">请选择</option>\n                <option value=\"1\">是</option>\n                <option value=\"2\">否</option>\n            </select>\n\n            <ion-label class=\"col-sm-1 control-label ml-50\">启用装柜时间:</ion-label>\n            <ion-toggle (ionChange)=\"toggleStatus()\" [(ngModel)]=\"use_estimated_loading_time\"></ion-toggle>\n        </div>\n        <ion-button [expand]=\"'block'\" size=\"small\" (click)=\"enter('enter')\">确定</ion-button>\n        <app-no-data-show *ngIf=\"!data.data.content.length\"></app-no-data-show>\n    </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/edit-task/edit-task.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/edit-task/edit-task.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <!-- 展示一个相同工厂的合同列表  -->\n    <nz-steps\n        nzType=\"navigation\"\n        nzDirection=\"horizontal\"\n        nzSize=\"small\"\n        [nzCurrent]=\"index\"\n        (nzIndexChange)=\"onIndexChange($event)\"\n    >\n        <nz-step nzTitle=\"选择工厂\" nzStatus=\"{{index == 0 ? 'wait' : 'process'}}\" nzDescription=\"选择要操作的工厂\"></nz-step>\n        <nz-step\n            nzTitle=\"勾选SKU\"\n            [nzDisabled]=\"!currentFactory\"\n            nzStatus=\"{{index <= 1 ? 'wait' : 'process'}}\" \n            nzDescription=\"勾选2个及以上不同批次号下的SKU\"\n        ></nz-step>\n        <nz-step\n            [nzDisabled]=\"!currentFactory || !treeChecked.length\"\n            nzTitle=\"填写信息\"\n            nzStatus=\"finish\"\n            nzStatus=\"{{index == 2 ? 'finish' : 'wait'}}\" \n            nzDescription=\"选择验货人及验货时间\"\n        ></nz-step>\n    </nz-steps>\n\n    <div class=\"tips\">\n        <h4 nz-typography>当前工厂: {{ currentFactory }}</h4>\n    </div>\n    <!-- 选择要合并的合同 -->\n    <div class=\"container\" *ngIf=\"index == 0\">\n        <div class=\"f-r search-bar mb-10\">\n            <nz-input-group nzSearch >\n                <input type=\"text\" [formControl]=\"factoryKeywords\" nz-input placeholder=\"请输入工厂名检索工厂\" />\n            </nz-input-group>\n        </div>\n\n        <nz-table class=\"mt-20\" #basicTable [nzData]=\"_tasks\" [nzShowPagination]=\"false\" [nzFrontPagination]=\"false\">\n            <thead>\n                <tr>\n                    <th>选择工厂</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr\n                    *ngFor=\"let data of basicTable.data\"\n                    (click)=\"tree = [data]; index = 1; currentFactory = data.title; currentFactoryTreeKey = data.key\"\n                >       \n                    <td>{{ data.title }}</td>\n                </tr>\n            </tbody>\n        </nz-table>\n    </div>\n    <!-- 显示穿梭框 -->\n    <div class=\"container\" [hidden]=\"index !== 1\">\n        <div class=\"f-r search-bar mb-10\">\n            <nz-input-group>\n                <input\n                    type=\"text\"\n                    nz-input\n                    [(ngModel)]=\"treeKeywords\"\n                    (input)=\"treeKeyChange($event)\"\n                    placeholder=\"请输入流水号或者合同号或者SKU加以检索\"\n                />\n            </nz-input-group>\n        </div>\n        <div class=\"clearfix\"></div>\n        <nz-tree\n            class=\"mt-40\"\n            [nzSearchValue]=\"treeKeywords\"\n            (nzCheckBoxChange)=\"treeOnChange($event)\"\n            [nzData]=\"tree\"\n            [nzCheckable]=\"true\" \n            nzShowLine\n            (nzClick)=\"nzEvent($event)\"\n            #nzTree\n        >\n        </nz-tree>\n    </div>\n    <!-- 填写信息 -->\n    <div class=\"container\" *ngIf=\"index == 2\">\n        <nz-form-item class=\"mt-30\">\n            <nz-form-label [nzSm]=\"10\" [nzXs]=\"24\" nzRequired>选择验货人</nz-form-label>\n            <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\">\n                <nz-select\n                    class=\"min-width-100\"\n                    [nzMaxTagCount]=\"3\"\n                    nzMode=\"multiple\"\n                    nzPlaceHolder=\"请选择\"\n                    [(ngModel)]=\"inspector\"\n                >\n                    <nz-option nzLabel=\"请选择验货人\" nzValue=\"\"></nz-option>\n                    <nz-option *ngFor=\"let item of inspectors\" [nzLabel]=\"item.name\" [nzValue]=\"item.id\"></nz-option>\n                </nz-select>\n            </nz-form-control>\n        </nz-form-item>\n        <nz-form-item>\n            <nz-form-label [nzSm]=\"10\" [nzXs]=\"24\" nzRequired>选择验货时间</nz-form-label>\n            <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\">\n                <nz-date-picker\n                    [nzFormat]=\"'yyyy/MM/dd'\"\n                    class=\"mr-5\"\n                    nzPlaceholder=\"请选择开始时间\"\n                    [(ngModel)]=\"startTime\"\n                    (ngModelChange)=\"onChange($event, 'start')\"\n                ></nz-date-picker>\n                -\n                <nz-date-picker\n                    [nzFormat]=\"'yyyy/MM/dd'\"\n                    nzPlaceholder=\"请选择结束时间\"\n                    [(ngModel)]=\"endTime\"\n                    (ngModelChange)=\"onChange($event, 'end')\"\n                ></nz-date-picker>\n            </nz-form-control>\n        </nz-form-item>\n        <nz-form-item>\n            <nz-form-label [nzSm]=\"10\" [nzXs]=\"24\">填写备注</nz-form-label>\n            <nz-form-control [nzSm]=\"14\" [nzXs]=\"48\">\n                <textarea rows=\"4\" cols=\"41\" [(ngModel)]=\"params.desc\" nz-input placeholder=\"请填写备注\"></textarea>\n            </nz-form-control>\n        </nz-form-item>\n        <nz-form-item>\n            <nz-form-control [nzXs]=\"{ span: 24, offset: 0 }\" [nzSm]=\"{ span: 14, offset: 10 }\">\n                <button nz-button nzType=\"primary\" [disabled]=\"!canClick\" (click)=\"submit()\">提交</button>\n            </nz-form-control>\n        </nz-form-item>\n    </div>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/editor/editor.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/editor/editor.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"root pos-r\" style=\"border: 1px solid #ccc;\">\n    <div id=\"editorMenu\"></div>\n    <div id=\"editor\" style=\"height:200px;max-height:200px; border-top: 1px solid #ccc;\">\n        <p>{{ defaultMessage }}</p>\n    </div>\n    <!-- {{commit.editor.txt.text()}} -->\n    <!-- [disabled]=\"commit.editor && commit.editor.txt && !commit.editor.txt.text()\"  -->\n    <button nz-button nzType=\"primary\" nzSize=\"small\" class=\"enter\" (click)=\"onData.emit(commit.editor.txt.html())\">\n        确定\n    </button>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/funnel/funnel.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/funnel/funnel.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-icon name=\"funnel\" class=\"fs-12\" nz-dropdown [nzDropdownMenu]=\"menu\" (click)=\"openSelector()\"></ion-icon>\n\n<nz-dropdown-menu #menu=\"nzDropdownMenu\">\n    <ul nz-menu nzSelectable>\n        <li nz-menu-item *ngFor=\"let item of _list\" (click)=\"onSelected.emit(item)\" >{{ item.key }}</li>\n    </ul>\n</nz-dropdown-menu>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/inspect-setting-box/inspect-setting-box.component.html":
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/inspect-setting-box/inspect-setting-box.component.html ***!
  \******************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"root\">\n    <ion-list class=\"f-l\">\n        <ion-item>\n            <ion-label>是否与工厂联系：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_contacted_factory\"></ion-toggle>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>是否购买车票：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_bought_ticket\"></ion-toggle>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>验货工厂是否曾经验过：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_inspected_factory\"></ion-toggle>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>验货产品是否曾经验过：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_inspected_product\"></ion-toggle>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>是否规范好时间路线：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_plan_date\"></ion-toggle>\n        </ion-item>\n\n        <ion-item>\n            <ion-label>是否熟悉要求：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_know_demand\"></ion-toggle>\n        </ion-item>\n    </ion-list>\n</div>\n<ion-button color=\"primary\" (click)=\"enter()\">确定</ion-button>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/loadding/loadding.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/loadding/loadding.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"dis-flex\">\n    <img src=\"../../assets/icon/loadding2.svg\" alt=\"\" />\n    <ion-text>正在加载</ion-text>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/no-data-show/no-data-show.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/no-data-show/no-data-show.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div\n    style=\"\n        width: 100%;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        flex-direction: column;\n        margin-top: 100px;\n    \"\n    class=\"mt-100\"\n>\n    <img style=\"width: 200px;\" src=\"../../../assets/img/no-data.png\" alt=\"\" />\n    <p class=\"mt-20\" style=\"color: #ababab; text-align: center;\">暂无数据</p>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/pagination/pagination.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/pagination/pagination.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"page-box\">\n    <ion-button [fill]=\"'clear'\" color=\"\" size=\"small\" (click)=\"changePage(1)\" [disabled]=\"pageNum == 1\"\n        >首页</ion-button\n    >\n    <ion-button [fill]=\"'clear'\" size=\"small\" (click)=\"changePage(pageNum - 1)\" [disabled]=\"pageNum <= 1\"\n        >上一页</ion-button\n    >\n    <div class=\"text\">\n        <ion-text>{{ pageNum }}</ion-text>\n        <ion-text>/</ion-text>\n        <ion-text>{{ pageTotal }}</ion-text>\n    </div>\n    <ion-button [fill]=\"'clear'\" size=\"small\" (click)=\"changePage(+(+pageNum) + 1)\" [disabled]=\"pageNum >= pageTotal\"\n        >下一页</ion-button\n    >\n    <ion-button [fill]=\"'clear'\" size=\"small\" (click)=\"changePage(pageTotal)\" [disabled]=\"pageNum == pageTotal\"\n        >尾页</ion-button\n    >\n    <nz-select\n        *ngIf=\"hidePaging\"\n        [(ngModel)]=\"pagingTotal\"\n        nzSize=\"small\"\n        class=\"mr-10\"\n        (ngModelChange)=\"pagingTotalChange($event)\"\n    >\n        <nz-option [nzValue]=\"10\" nzLabel=\"10条/页\">10条/页</nz-option>\n        <nz-option [nzValue]=\"20\" nzLabel=\"20条/页\">20条/页</nz-option>\n        <nz-option [nzValue]=\"30\" nzLabel=\"30条/页\">30条/页</nz-option>\n        <nz-option [nzValue]=\"50\" nzLabel=\"50条/页\">50条/页</nz-option>\n        <nz-option [nzValue]=\"100\" nzLabel=\"100条/页\">100条/页</nz-option>\n    </nz-select>\n\n    <input placeholder=\"0\" [(ngModel)]=\"paging\" type=\"number\" (change)=\"regValid($event)\" />\n    <ion-button [fill]=\"'clear'\" size=\"small\" (click)=\"changePage(paging)\" [disabled]=\"!paging\">跳转</ion-button>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/permission-tree/permission-tree.component.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/permission-tree/permission-tree.component.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<nz-tabset class=\"w100\">\n    <nz-tab nzTitle=\"菜单/按钮\">\n        <nz-tree\n            [nzData]=\"_permissions\"\n            nzCheckable\n            [nzBlockNode]=\"true\"\n            nzMultiple\n            [nzExpandAll]=\"true\"\n            [nzTreeTemplate]=\"nzTreeTemplate\"\n            (nzCheckBoxChange)=\"getTreePermission($event.keys)\"\n        >\n            <ng-template #nzTreeTemplate let-node>\n                <span>\n                    {{ node.title }}\n                </span>\n                <span [ngClass]=\"node.origin.type\"> ({{ permissionTypeMap[node.origin.type] }}) </span>\n            </ng-template>\n        </nz-tree>\n    </nz-tab>\n    <nz-tab nzTitle=\"列表字段\">\n        <nz-collapse>\n            <nz-collapse-panel\n                *ngFor=\"let panel of _permissionListFiled\"\n                [nzHeader]=\"$any(panel).title\"\n                [nzActive]=\"$any(panel).active\"\n            >\n                <nz-checkbox-group\n                    [(ngModel)]=\"panel.children\"\n                    (ngModelChange)=\"logReportFiled(panel)\"\n                ></nz-checkbox-group>\n            </nz-collapse-panel>\n        </nz-collapse>\n    </nz-tab>\n    <nz-tab nzTitle=\"验货报告\">\n        <nz-checkbox-group\n            [(ngModel)]=\"permissionReport\"\n            (ngModelChange)=\"logReportFiled(permissionReport)\"\n        ></nz-checkbox-group>\n    </nz-tab>\n</nz-tabset>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/progress/progress.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/progress/progress.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"progress\" style=\"margin-bottom: 0;\">\n    <div\n        class=\"progress-bar progress-bar-striped active\"\n        role=\"progressbar\"\n        [ngStyle]=\"{ width: (current / total > 1 ? 100 : (current / total) * 100) + '%' }\"\n    >\n        {{ ((current / total > 1 ? 100 : (current / total) * 100) | number: '2.1-2') + '%' }}\n    </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/reply-mode/reply-mode.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/reply-mode/reply-mode.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n    reply-mode works!\n</p>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/reply/reply.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/reply/reply.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div #screen id=\"screen\">\n    <ng-template #commentTemplateRef let-comment=\"comment\">\n        <nz-comment\n            [nzAuthor]=\"(comment.user && comment.user.name) || '未知'\"\n            [nzDatetime]=\"(comment.created_at | date: 'yyyy-MM-dd hh:mm:ss') || '几天前'\"\n        >\n            <nz-avatar nz-comment-avatar nzIcon=\"user\" [nzSrc]=\"'../../../assets/img/avatar-2.png'\"></nz-avatar>\n            <nz-comment-content>\n                <p *ngIf=\"!comment.advise_img && !comment.advise_video\">{{ comment.contents || '暂无' }}</p>\n                <div class=\"comment-img\" *ngIf=\"comment.advise_img\">\n                    <img [src]=\"env.origin + '/' + comment.advise_img\" alt=\"\" imgGallery />\n                </div>\n                <div class=\"comment-video\" *ngIf=\"comment.advise_video\">\n                    <video controls [src]=\"env.origin + '/' + comment.advise_video\"></video>\n                </div>\n            </nz-comment-content>\n            <nz-comment-action>\n                <span (click)=\"reply(comment); commentBoxShow = true\">回复</span>\n                <span\n                    nz-popconfirm\n                    nzPopconfirmTitle=\"确定要删除吗?\"\n                    class=\"ml-15\"\n                    nzPopconfirmPlacement=\"bottom\"\n                    (nzOnConfirm)=\"delConfirm(comment)\"\n                    >删除</span\n                >\n                <span\n                    (click)=\"commentBoxShow = false\"\n                    *ngIf=\"comment.id == currentComment.id && commentBoxShow\"\n                    class=\"ml-15\"\n                    >取消</span\n                >\n            </nz-comment-action>\n\n            <ng-container *ngIf=\"comment.son && comment.son.length\">\n                <ng-template ngFor let-child [ngForOf]=\"comment.son\">\n                    <ng-template [ngTemplateOutlet]=\"commentTemplateRef\" [ngTemplateOutletContext]=\"{ comment: child }\">\n                    </ng-template>\n                </ng-template>\n            </ng-container>\n\n            <nz-comment-content *ngIf=\"comment.id == currentComment.id && commentBoxShow\">\n                <nz-tabset [nzType]=\"'line'\" nzSize=\"small\">\n                    <nz-tab [nzTitle]=\"'文字'\">\n                        <nz-form-item>\n                            <textarea [(ngModel)]=\"inputValue\" nz-input rows=\"4\"></textarea>\n                        </nz-form-item>\n                        <nz-form-item>\n                            <button\n                                nz-button\n                                nzType=\"primary\"\n                                nzSize=\"small\"\n                                [nzLoading]=\"submitting\"\n                                [disabled]=\"!inputValue\"\n                                (click)=\"handleSubmit(comment)\"\n                            >\n                                添加回复\n                            </button>\n                        </nz-form-item>\n                    </nz-tab>\n                    <nz-tab [nzTitle]=\"'图片'\">\n                        <nz-upload\n                            [nzShowButton]=\"fileList.length < 8\"\n                            [nzPreview]=\"handlePreview\"\n                            [nzAccept]=\"'image/png,image/jpeg,image/gif,image/bmp'\"\n                            [nzRemove]=\"shouldRemoveImg\"\n                            [nzFileType]=\"'image/png,image/jpeg,image/gif,image/bmp'\"\n                            [nzCustomRequest]=\"customRequest\"\n                            (nzChange)=\"handleChange($event)\"\n                        >\n                            <div class=\"ant-upload-text\">点击上传</div>\n                        </nz-upload>\n                    </nz-tab>\n                    <nz-tab [nzTitle]=\"'视频'\">\n                        <nz-upload\n                            [nzFileType]=\"'video/mp4,video/wma'\"\n                            [nzRemove]=\"shouldRemoveImg\"\n                            [nzAccept]=\"'video/mp4,video/wma'\"\n                            [nzCustomRequest]=\"customRequestVideo\"\n                            (nzChange)=\"handleChange($event)\"\n                        >\n                            <div class=\"ant-upload-text\">点击上传</div>\n                        </nz-upload>\n                    </nz-tab>\n                </nz-tabset>\n            </nz-comment-content>\n        </nz-comment>\n    </ng-template>\n    <ng-template [ngTemplateOutlet]=\"commentTemplateRef\" [ngTemplateOutletContext]=\"{ comment: _data }\"> </ng-template>\n</div>\n\n<nz-modal\n    [nzVisible]=\"previewVisible\"\n    [nzContent]=\"modalContent\"\n    [nzFooter]=\"null\"\n    (nzOnCancel)=\"previewVisible = false\"\n>\n    <ng-template #modalContent>\n        <img [src]=\"previewImage\" [ngStyle]=\"{ width: '100%' }\" />\n    </ng-template>\n</nz-modal>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sku-desc-popup/sku-desc-popup.component.html":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sku-desc-popup/sku-desc-popup.component.html ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<table\n    id=\"table1\"\n    style=\"table-layout: fixed !important; width: 1200px;\"\n    class=\"table table-striped table-condensed table-hover table-condensed table-text-no-break\"\n>\n    <thead>\n        <tr>\n            <td class=\"w100\">SKU</td>\n            <td class=\"w100\">中文名称</td>\n            <td class=\"w200\">描述</td>\n            <td class=\"w100\">是否含配件</td>\n            <td class=\"w100\">材质</td>\n            <td class=\"w150\">包装方式</td>\n            <td class=\"w100\">验货主题</td>\n            <td class=\"w200\">验货内容</td>\n        </tr>\n    </thead>\n    <tbody>\n        <tr *ngFor=\"let item of skuDesc; let i = index\">\n            <td class=\"w100\" [title]=\"item.sku\">{{ item.sku }}</td>\n            <td class=\"w100\" [title]=\"item.chinese_name\">{{ item.chinese_name }}</td>\n            <td class=\"w200\" [title]=\"item.chinese_description\">{{ item.chinese_description }}</td>\n            <td class=\"w100\">{{ item.accessory_info ? '是' : '否' }}</td>\n            <td class=\"w100\" [title]=\"item.text_ture\">{{ item.text_ture }}</td>\n            <td class=\"w150\" [title]=\"item.packing_type\">{{ item.packing_type }}</td>\n            <td colspan=\"2\">\n                <table class=\"table2\" style=\"table-layout: fixed !important; width: 300px;\">\n                    <tr *ngFor=\"let sItem of item.inspection_require\">\n                        <td class=\"w100\" [title]=\"sItem.theme_name\">{{ sItem.theme_name }}</td>\n                        <td class=\"w200\" [title]=\"sItem.require\">{{ sItem.require }}</td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n    </tbody>\n</table>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sku-info/sku-info.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sku-info/sku-info.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div>\n    <p><span>合同号：</span>{{ $any(_contract).contract_no }}</p>\n\n\n    <nz-table #table  [nzData]=\"$any(_contract).sku_list\">\n        <thead>\n            <th>缩略图</th>\n            <th>SKU</th>\n            <th>中文名</th>\n            <th>箱率</th>\n            <th>仓库</th>\n            <th>合同数量</th>\n            <th>剩余数量</th>\n            <th>返单率</th>\n            <!-- <th>合同数量</th> -->\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let item of table.data\">\n                <td>\n                    <img [src]=\"baseData.fileUrl + item.pic\" alt=\"\" imgGallery />\n                </td>\n                <td>\n                    {{ item.sku }}\n                </td>\n                <td>\n                    {{ item.name }}\n                </td>\n                <td>\n                    {{ item.rate_container }}\n                </td>\n                <td>\n                    {{ item.warehouse }}\n                </td>\n                <td>\n                    {{ item.Count }}\n                </td>\n                <td>\n                    {{ item.inspection_left_num }}\n                </td>\n                <td>\n                    {{ item.return_rate }}\n                </td>\n                <!-- <td>\n                    {{ item.inspectioned_num }}\n                </td> -->\n            </tr>\n        </tbody>\n    </nz-table>\n</div>");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sort/sort.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sort/sort.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"dis-flex\" (click)=\"change()\">\n    <ion-label class=\"mr-5\">{{ sortName }}</ion-label>\n    <ion-icon class=\"fs-20\" [name]=\"icon\"></ion-icon>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/td-overflow-text/td-overflow-text.component.html":
/*!************************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/td-overflow-text/td-overflow-text.component.html ***!
  \************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <div class=\"pos-a out-div chip-text-tips\">\n    <p class=\"chip-text chip-text-tips\" Chipboard>{{ text }}</p>\n</div> -->\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/track-exclude/track-exclude.component.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/track-exclude/track-exclude.component.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"drawer-content\">\n    <h4>\n        <span>合同号：{{ contract.contract_no }}</span>\n        <span>工厂名：{{ contract.factory_name }}</span>\n    </h4>\n    <nz-table #skuTable nzSize=\"small\" [nzShowPagination]=\"false\" [nzData]=\"contract.sku_list\">\n        <thead>\n            <tr>\n                <th [nzAlign]=\"'center'\">SKU</th>\n                <th [nzAlign]=\"'center'\">中文名</th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let data of skuTable.data; let i = index\">\n                <td [nzAlign]=\"'center'\">{{ data.sku }}</td>\n                <td [nzAlign]=\"'center'\">{{ data.name }}</td>\n            </tr>\n        </tbody>\n    </nz-table>\n\n    <nz-table\n        class=\"mt-20\"\n        #scgeduleTable\n        nzSize=\"small\"\n        [(nzPageSize)]=\"contract.schedule_list_select.length\"\n        [nzShowPagination]=\"false\"\n        [nzData]=\"contract.schedule_list_select\"\n    >\n        <thead>\n            <tr>\n                <th [nzAlign]=\"'center'\">序号</th>\n                <th [nzAlign]=\"'center'\">状态</th>\n                <th [nzAlign]=\"'center'\">进度要求</th>\n                <th [nzAlign]=\"'center'\">我不需要</th>\n                <th [nzAlign]=\"'center'\">操作</th>\n            </tr>\n        </thead>\n        <tbody>\n            <ng-container *ngFor=\"let data of scgeduleTable.data; let i = index\">\n                <tr>\n                    <td [nzAlign]=\"'center'\">{{ i + 1 }}</td>\n                    <td [nzAlign]=\"'center'\">{{ data.description }}</td>\n                    <td [nzAlign]=\"'center'\">{{ data.details }}</td>\n                    <td [nzAlign]=\"'center'\" [ngStyle]=\"{ color: data.is_need ? '#666' : '#b9b9b9' }\">\n                        我不需要\n                    </td>\n                    <td [nzAlign]=\"'center'\">\n                        <label\n                            nz-checkbox\n                            [(ngModel)]=\"data.is_need\"\n                            (change)=\"setStatusJudgeFn(data)\"\n                            [disabled]=\"data.meta_is_need && !baseData.isSystemManger()\"\n                            [nzChecked]=\"data.is_need\"\n                        ></label>\n                    </td>\n                </tr>\n            </ng-container>\n        </tbody>\n    </nz-table>\n</div>\n\n<div class=\"footer mt-20 f-r\">\n    <p class=\"color-red m-0\">备注：8-14唛头选项必须保留一个！</p>\n    <div>\n        <a \n            nz-popconfirm\n            nzPopconfirmTitle=\"确定要重置吗？\"\n            nzPopconfirmPlacement=\"bottom\"\n            (nzOnConfirm)=\"confirm()\"\n            (nzOnCancel)=\"cancel()\"\n            class=\"mr-15\"\n        >\n            <span>重置</span>\n        </a>\n\n        <button\n            type=\"button\"\n            nzSize=\"small\"\n            nz-button\n            nzType=\"primary\"\n            (click)=\"scheduleEditSubmit()\"\n            class=\"ant-btn ant-btn-primary\"\n        >\n            <span>提交</span>\n        </button>\n    </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/uploadimg/uploadimg.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/uploadimg/uploadimg.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"col-sm-1 col-xs-2 file-box\">\n    <ion-button size=\"small\">拍照</ion-button>\n    <input\n        accept=\"image/*\"\n        type=\"file\"\n        class=\"img-up-load\"\n        ng2FileSelect\n        [uploader]=\"uploader\"\n        (change)=\"selectedFileOnChanged()\"\n        multiple\n    />\n</div>\n\n<div class=\"col-sm-1 col-xs-2\">\n    <ion-button [disabled]=\"uploader.progress == 100 || uploader.queue.length == 0\" size=\"small\" (click)=\"upload()\"\n        >上传</ion-button\n    >\n</div>\n\n<ul class=\"col-sm-12 img-box\" imgGallery>\n    <li *ngFor=\"let item of uploader.queue\">\n        <!-- <ion-icon name='close' color='#f00' (click)=\"clearImg(img)\"></ion-icon> -->\n        <img src=\"\" imgPreview [image]=\"item.some\" class=\"img-responsive\" alt=\"预览图\" />\n    </li>\n</ul>\n\n<app-progress [total]=\"100\" [current]=\"uploader.progress\"></app-progress>\n\n<div class=\"form-group inspection-item-img\">\n    <div class=\"col-sm-2\"></div>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/create-inspec-batch/create-inspec-batch.page.html":
/*!*********************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/create-inspec-batch/create-inspec-batch.page.html ***!
  \*********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"tab-view-page over-h\" padding>\n    <div class=\"search-box\">\n        <ion-segment color=\"tertiary\" [(ngModel)]=\"getListParams.type\" (ionChange)=\"segmentChange()\">\n            <ion-segment-button value=\"contract_no\">\n                <ion-label>合同号</ion-label>\n                <ion-icon name=\"calendar\"></ion-icon>\n            </ion-segment-button>\n            <ion-segment-button value=\"factory_simple_address\">\n                <ion-label>工厂地址</ion-label>\n                <ion-icon name=\"link\"></ion-icon>\n            </ion-segment-button>\n            <ion-segment-button value=\"manufacturer\">\n                <ion-label>工厂名称</ion-label>\n                <ion-icon name=\"star\"></ion-icon>\n            </ion-segment-button>\n\n            <ion-segment-button value=\"user_name\">\n                <ion-label>验货人</ion-label>\n                <ion-icon name=\"people\"></ion-icon>\n            </ion-segment-button>\n        </ion-segment>\n        <ion-searchbar\n            debounce=\"500\"\n            [placeholder]='\"按\" + chinaeseType + \"搜索\"'\n            showCancelButton=\"true\"\n            [(ngModel)]=\"getListParams.keywords\"\n            (ionChange)=\"getListBySearch()\"\n            spellcheck=\"true\"\n        >\n        </ion-searchbar>\n    </div>\n\n    <div class=\"swiper-container\" [swiper]=\"swiperConfig\">\n        <div class=\"swiper-wrapper\">\n            <div class=\"swiper-slide\">\n                <table\n                    id=\"table1\"\n                    style=\"table-layout: fixed;\"\n                    class=\"table table-striped table-condensed table-hover table-condensed table-text-no-break mb-0\"\n                    [ngStyle]=\"{'width': tableWidth + 'px'}\"\n                >\n                    <thead>\n                        <tr>\n                            <td class=\"w100\" *ngIf=\"userLimit.has('inspector',42)\">\n                                <app-sort\n                                    [sortField]='\"inspection_username_order_by\"'\n                                    [sortName]='\"验货人\"'\n                                    (outFn)=\"getinpectionGroup($event)\"\n                                ></app-sort>\n                            </td>\n                            <td class=\"w120\" *ngIf=\"userLimit.has('inspection-group-no',42)\">\n                                <app-sort\n                                    [sortField]='\"inspection_group_no_order_by\"'\n                                    [sortName]='\"批次号\"'\n                                    (outFn)=\"getinpectionGroup($event)\"\n                                ></app-sort>\n                            </td>\n\n                            <td class=\"w100\" *ngIf=\"userLimit.has('earliest-inspection-time',42)\">最早可验货时间</td>\n                            <td class=\"w200\" *ngIf=\"userLimit.has('inspection-time',42)\">计划验货时间</td>\n\n                            <td class=\"w180\" Chipboard *ngIf=\"userLimit.has('factory-name',42)\">工厂名称</td>\n                            <td class=\"w100\" *ngIf=\"userLimit.has('factory-address',42)\">工厂地址</td>\n\n                            <td class=\"w90\" *ngIf=\"userLimit.has('inspection-sku-quantity',42)\">验货SKU数</td>\n\n                            <td class=\"w200\">合同操作</td>\n                            <td class=\"w200\">操作</td>\n                            <td class=\"w100\" *ngIf=\"userLimit.has('desc',42)\">备注</td>\n\n                            <td class=\"w150\" *ngIf=\"userLimit.has('sku',42)\">货号</td>\n                            <td class=\"w200\" *ngIf=\"userLimit.has('sku-desc',42)\">货号备注</td>\n                        </tr>\n                    </thead>\n                </table>\n\n                <div class=\"custom-tbody\" *ngIf=\"inspecGroup && inspecGroup.length!=0\">\n                    <table\n                        id=\"table1\"\n                        style=\"table-layout: fixed;\"\n                        class=\"table table-striped table-condensed table-hover table-condensed table-text-no-break\"\n                        [ngStyle]=\"{'width': tableWidth + 'px'}\"\n                    >\n                        <tbody>\n                            <tr *ngFor=\"let item of inspecGroup;let i = index\">\n                                <!-- 验货人 -->\n                                <td\n                                    class=\"w100 pos-r chip-text\"\n                                    Chipboard\n                                    [title]=\"item.user.join('')\"\n                                    *ngIf=\"userLimit.has('inspector',42)\"\n                                >\n                                    {{ item.user.length > 2 ? item.user[0] + ',' + item.user[1] + '…' :\n                                    item.user.join(',')}}\n                                </td>\n                                <!-- 批次号 -->\n                                <td\n                                    class=\"w120\"\n                                    [title]=\"item.inspection_group_no\"\n                                    *ngIf=\"userLimit.has('inspection-group-no',42)\"\n                                >\n                                    {{ item.inspection_group_no.length > 11 ? item.inspection_group_no.slice(0,9) + '…'\n                                    :item.inspection_group_no }}\n                                </td>\n\n                                <td colspan=\"6\" [attr.colSpan]=\"sixColSpan\" class=\"w870\">\n                                    <!-- width: 790px; -->\n                                    <table\n                                        class=\"table2\"\n                                        style=\"table-layout: fixed; \"\n                                        [ngStyle]=\"{'width':tableColSpanSixWidth + 'px'}\"\n                                    >\n                                        <tbody>\n                                            <tr\n                                                *ngFor=\"let sItem of item.apply_inspections\"\n                                                (mouseenter)=\"currentHoverItem = sItem\"\n                                                (mouseleave)=\"currentHoverItem = null\"\n                                            >\n                                                <!-- 最早验货时间 -->\n                                                <td\n                                                    class=\"w100 pos-r\"\n                                                    *ngIf=\"userLimit.has('earliest-inspection-time',42)\"\n                                                >\n                                                    {{sItem.inspection_date?(sItem.inspection_date|date:'yyyy-MM-dd'):''}}\n                                                </td>\n\n                                                <!-- 计划验货时间 -->\n                                                <td class=\"w200 pos-r\" *ngIf=\"userLimit.has('inspection-time',42)\">\n                                                    <div\n                                                        class=\"probable-date-div pos-a chip-text\"\n                                                        Chipboard\n                                                        [ngStyle]=\"{'line-height': 36*sItem.sku_group.length+'px'}\"\n                                                    >\n                                                        {{(sItem.date ?(sItem.date.probable_inspection_date_start |\n                                                        date:'yyyy-MM-dd' | filterText):'')+' - '+ (sItem.date ?\n                                                        (sItem.date.probable_inspection_date_end | date:'yyyy-MM-dd' |\n                                                        filterText):'') }}\n                                                    </div>\n                                                </td>\n\n                                                <!-- 工厂名 -->\n                                                <td\n                                                    class=\"pos-r w180\"\n                                                    [ngStyle]=\"{'height': 36*(sItem.sku_group.length>sItem.data.length?sItem.sku_group.length:sItem.data.length)+'px'}\"\n                                                    title=\"{{sItem.factory_name}}\"\n                                                    style=\"overflow: visible !important;\"\n                                                    *ngIf=\"userLimit.has('factory-name',42)\"\n                                                >\n                                                    <div\n                                                        class=\"inner-div pos-a chip-text\"\n                                                        Chipboard\n                                                        [ngStyle]=\"{'line-height': 36*(sItem.sku_group.length>sItem.data.length?sItem.sku_group.length:sItem.data.length)+'px'}\"\n                                                    >\n                                                        {{sItem.factory_name.length>12?sItem.factory_name.substring(0,12)+'…':sItem.factory_name}}\n                                                    </div>\n\n                                                    <app-td-overflow-text\n                                                        *ngIf=\"sItem.show_factory_tips\"\n                                                        [text]=\"sItem.factory_name\"\n                                                    >\n                                                    </app-td-overflow-text>\n                                                </td>\n\n                                                <!-- 工厂地址 -->\n                                                <td class=\"w100 pos-r\" *ngIf=\"userLimit.has('factory-address',42)\">\n                                                    {{sItem.factory_address}}\n                                                </td>\n\n                                                <!-- 验货数 -->\n                                                <td\n                                                    class=\"chip-text w90 pos-r\"\n                                                    Chipboard\n                                                    *ngIf=\"userLimit.has('inspection-sku-quantity',42)\"\n                                                >\n                                                    {{sItem.sku_count}}\n                                                </td>\n\n                                                <!-- 操作 查看sku 查看详情 style=\"width: 200px !important;\"-->\n                                                <td colspan=\"1\" class=\"w200\">\n                                                    <table\n                                                        class=\"table3\"\n                                                        style=\"table-layout: fixed; width: 200px !important;\"\n                                                    >\n                                                        <tbody>\n                                                            <tr *ngFor=\"let tItem of sItem.data\">\n                                                                <td class=\"w200\">\n                                                                    <button\n                                                                        nz-button\n                                                                        (click)=\"seeSku(tItem)\"\n                                                                        nzSize=\"small\"\n                                                                        class=\"mr-5\"\n                                                                        nzType=\"primary\"\n                                                                        *ngIf=\"userLimit.has('show-sku',42)\"\n                                                                    >\n                                                                        查看SKU\n                                                                    </button>\n                                                                    <button\n                                                                        nz-button\n                                                                        (click)=\"seeDetail(tItem)\"\n                                                                        nzSize=\"small\"\n                                                                        nzType=\"primary\"\n                                                                        *ngIf=\"userLimit.has('show-detail',42)\"\n                                                                    >\n                                                                        查看详情\n                                                                    </button>\n                                                                </td>\n                                                            </tr>\n                                                        </tbody>\n                                                    </table>\n                                                </td>\n                                            </tr>\n                                        </tbody>\n                                    </table>\n                                </td>\n\n                                <!-- 撤销验货 确认验货 -->\n                                <td class=\"w200\">\n                                    <button\n                                        nz-button\n                                        (click)=\"revokeTask(item,'group')\"\n                                        class=\"mr-5\"\n                                        nzSize=\"small\"\n                                        nzType=\"danger\"\n                                        *ngIf=\"userLimit.has('reset-inspection',42)\"\n                                    >\n                                        撤销验货\n                                    </button>\n                                    <button\n                                        nz-button\n                                        *ngIf=\"userLimit.has('confirm-inspection',42)\"\n                                        (click)=\"enterReceiving(item)\"\n                                        nzSize=\"small\"\n                                        nzType=\"primary\"\n                                    >\n                                        确认验货\n                                    </button>\n                                </td>\n\n                                <!-- 备注 -->\n                                <td colspan=\"3\" [attr.colSpan]=\"threeColSpan\"  [ngStyle]=\"{'width': tableColSpanThreeWidth + 'px'}\">\n                                    <!-- style=\"table-layout: fixed; width: 450px !important;\" -->\n                                    <table class=\"table3\" [ngStyle]=\"{'width':tableColSpanThreeWidth + 'px'}\">\n                                        <tbody>\n                                            <tr\n                                                *ngFor=\"let sItem of item.apply_inspections\"\n                                                style=\"background: transparent;\"\n                                            >\n                                                <td\n                                                    class=\"w100 chip-text\"\n                                                    Chipboard\n                                                    title=\"{{sItem.desc}}\"\n                                                    style=\"background: transparent !important;width: 100px ;\"\n                                                    *ngIf=\"userLimit.has('desc',42)\"\n                                                >\n                                                    <div>\n                                                        {{sItem.desc && sItem.desc.length >8 ? sItem.desc.slice(0,8) :\n                                                        sItem.desc}}\n                                                    </div>\n                                                </td>\n                                                <td\n                                                    colspan=\"2\"\n                                                    [attr.colSpan]=\"twoColSpan\"\n                                                    [ngStyle]=\"{'width': tableColSpanTwoWidth + 'px'}\"\n                                                    style=\"background: transparent !important;\"\n                                                >\n                                                    <!-- style=\"width: 350px !important;\" -->\n                                                    <table\n                                                        class=\"three-table\"\n                                                        [ngStyle]=\"{'width':tableColSpanTwoWidth + 'px'}\"\n                                                    >\n                                                        <tbody>\n                                                            <tr *ngFor=\"let tItem of sItem.sku_group\">\n                                                                <td\n                                                                    class=\"w150\"\n                                                                    title='{{tItem.sku_k.substring(tItem.sku_k.lastIndexOf(\"&\") + 1,tItem.sku_k.length ) }}'\n                                                                    *ngIf=\"userLimit.has('sku',42)\"\n                                                                >\n                                                                    {{\n                                                                    tItem.sku_k.substring(tItem.sku_k.lastIndexOf('&') +\n                                                                    1,tItem.sku_k.length ) }}\n                                                                </td>\n                                                                <td\n                                                                    class=\"w200\"\n                                                                    title=\"{{tItem.g_item}}\"\n                                                                    *ngIf=\"userLimit.has('sku-desc',42)\"\n                                                                >\n                                                                    {{tItem.g_item}}\n                                                                </td>\n                                                            </tr>\n                                                        </tbody>\n                                                    </table>\n                                                </td>\n                                            </tr>\n                                        </tbody>\n                                    </table>\n                                </td>\n                            </tr>\n                        </tbody>\n                    </table>\n                </div>\n\n                <app-no-data-show *ngIf=\"!inspecGroup.length\"></app-no-data-show>\n            </div>\n        </div>\n        <div class=\"swiper-scrollbar\"></div>\n    </div>\n\n    <app-pagination\n        class=\"f-r mt-6\"\n        [pagging]=\"{\n    pageNum: getListParams.page,\n    pageTotal: contracts.last_page\n}\"\n        (pagechange)=\"getListByPaging($event)\"\n    ></app-pagination>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.html":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.html ***!
  \************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"clearfix close-box\">\n    <ion-button style=\"float: right;\" (click)=\"cancel()\" size=\"small\" color=\"danger\" class=\"f-r\">关闭</ion-button>\n</div>\n<div class=\"box\">\n    <div class=\"swiper-container\" [swiper]=\"swiperConfig\" *ngIf=\"group && group.length != 0\">\n        <div class=\"swiper-wrapper\">\n            <div class=\"swiper-slide\">\n                <table class=\"table table-striped table-condensed table-hover table-condensed table-text-no-break\">\n                    <thead>\n                        <tr>\n                            <td>申请人</td>\n                            <td>跟单人</td>\n                            <td>采购人</td>\n\n                            <td>合同号</td>\n                            <td class=\"chip-text\" Chipboard>工厂名</td>\n\n                            <td>工厂地址</td>\n                            <td>合同SKU数</td>\n                            <td>验货SKU数</td>\n                            <td>新品SKU数量</td>\n                            <td>申请时间</td>\n                            <td>申请验货时间</td>\n\n                            <td>操作</td>\n                        </tr>\n                    </thead>\n                    <tbody>\n                        <tr *ngFor=\"let item of group; let i = index\">\n                            <td>{{ item.apply_name }}</td>\n                            <td>{{ item.buyer_user }}</td>\n                            <td>{{ item.schedule_name ? item.schedule_name.user.name : '' }}</td>\n\n                            <td class=\"chip-text\" Chipboard>{{ item.contract_no }}</td>\n                            <td class=\"chip-text\" Chipboard>{{ item.factory_name }}</td>\n\n                            <td>{{ item.ProviceName + item.CityName }}</td>\n                            <td class=\"chip-text\" Chipboard>{{ item.total_quantity }}</td>\n                            <td class=\"chip-text\" Chipboard>{{ item.quantity }}</td>\n                            <td class=\"chip-text\" Chipboard>{{ item.new_quantity }}</td>\n                            <td class=\"chip-text\" Chipboard>{{ item.created_at | date: 'yyyy-MM-dd' }}</td>\n                            <td class=\"chip-text\" Chipboard>{{ item.inspection_date | date: 'yyyy-MM-dd' }}</td>\n\n                            <td>\n                                <ion-button\n                                    *ngIf=\"type == ''\"\n                                    size=\"small\"\n                                    (click)=\"revokeTask(item, 'contract')\"\n                                    color=\"danger\"\n                                    >撤销验货</ion-button\n                                >\n                            </td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n        </div>\n        <div class=\"swiper-scrollbar\"></div>\n    </div>\n    <app-no-data-show *ngIf=\"group && group.length == 0\"></app-no-data-show>\n</div>\n");

/***/ }),

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/permission/permission.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/permission/permission.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"tab-view-page over-h\">\n    <button nz-button nzType=\"primary\" nzSize=\"small\" class=\"mb-15\" (click)=\"editPermission()\">\n        添加权限\n    </button>\n\n    <nz-table #basicTable [nzData]=\"permission\" nzTableLayout=\"fixed\" [nzShowPagination]=\"false\">\n        <thead>\n            <tr>\n                <th>权限名称</th>\n                <th>权限字段</th>\n                <th>权限标识</th>\n                <th>权限类型</th>\n                <th>操作</th>\n            </tr>\n        </thead>\n        <tbody>\n            <ng-container *ngFor=\"let data of basicTable.data\">\n                <ng-container *ngFor=\"let item of mapOfExpandedData[data.key]\">\n                    <tr *ngIf=\"(item.parent && item.parent.expand) || !item.parent\">\n                        <td\n                            [nzIndentSize]=\"item.level! * 20\"\n                            [nzShowExpand]=\"!!item.children\"\n                            [(nzExpand)]=\"item.expand\"\n                            (nzExpandChange)=\"collapse(mapOfExpandedData[data.key], item, $event)\"\n                        >\n                            {{ item.title }}\n                        </td>\n                        <td>{{ item.name }}</td>\n                        <td>{{ item.key }}</td>\n                        <td>{{ permissionTypeMap[item.type] }}</td>\n                        <td>\n                            <button\n                                nz-button\n                                nzSize=\"small\"\n                                class=\"mr-5\"\n                                nzType=\"primary\"\n                                (click)=\"editPermission(item)\"\n                            >\n                                编辑\n                            </button>\n                            <button\n                                nz-popconfirm\n                                nzPopconfirmTitle=\"确定要删除吗?\"\n                                nzPopconfirmPlacement=\"bottom\"\n                                (nzOnConfirm)=\"delPermission(item)\"\n                                nz-button\n                                nzSize=\"small\"\n                                nzType=\"danger\"\n                            >\n                                删除\n                            </button>\n                        </td>\n                    </tr>\n                </ng-container>\n            </ng-container>\n        </tbody>\n    </nz-table>\n</div>\n\n<nz-modal\n    [(nzVisible)]=\"editIsVisible\"\n    [nzTitle]=\"$any(currentPermission).key ? '编辑权限' : '添加权限'\"\n    nzOkText=\"确定\"\n    nzCancelText=\"取消\"\n    (nzOnOk)=\"treeHandleOk()\"\n    (nzOnCancel)=\"editIsVisible = !editIsVisible\"\n>\n    <div>\n        <nz-form-item>\n            <nz-form-label [nzSm]=\"8\" [nzXs]=\"24\" nzRequired nzFor=\"email\">权限类型</nz-form-label>\n            <nz-form-control [nzSm]=\"12\" [nzXs]=\"24\">\n                <nz-select [(ngModel)]=\"currentPermission.type\" class=\"w100\"   style=\"width: 250px\">\n                    <nz-option nzValue=\"\" nzLabel=\"请选择权限类型\"></nz-option>\n                    <nz-option nzValue=\"menu\" nzLabel=\"菜单\"></nz-option>\n                    <nz-option nzValue=\"btn\" nzLabel=\"按钮\"></nz-option>\n                    <nz-option nzValue=\"field\" nzLabel=\"列表字段\"></nz-option>\n                    <nz-option nzValue=\"inspect-report\" nzLabel=\"验货报告\"></nz-option>\n                </nz-select>\n            </nz-form-control>\n        </nz-form-item>\n\n        <nz-form-item>\n            <nz-form-label [nzSm]=\"8\" [nzXs]=\"24\" nzRequired nzFor=\"email\">父级权限</nz-form-label>\n            <nz-form-control [nzSm]=\"12\" [nzXs]=\"24\">\n                <nz-tree-select\n                    style=\"width: 250px\"\n                    [nzNodes]=\"permission\"\n                    nzShowSearch\n                    [(ngModel)]=\"currentPermission.parent_id\"\n                    nzPlaceHolder=\"请选择父级权限\"\n                    [(ngModel)]=\"value\"\n                    (ngModelChange)=\"onChange($event)\"\n                >\n                </nz-tree-select>\n            </nz-form-control>\n        </nz-form-item>\n\n        <nz-form-item>\n            <nz-form-label [nzSm]=\"8\" [nzXs]=\"24\" nzRequired nzFor=\"email\">权限名称（英文）</nz-form-label>\n            <nz-form-control [nzSm]=\"12\" [nzXs]=\"24\">\n                <input style=\"width: 250px\" class=\"w100\" nz-input placeholder=\"请填写权限显示的名称\" [(ngModel)]=\"currentPermission.name\" />\n            </nz-form-control>\n        </nz-form-item>\n\n        <nz-form-item>\n            <nz-form-label [nzSm]=\"8\" [nzXs]=\"24\" nzRequired nzFor=\"email\">权限名称（中文）</nz-form-label>\n            <nz-form-control [nzSm]=\"12\" [nzXs]=\"24\">\n                <input style=\"width: 250px\" nz-input placeholder=\"请填写权限显示的名称\" [(ngModel)]=\"$any(currentPermission).title\" />\n            </nz-form-control>\n        </nz-form-item>\n    </div>\n</nz-modal>\n");

/***/ }),

/***/ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js":
/*!******************************************************!*\
  !*** ./node_modules/_tslib@2.0.3@tslib/tslib.es6.js ***!
  \******************************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, privateMap) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return privateMap.get(receiver);
}

function __classPrivateFieldSet(receiver, privateMap, value) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
    }
    privateMap.set(receiver, value);
    return value;
}


/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./layout/layout/layout.module": [
		"./src/app/layout/layout/layout.module.ts",
		"layout-layout-layout-module"
	],
	"./pages/home/home.module": [
		"./src/app/pages/home/home.module.ts",
		"pages-home-home-module"
	],
	"./pages/login/login.module": [
		"./src/app/pages/login/login.module.ts",
		"pages-login-login-module"
	],
	"./pages/welcome/welcome.module": [
		"./src/app/pages/welcome/welcome.module.ts",
		"pages-welcome-welcome-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _guard_login_can_enter_guard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./guard/login-can-enter.guard */ "./src/app/guard/login-can-enter.guard.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _guard_login_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./guard/login.guard */ "./src/app/guard/login.guard.ts");
/* harmony import */ var _guard_login_can_leave_guard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./guard/login-can-leave.guard */ "./src/app/guard/login-can-leave.guard.ts");






var routes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full',
    },
    {
        path: '',
        loadChildren: './pages/login/login.module#LoginPageModule',
        canDeactivate: [_guard_login_can_leave_guard__WEBPACK_IMPORTED_MODULE_5__["LoginCanLeaveGuard"]],
        canActivate: [_guard_login_can_enter_guard__WEBPACK_IMPORTED_MODULE_1__["LoginCanEnterGuard"]],
        data: { uid: 1, useCache: false },
    },
    { path: '', loadChildren: './layout/layout/layout.module#LayoutPageModule' },
    {
        path: '',
        loadChildren: './pages/home/home.module#HomePageModule',
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuard"]],
        data: { uid: 2, useCache: false },
    },
    {
        path: '',
        loadChildren: './pages/welcome/welcome.module#WelcomePageModule',
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuard"]],
        data: { uid: 1, useCache: false },
    },
    {
        path: '**',
        redirectTo: '/welcome',
        pathMatch: 'full',
    },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]],
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_user_limit_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/user-limit.service */ "./src/app/services/user-limit.service.ts");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/_@ionic-native_splash-screen@5.30.0@@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/_@ionic-native_status-bar@5.30.0@@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _layout_theme_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./layout/theme.service */ "./src/app/layout/theme.service.ts");
/* harmony import */ var _services_menu_permission_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./services/menu-permission.service */ "./src/app/services/menu-permission.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");













var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, baseData, Router, location, userLimit, effectCtrl, themeService, menuPermission) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.baseData = baseData;
        this.Router = Router;
        this.location = location;
        this.userLimit = userLimit;
        this.effectCtrl = effectCtrl;
        this.themeService = themeService;
        this.menuPermission = menuPermission;
        this.appPages = this.baseData.appPages;
        this.showMenu = true;
        this.loading = false;
        this.currentParentItem = {
            title: '',
            url: '',
            type: '',
            icon: '',
            active: null,
            limit: '',
        };
        this.currentSonItem = {
            title: '',
            url: '',
            type: '',
            icon: '',
            active: null,
            limit: '',
        };
        this.menuPermissionString = '';
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function (res) {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        //路由改变的时候执行是否显示菜单的方法
        this.Router.events.subscribe(function (event) {
            _this.showMenu = true;
            _this.showMenuFn();
        });
        var userInfo = sessionStorage.getItem('USERINFO') || null;
        var permissionList = JSON.parse(sessionStorage.getItem('PERMISSION')) || null;
        if (userInfo && permissionList) {
            userInfo = JSON.parse(userInfo);
            this.baseData.userInfo = userInfo;
            this.baseData.permissionList = permissionList;
            permissionList.forEach(function (element) {
                if (element.type === 'menu')
                    _this.menuPermission.permissions.push(element);
            });
            this.menuShowFn(); //bug
        }
        // 订阅loading
        this.baseData.valueUpdated.subscribe(function (val) {
            _this.loading = val;
        });
        this.baseData.menuChanged.subscribe(function (val) {
            _this.menuShowFn(); // bug
        });
        // 订阅自动展开菜单项
        this.baseData.autoExpandMenu.subscribe(function (menu) {
            _this.appPages.forEach(function (value) {
                if ('dashboard' + value.url === menu.url) {
                    _this.choice(value, menu.sonIndex);
                }
            });
        });
        this.themeService.theme.subscribe(function (res) {
            _this.theme = res;
        });
    };
    // 判断菜单显示
    AppComponent.prototype.menuShowFn = function () {
        var _this = this;
        this.menuPermission.permissions.forEach(function (permission) {
            _this.menuPermissionString += permission.name + '&';
        });
        var appPages = JSON.parse(JSON.stringify(this.baseData.appPages));
        for (var i = 0; i < appPages.length; i++) {
            var menu = appPages[i];
            if (menu.title != '主页' && menu.title != '退出') {
                if (menu.children && menu.children.length) {
                    var count = 0, childLength = menu.children.length;
                    if (menu.children.length)
                        menu.url = menu.children[0].url;
                    if (count == childLength) {
                        appPages.splice(i, 1);
                        i--;
                        count = 0;
                    }
                }
            }
        }
        this.appPages = this.filterMenu(appPages);
    };
    AppComponent.prototype.filterMenu = function (menus) {
        for (var i = 0; i < menus.length; i++) {
            if (menus[i].title === '主页' || menus[i].title === '退出')
                continue;
            if (this.menuPermissionString.indexOf(menus[i].limit) == -1) {
                menus.splice(i, 1);
                i--;
            }
            if (menus[i] && menus[i].children && menus[i].children.length) {
                this.filterMenu(menus[i].children);
            }
        }
        return menus;
    };
    AppComponent.prototype.showMenuFn = function () {
        for (var i = 0; i < this.baseData.notShowMenuPageArr.length; i++) {
            if (this.location.hash.match(this.baseData.notShowMenuPageArr[i]) != null) {
                this.showMenu = false;
                return;
            }
        }
    };
    AppComponent.prototype.menuBtn = function (p) {
        this.currentSonItem = p;
        var that = this;
        if (p.type == 'link') {
            this.Router.navigate([p.notModify ? p.url : '/dashboard/' + p.url]);
        }
        if (p.title == '退出') {
            this.effectCtrl.showAlert({
                message: '确定要退出吗？',
                header: '提示',
                buttons: [
                    {
                        text: '确定',
                        handler: function () {
                            sessionStorage.removeItem('USERINFO');
                            sessionStorage.removeItem('PERMISSION');
                            that.Router.navigate(['/login']);
                            Object(rxjs__WEBPACK_IMPORTED_MODULE_12__["timer"])(500)
                                .subscribe(function () {
                                location.reload();
                            });
                        },
                    },
                    {
                        text: '取消',
                    },
                ],
            });
        }
    };
    AppComponent.prototype.choice = function (item, sonIndex) {
        //sonIndex 为 自动展开菜单时 第几个子菜单展开
        if (item.children) {
            item.active = !item.active;
            this.menuBtn(item.children[sonIndex ? sonIndex : 0]);
        }
        this.currentParentItem = item;
        this.appPages.map(function (menu) {
            menu.children && (menu.active = false);
            item.active = true;
        });
        this.baseData.printDebug && console.log(item);
    };
    AppComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
        { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"] },
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__["PlatformLocation"] },
        { type: _services_user_limit_service__WEBPACK_IMPORTED_MODULE_1__["UserLimitService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] },
        { type: _layout_theme_service__WEBPACK_IMPORTED_MODULE_10__["ThemeService"] },
        { type: _services_menu_permission_service__WEBPACK_IMPORTED_MODULE_11__["MenuPermissionService"] }
    ]; };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-root',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
            _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"],
            _angular_common__WEBPACK_IMPORTED_MODULE_9__["PlatformLocation"],
            _services_user_limit_service__WEBPACK_IMPORTED_MODULE_1__["UserLimitService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"],
            _layout_theme_service__WEBPACK_IMPORTED_MODULE_10__["ThemeService"],
            _services_menu_permission_service__WEBPACK_IMPORTED_MODULE_11__["MenuPermissionService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/_@angular_platform-browser@8.2.14@@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _component_sku_desc_popup_sku_desc_popup_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./component/sku-desc-popup/sku-desc-popup.component */ "./src/app/component/sku-desc-popup/sku-desc-popup.component.ts");
/* harmony import */ var _component_confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./component/confirmed-popupbox/confirmed-popupbox.component */ "./src/app/component/confirmed-popupbox/confirmed-popupbox.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/_@angular_forms@8.2.14@@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/_@angular_platform-browser@8.2.14@@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/_@ionic-native_splash-screen@5.30.0@@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/_@ionic-native_status-bar@5.30.0@@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _services_interceptor_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./services/interceptor.service */ "./src/app/services/interceptor.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _share_share_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./share/share.module */ "./src/app/share/share.module.ts");
/* harmony import */ var _component_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./component/custom-popup/custom-popup.component */ "./src/app/component/custom-popup/custom-popup.component.ts");
/* harmony import */ var _pages_distrib_see_order_detail_distrib_see_order_detail_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./pages/distrib-see-order-detail/distrib-see-order-detail.component */ "./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common/locales/zh */ "./node_modules/_@angular_common@8.2.14@@angular/common/locales/zh.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _layout_layout_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./layout/layout/router */ "./src/app/layout/layout/router.ts");
/* harmony import */ var _component_confirmed_inspect_confirmed_inspect_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./component/confirmed-inspect/confirmed-inspect.component */ "./src/app/component/confirmed-inspect/confirmed-inspect.component.ts");
/* harmony import */ var _component_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./component/inspect-setting-box/inspect-setting-box.component */ "./src/app/component/inspect-setting-box/inspect-setting-box.component.ts");
/* harmony import */ var _component_edit_task_edit_task_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./component/edit-task/edit-task.component */ "./src/app/component/edit-task/edit-task.component.ts");




















/** 配置 angular i18n **/






Object(_angular_common__WEBPACK_IMPORTED_MODULE_15__["registerLocaleData"])(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_20___default.a);
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"],
                _component_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_17__["CustomPopupComponent"],
                _pages_distrib_see_order_detail_distrib_see_order_detail_component__WEBPACK_IMPORTED_MODULE_18__["DistribSeeOrderDetailComponent"],
                _component_confirmed_inspect_confirmed_inspect_component__WEBPACK_IMPORTED_MODULE_22__["confirmedInspectComponent"],
                _component_sku_desc_popup_sku_desc_popup_component__WEBPACK_IMPORTED_MODULE_2__["SkuDescPopupComponent"],
                _component_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_23__["InspectSettingBoxComponent"],
                _component_edit_task_edit_task_component__WEBPACK_IMPORTED_MODULE_24__["EditTaskComponent"],
            ],
            entryComponents: [
                _component_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_17__["CustomPopupComponent"],
                _component_sku_desc_popup_sku_desc_popup_component__WEBPACK_IMPORTED_MODULE_2__["SkuDescPopupComponent"],
                _pages_distrib_see_order_detail_distrib_see_order_detail_component__WEBPACK_IMPORTED_MODULE_18__["DistribSeeOrderDetailComponent"],
                _component_confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_3__["ConfirmedPopupBoxComponent"],
                _component_confirmed_inspect_confirmed_inspect_component__WEBPACK_IMPORTED_MODULE_22__["confirmedInspectComponent"],
                _component_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_23__["InspectSettingBoxComponent"],
                _component_edit_task_edit_task_component__WEBPACK_IMPORTED_MODULE_24__["EditTaskComponent"],
            ],
            imports: [
                ng_zorro_antd__WEBPACK_IMPORTED_MODULE_19__["NgZorroAntdModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_1__["BrowserAnimationsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonicModule"].forRoot(),
                _share_share_module__WEBPACK_IMPORTED_MODULE_16__["ShareModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_13__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_10__["SplashScreen"],
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HTTP_INTERCEPTORS"], useClass: _services_interceptor_service__WEBPACK_IMPORTED_MODULE_14__["DefaultInterceptor"], multi: true },
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouteReuseStrategy"], useClass: _layout_layout_router__WEBPACK_IMPORTED_MODULE_21__["SimpleReuseStrategy"] },
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_15__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_15__["HashLocationStrategy"] },
                { provide: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_19__["NZ_I18N"], useValue: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_19__["zh_CN"] },
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"]],
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/component/commit-reply/commit-reply.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/component/commit-reply/commit-reply.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("::ng-deep .ant-comment-inner {\n  padding: 0 !important; }\n\n:host ::ng-deep img {\n  border: 1px solid #ccc !important; }\n\n#screen {\n  border-bottom: 1px solid #d4d4d4;\n  border-right: 1px solid #d4d4d4;\n  border-left: 1px solid #d4d4d4;\n  padding: 15px;\n  box-sizing: border-box; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9jb21taXQtcmVwbHkvY29tbWl0LXJlcGx5LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQXFCLEVBQUE7O0FBR3pCO0VBQ0ksaUNBQWlDLEVBQUE7O0FBR3JDO0VBQ0ksZ0NBQWdDO0VBQ2hDLCtCQUE4QjtFQUM5Qiw4QkFBNkI7RUFDN0IsYUFBYTtFQUNiLHNCQUFzQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L2NvbW1pdC1yZXBseS9jb21taXQtcmVwbHkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAgLmFudC1jb21tZW50LWlubmVye1xuICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIGltZ3tcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2NjICFpbXBvcnRhbnQ7XG59XG5cbiNzY3JlZW57XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkNGQ0ZDQ7XG4gICAgYm9yZGVyLXJpZ2h0OjFweCBzb2xpZCAjZDRkNGQ0O1xuICAgIGJvcmRlci1sZWZ0OjFweCBzb2xpZCAjZDRkNGQ0O1xuICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/component/commit-reply/commit-reply.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/component/commit-reply/commit-reply.component.ts ***!
  \******************************************************************/
/*! exports provided: CommitReplyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommitReplyComponent", function() { return CommitReplyComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_commit_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/commit.service */ "./src/app/services/commit.service.ts");
/* harmony import */ var src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/operators/index.js");
/* harmony import */ var src_app_services_oa_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/oa.service */ "./src/app/services/oa.service.ts");






var CommitReplyComponent = /** @class */ (function () {
    function CommitReplyComponent(commitCtrl, baseData, oa) {
        this.commitCtrl = commitCtrl;
        this.baseData = baseData;
        this.oa = oa;
        this._data = null;
        this.currentComment = {};
        this.defaultMessage = null;
        this.pushComplete = false;
        this.oaToken = '';
        this.index = null;
        this.onReply = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onComplete = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    Object.defineProperty(CommitReplyComponent.prototype, "data", {
        set: function (input) {
            if (!!input) {
                this._data = input;
            }
        },
        enumerable: true,
        configurable: true
    });
    CommitReplyComponent.prototype.ngOnInit = function () { };
    CommitReplyComponent.prototype.ngAfterViewInit = function () { };
    CommitReplyComponent.prototype.getToke = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var data;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.oa.getToken()];
                    case 1:
                        data = (_a.sent()).data;
                        this.oaToken = data;
                        this.getOaUserInfo('XD118').then(function (res) {
                            console.log(res);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    CommitReplyComponent.prototype.getOaUserInfo = function (oa) {
        return this.oa.getUserInfo(oa, this.oaToken);
    };
    CommitReplyComponent.prototype.reply = function (p) {
        this.pushComplete = false;
        this.commitCtrl.index = this.index;
        this.currentComment = p;
    };
    CommitReplyComponent.prototype.editorDataComplete = function (e, id) {
        var _this = this;
        var active = true;
        //此处id为null只有跟节点的时候
        var data = { content: e, id: id };
        this.onComplete.emit(data);
        this.pushComplete = !this.pushComplete;
        this.commitCtrl.currentKey$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["takeWhile"])(function () { return active; })).subscribe(function (res) {
            _this.insertTree(id, e, [_this._data], res);
            active = false;
        });
    };
    CommitReplyComponent.prototype.insertTree = function (id, content, tree, targetId) {
        var _this = this;
        var treeItem = {
            apply_inspection_no: this.commitCtrl.applyInspectNo,
            contents: content,
            created_at: new Date().getTime(),
            id: targetId,
            pid: null,
            sku: this.commitCtrl.Sku,
            updated_at: new Date().getTime(),
            user: { id: this.baseData.userInfo.id, name: this.baseData.userInfo.name },
            user_id: this.baseData.userInfo.id,
        };
        tree.forEach(function (item) {
            if (item.id === id) {
                if (item.son && item.son.length) {
                    treeItem.pid = item.id;
                    item.son.push(treeItem);
                    return;
                }
                else {
                    treeItem.pid = item.id;
                    item.son = [treeItem];
                }
                return;
            }
            else {
                item.son && item.son.length && _this.insertTree(id, content, item.son, targetId);
            }
        });
    };
    CommitReplyComponent.ctorParameters = function () { return [
        { type: src_app_services_commit_service__WEBPACK_IMPORTED_MODULE_2__["CommitService"] },
        { type: src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"] },
        { type: src_app_services_oa_service__WEBPACK_IMPORTED_MODULE_5__["OaService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], CommitReplyComponent.prototype, "data", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], CommitReplyComponent.prototype, "index", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], CommitReplyComponent.prototype, "onReply", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], CommitReplyComponent.prototype, "onComplete", void 0);
    CommitReplyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-commit-reply',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./commit-reply.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/commit-reply/commit-reply.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./commit-reply.component.scss */ "./src/app/component/commit-reply/commit-reply.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_commit_service__WEBPACK_IMPORTED_MODULE_2__["CommitService"], src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"], src_app_services_oa_service__WEBPACK_IMPORTED_MODULE_5__["OaService"]])
    ], CommitReplyComponent);
    return CommitReplyComponent;
}());



/***/ }),

/***/ "./src/app/component/component.module.ts":
/*!***********************************************!*\
  !*** ./src/app/component/component.module.ts ***!
  \***********************************************/
/*! exports provided: ComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentModule", function() { return ComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _funnel_funnel_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./funnel/funnel.component */ "./src/app/component/funnel/funnel.component.ts");
/* harmony import */ var _reply_mode_reply_mode_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reply-mode/reply-mode.component */ "./src/app/component/reply-mode/reply-mode.component.ts");
/* harmony import */ var _commit_reply_commit_reply_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./commit-reply/commit-reply.component */ "./src/app/component/commit-reply/commit-reply.component.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _track_exclude_track_exclude_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./track-exclude/track-exclude.component */ "./src/app/component/track-exclude/track-exclude.component.ts");
/* harmony import */ var _confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./confirmed-popupbox/confirmed-popupbox.component */ "./src/app/component/confirmed-popupbox/confirmed-popupbox.component.ts");
/* harmony import */ var _td_overflow_text_td_overflow_text_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./td-overflow-text/td-overflow-text.component */ "./src/app/component/td-overflow-text/td-overflow-text.component.ts");
/* harmony import */ var _loadding_loadding_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./loadding/loadding.component */ "./src/app/component/loadding/loadding.component.ts");
/* harmony import */ var _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pagination/pagination.component */ "./src/app/component/pagination/pagination.component.ts");
/* harmony import */ var _sort_sort_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./sort/sort.component */ "./src/app/component/sort/sort.component.ts");
/* harmony import */ var _directive_directive_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./../directive/directive.module */ "./src/app/directive/directive.module.ts");
/* harmony import */ var _progress_progress_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./progress/progress.component */ "./src/app/component/progress/progress.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ng2-file-upload */ "./node_modules/_ng2-file-upload@1.4.0@ng2-file-upload/fesm5/ng2-file-upload.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ "./node_modules/_@angular_forms@8.2.14@@angular/forms/fesm5/forms.js");
/* harmony import */ var _uploadimg_uploadimg_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./uploadimg/uploadimg.component */ "./src/app/component/uploadimg/uploadimg.component.ts");
/* harmony import */ var _no_data_show_no_data_show_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./no-data-show/no-data-show.component */ "./src/app/component/no-data-show/no-data-show.component.ts");
/* harmony import */ var _reply_reply_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./reply/reply.component */ "./src/app/component/reply/reply.component.ts");
/* harmony import */ var _pipe_compare_text_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../pipe/compare-text.pipe */ "./src/app/pipe/compare-text.pipe.ts");
/* harmony import */ var _permission_tree_permission_tree_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./permission-tree/permission-tree.component */ "./src/app/component/permission-tree/permission-tree.component.ts");
/* harmony import */ var _sku_info_sku_info_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./sku-info/sku-info.component */ "./src/app/component/sku-info/sku-info.component.ts");
/* harmony import */ var _editor_editor_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./editor/editor.component */ "./src/app/component/editor/editor.component.ts");

























var ComponentModule = /** @class */ (function () {
    function ComponentModule() {
    }
    ComponentModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_13__["NgModule"])({
            declarations: [
                _progress_progress_component__WEBPACK_IMPORTED_MODULE_12__["ProgressComponent"],
                _sort_sort_component__WEBPACK_IMPORTED_MODULE_10__["SortComponent"],
                _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_9__["PaginationComponent"],
                _uploadimg_uploadimg_component__WEBPACK_IMPORTED_MODULE_18__["UploadimgComponent"],
                _loadding_loadding_component__WEBPACK_IMPORTED_MODULE_8__["LoaddingComponent"],
                _no_data_show_no_data_show_component__WEBPACK_IMPORTED_MODULE_19__["NoDataShowComponent"],
                _td_overflow_text_td_overflow_text_component__WEBPACK_IMPORTED_MODULE_7__["TdOverflowTextComponent"],
                _confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_6__["ConfirmedPopupBoxComponent"],
                _track_exclude_track_exclude_component__WEBPACK_IMPORTED_MODULE_5__["TrackExcludeComponent"],
                _reply_reply_component__WEBPACK_IMPORTED_MODULE_20__["ReplyComponent"],
                _reply_mode_reply_mode_component__WEBPACK_IMPORTED_MODULE_2__["ReplyModeComponent"],
                _funnel_funnel_component__WEBPACK_IMPORTED_MODULE_1__["FunnelComponent"],
                _pipe_compare_text_pipe__WEBPACK_IMPORTED_MODULE_21__["CompareTextPipe"],
                _permission_tree_permission_tree_component__WEBPACK_IMPORTED_MODULE_22__["PermissionTreeComponent"],
                _sku_info_sku_info_component__WEBPACK_IMPORTED_MODULE_23__["SkuInfoComponent"],
                _commit_reply_commit_reply_component__WEBPACK_IMPORTED_MODULE_3__["CommitReplyComponent"],
                _editor_editor_component__WEBPACK_IMPORTED_MODULE_24__["EditorComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_14__["CommonModule"],
                _directive_directive_module__WEBPACK_IMPORTED_MODULE_11__["DirectiveModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_15__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_17__["FormsModule"],
                ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__["NgZorroAntdModule"],
                ng2_file_upload__WEBPACK_IMPORTED_MODULE_16__["FileUploadModule"],
            ],
            exports: [
                _progress_progress_component__WEBPACK_IMPORTED_MODULE_12__["ProgressComponent"],
                _sort_sort_component__WEBPACK_IMPORTED_MODULE_10__["SortComponent"],
                _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_9__["PaginationComponent"],
                _uploadimg_uploadimg_component__WEBPACK_IMPORTED_MODULE_18__["UploadimgComponent"],
                _loadding_loadding_component__WEBPACK_IMPORTED_MODULE_8__["LoaddingComponent"],
                _no_data_show_no_data_show_component__WEBPACK_IMPORTED_MODULE_19__["NoDataShowComponent"],
                _td_overflow_text_td_overflow_text_component__WEBPACK_IMPORTED_MODULE_7__["TdOverflowTextComponent"],
                _confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_6__["ConfirmedPopupBoxComponent"],
                _track_exclude_track_exclude_component__WEBPACK_IMPORTED_MODULE_5__["TrackExcludeComponent"],
                _reply_reply_component__WEBPACK_IMPORTED_MODULE_20__["ReplyComponent"],
                _reply_mode_reply_mode_component__WEBPACK_IMPORTED_MODULE_2__["ReplyModeComponent"],
                _funnel_funnel_component__WEBPACK_IMPORTED_MODULE_1__["FunnelComponent"],
                _pipe_compare_text_pipe__WEBPACK_IMPORTED_MODULE_21__["CompareTextPipe"],
                _permission_tree_permission_tree_component__WEBPACK_IMPORTED_MODULE_22__["PermissionTreeComponent"],
                _sku_info_sku_info_component__WEBPACK_IMPORTED_MODULE_23__["SkuInfoComponent"],
                _commit_reply_commit_reply_component__WEBPACK_IMPORTED_MODULE_3__["CommitReplyComponent"],
                _editor_editor_component__WEBPACK_IMPORTED_MODULE_24__["EditorComponent"]
            ],
            providers: [ng_zorro_antd__WEBPACK_IMPORTED_MODULE_4__["NzTreeService"]],
        })
    ], ComponentModule);
    return ComponentModule;
}());



/***/ }),

/***/ "./src/app/component/confirmed-inspect/confirmed-inspect.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/component/confirmed-inspect/confirmed-inspect.component.scss ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".close-box {\n  background: #fff;\n  z-index: 200002;\n  box-shadow: 2px 2px 10px #555;\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n  height: 55px;\n  width: 100%;\n  position: fixed;\n  top: 0;\n  padding: 0 10px;\n  left: 0; }\n\n.swiper-container {\n  margin-top: 60px;\n  padding-bottom: 40px; }\n\n.swiper-container .swiper-slide {\n    width: 1340px;\n    min-width: 1000px; }\n\ntd {\n  border: 1px solid #cecece;\n  box-sizing: border-box !important;\n  height: 36px; }\n\n#table1 {\n  width: 1340px; }\n\ntable {\n  border-collapse: collapse;\n  text-align: center;\n  padding: 0;\n  word-break: break-all; }\n\ntable thead td {\n  border: 1px solid #cecece; }\n\ntable tbody td {\n  border-bottom: 1px solid #cecece; }\n\n.table2 tr td:nth-child(1) {\n  border-left: 0; }\n\n.table2 tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.table2 tr:nth-child(1) td {\n  border-top: 0; }\n\n.table2 tr:nth-last-child(1) td {\n  border-bottom: 0; }\n\ntd {\n  padding: 0 !important;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden; }\n\n.table2 td,\n.three-table td {\n  height: 36px; }\n\n.w20 {\n  width: 20px !important;\n  overflow: hidden; }\n\n.w50 {\n  width: 50px !important;\n  overflow: hidden; }\n\n.w30 {\n  width: 30px !important;\n  overflow: hidden; }\n\n.w60 {\n  width: 60px !important;\n  overflow: hidden; }\n\n.w40 {\n  width: 40px !important;\n  overflow: hidden; }\n\n.w70 {\n  width: 70px !important;\n  overflow: hidden; }\n\n.w80 {\n  width: 80px !important;\n  overflow: hidden; }\n\n.w90 {\n  width: 90px !important;\n  overflow: hidden; }\n\n.w100 {\n  width: 100px !important;\n  overflow: hidden; }\n\n.w120 {\n  width: 120px !important;\n  overflow: hidden; }\n\n.w110 {\n  width: 110px !important;\n  overflow: hidden; }\n\n.w220 {\n  width: 220px !important;\n  overflow: hidden; }\n\n.w230 {\n  width: 230px !important;\n  overflow: hidden; }\n\n.w150 {\n  width: 150px !important;\n  overflow: hidden; }\n\n.w200 {\n  width: 200px !important;\n  overflow: hidden; }\n\n.bot-box {\n  padding: 0 10px;\n  height: 40px;\n  background: #fff;\n  z-index: 200002;\n  box-shadow: 2px 2px 10px #555;\n  position: fixed;\n  bottom: 0;\n  width: 100%; }\n\n.probable-date-div {\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9jb25maXJtZWQtaW5zcGVjdC9jb25maXJtZWQtaW5zcGVjdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIseUJBQXlCO0VBQ3pCLFlBQVk7RUFDWixXQUFXO0VBQ1gsZUFBZTtFQUNmLE1BQU07RUFDTixlQUFlO0VBQ2YsT0FBTyxFQUFBOztBQUdYO0VBQ0ksZ0JBQWdCO0VBQ2hCLG9CQUFvQixFQUFBOztBQUZ4QjtJQUlRLGFBQWE7SUFDYixpQkFBaUIsRUFBQTs7QUFJekI7RUFDSSx5QkFBeUI7RUFDekIsaUNBQWlDO0VBQ2pDLFlBQVksRUFBQTs7QUFFaEI7RUFDSSxhQUFhLEVBQUE7O0FBR2pCO0VBQ0kseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1YscUJBQXFCLEVBQUE7O0FBRXpCO0VBQ0kseUJBQXlCLEVBQUE7O0FBRzdCO0VBQ0ksZ0NBQWdDLEVBQUE7O0FBRXBDO0VBQ0ksY0FBYyxFQUFBOztBQUVsQjtFQUNJLGVBQWUsRUFBQTs7QUFFbkI7RUFDSSxhQUFhLEVBQUE7O0FBRWpCO0VBQ0ksZ0JBQWdCLEVBQUE7O0FBRXBCO0VBQ0kscUJBQXFCO0VBRXJCLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBRXBCOztFQUdRLFlBQVksRUFBQTs7QUFJcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFFcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFFcEI7RUFDSSxlQUFlO0VBQ2YsWUFBWTtFQUNaLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLGVBQWU7RUFDZixTQUFTO0VBQ1QsV0FBVyxFQUFBOztBQUdmO0VBQ0ksTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9jb25maXJtZWQtaW5zcGVjdC9jb25maXJtZWQtaW5zcGVjdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jbG9zZS1ib3gge1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgei1pbmRleDogMjAwMDAyO1xuICAgIGJveC1zaGFkb3c6IDJweCAycHggMTBweCAjNTU1O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIGhlaWdodDogNTVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICBsZWZ0OiAwO1xufVxuXG4uc3dpcGVyLWNvbnRhaW5lciB7XG4gICAgbWFyZ2luLXRvcDogNjBweDtcbiAgICBwYWRkaW5nLWJvdHRvbTogNDBweDtcbiAgICAuc3dpcGVyLXNsaWRlIHtcbiAgICAgICAgd2lkdGg6IDEzNDBweDtcbiAgICAgICAgbWluLXdpZHRoOiAxMDAwcHg7XG4gICAgfVxufVxuXG50ZCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NlY2VjZTtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94ICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiAzNnB4O1xufVxuI3RhYmxlMSB7XG4gICAgd2lkdGg6IDEzNDBweDtcbn1cblxudGFibGUge1xuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgd29yZC1icmVhazogYnJlYWstYWxsO1xufVxudGFibGUgdGhlYWQgdGQge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjZWNlY2U7XG59XG5cbnRhYmxlIHRib2R5IHRkIHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NlY2VjZTtcbn1cbi50YWJsZTIgdHIgdGQ6bnRoLWNoaWxkKDEpIHtcbiAgICBib3JkZXItbGVmdDogMDtcbn1cbi50YWJsZTIgdHIgdGQ6bnRoLWxhc3QtY2hpbGQoMSkge1xuICAgIGJvcmRlci1yaWdodDogMDtcbn1cbi50YWJsZTIgdHI6bnRoLWNoaWxkKDEpIHRkIHtcbiAgICBib3JkZXItdG9wOiAwO1xufVxuLnRhYmxlMiB0cjpudGgtbGFzdC1jaGlsZCgxKSB0ZCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbn1cbnRkIHtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgLy8gb3ZlcmZsb3c6IHVuc2V0ICFpbXBvcnRhbnQ7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLnRhYmxlMixcbi50aHJlZS10YWJsZSB7XG4gICAgdGQge1xuICAgICAgICBoZWlnaHQ6IDM2cHg7XG4gICAgfVxufVxuXG4udzIwIHtcbiAgICB3aWR0aDogMjBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53NTAge1xuICAgIHdpZHRoOiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnczMCB7XG4gICAgd2lkdGg6IDMwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzYwIHtcbiAgICB3aWR0aDogNjBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53NDAge1xuICAgIHdpZHRoOiA0MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnc3MCB7XG4gICAgd2lkdGg6IDcwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzgwIHtcbiAgICB3aWR0aDogODBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53OTAge1xuICAgIHdpZHRoOiA5MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLncxMDAge1xuICAgIHdpZHRoOiAxMDBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MTIwIHtcbiAgICB3aWR0aDogMTIwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzExMCB7XG4gICAgd2lkdGg6IDExMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLncyMjAge1xuICAgIHdpZHRoOiAyMjBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG4udzIzMCB7XG4gICAgd2lkdGg6IDIzMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLncxNTAge1xuICAgIHdpZHRoOiAxNTBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MjAwIHtcbiAgICB3aWR0aDogMjAwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLmJvdC1ib3gge1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICB6LWluZGV4OiAyMDAwMDI7XG4gICAgYm94LXNoYWRvdzogMnB4IDJweCAxMHB4ICM1NTU7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogMDtcbiAgICB3aWR0aDogMTAwJTtcbn1cblxuLnByb2JhYmxlLWRhdGUtZGl2IHtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuIl19 */");

/***/ }),

/***/ "./src/app/component/confirmed-inspect/confirmed-inspect.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/component/confirmed-inspect/confirmed-inspect.component.ts ***!
  \****************************************************************************/
/*! exports provided: confirmedInspectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "confirmedInspectComponent", function() { return confirmedInspectComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _pages_create_inspec_batch_create_inspec_batch_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../pages/create-inspec-batch/create-inspec-batch.page */ "./src/app/pages/create-inspec-batch/create-inspec-batch.page.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");






var confirmedInspectComponent = /** @class */ (function () {
    function confirmedInspectComponent(baseData, effectCtrl, inspectService) {
        this.baseData = baseData;
        this.effectCtrl = effectCtrl;
        this.inspectService = inspectService;
        this.swiperConfig = {};
        this.currentHoverItem = { id: null };
    }
    confirmedInspectComponent.prototype.ngOnInit = function () {
        this.group = [this.group];
        // this.createInspecBatch = CreateInspecBatchPage
    };
    confirmedInspectComponent.prototype.ionViewWillEnter = function () {
        this.swiperConfig = this.baseData.utilFn.getSwiperPublicConfig();
    };
    confirmedInspectComponent.prototype.enterReceiving = function () {
        var _this = this;
        this.inspectService.confirmationOfReceipt({ inspection_group_id: this.group[0].id }).subscribe(function (data) {
            _this.effectCtrl.showAlert({
                header: '提示',
                message: data.message,
            });
            if (data.status == 1) {
                _this.effectCtrl.modalCtrl.dismiss({
                    refresh: true,
                });
            }
        });
    };
    confirmedInspectComponent.ctorParameters = function () { return [
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] },
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__["InspectionService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('createInspecBatch', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _pages_create_inspec_batch_create_inspec_batch_page__WEBPACK_IMPORTED_MODULE_3__["CreateInspecBatchPage"])
    ], confirmedInspectComponent.prototype, "createInspecBatch", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], confirmedInspectComponent.prototype, "group", void 0);
    confirmedInspectComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-confirmed-inspect',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./confirmed-inspect.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/confirmed-inspect/confirmed-inspect.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./confirmed-inspect.component.scss */ "./src/app/component/confirmed-inspect/confirmed-inspect.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"],
            src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__["InspectionService"]])
    ], confirmedInspectComponent);
    return confirmedInspectComponent;
}());



/***/ }),

/***/ "./src/app/component/confirmed-popupbox/confirmed-popupbox.component.scss":
/*!********************************************************************************!*\
  !*** ./src/app/component/confirmed-popupbox/confirmed-popupbox.component.scss ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-list {\n  width: 47%; }\n  ion-list ion-label,\n  ion-list ion-text {\n    font-size: 14px; }\n  ion-list:first-child {\n  margin-right: 5%; }\n  .root {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9jb25maXJtZWQtcG9wdXBib3gvY29uZmlybWVkLXBvcHVwYm94LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksVUFBVSxFQUFBO0VBRGQ7O0lBSVEsZUFBZSxFQUFBO0VBSXZCO0VBQ0ksZ0JBQWdCLEVBQUE7RUFHcEI7RUFDSSxXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnQvY29uZmlybWVkLXBvcHVwYm94L2NvbmZpcm1lZC1wb3B1cGJveC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1saXN0IHtcbiAgICB3aWR0aDogNDclO1xuICAgIGlvbi1sYWJlbCxcbiAgICBpb24tdGV4dCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICB9XG59XG5cbmlvbi1saXN0OmZpcnN0LWNoaWxkIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG4ucm9vdCB7XG4gICAgd2lkdGg6IDEwMCU7XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/component/confirmed-popupbox/confirmed-popupbox.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/component/confirmed-popupbox/confirmed-popupbox.component.ts ***!
  \******************************************************************************/
/*! exports provided: ConfirmedPopupBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfirmedPopupBoxComponent", function() { return ConfirmedPopupBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var ConfirmedPopupBoxComponent = /** @class */ (function () {
    function ConfirmedPopupBoxComponent() {
    }
    ConfirmedPopupBoxComponent.prototype.ngOnInit = function () {
        console.log(this.contract);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ConfirmedPopupBoxComponent.prototype, "contract", void 0);
    ConfirmedPopupBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-confirmed-popupbox',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./confirmed-popupbox.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/confirmed-popupbox/confirmed-popupbox.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./confirmed-popupbox.component.scss */ "./src/app/component/confirmed-popupbox/confirmed-popupbox.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ConfirmedPopupBoxComponent);
    return ConfirmedPopupBoxComponent;
}());



/***/ }),

/***/ "./src/app/component/custom-popup/custom-popup.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/component/custom-popup/custom-popup.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".clearfix:after {\n  content: '';\n  display: block;\n  clear: both; }\n\n.box {\n  width: 100%;\n  box-sizing: border-box;\n  height: 100%; }\n\n.box td {\n    background: #fff !important; }\n\n.box tr:nth-child(1n + 0) {\n    background: #fff; }\n\n.file-image {\n  top: 0;\n  left: 0;\n  opacity: 0;\n  width: 100%; }\n\n.load-img img {\n  width: 35px;\n  height: 35px !important; }\n\n.pd-0 {\n  padding: 0 !important; }\n\n.pb-80 {\n  padding-bottom: 80px; }\n\n.box.has-mb > div {\n  margin-bottom: 80px !important; }\n\n.f-r {\n  float: right; }\n\n.close-box {\n  background: #fff;\n  z-index: 200002;\n  box-shadow: 2px 2px 10px #555;\n  height: 55px;\n  width: 100%;\n  position: fixed;\n  top: 0;\n  padding: 0 10px;\n  line-height: 55px;\n  left: 0; }\n\n.close-box > div {\n    display: flex;\n    justify-content: start;\n    align-items: center; }\n\n.close-box::after {\n  content: '';\n  display: block;\n  clear: both; }\n\n.no-data {\n  text-align: center;\n  margin-top: 50px; }\n\n.table {\n  width: auto;\n  min-width: 100%;\n  color: #666;\n  text-align: center; }\n\n.table thead {\n    padding: 10px 0;\n    border-top: 1px solid #666;\n    border-bottom: 1px solid #666; }\n\n.table td {\n    padding: 1px !important;\n    text-align: center;\n    vertical-align: middle !important; }\n\n.table td input {\n      width: 100px;\n      text-align: center;\n      height: 50px; }\n\n.table td.remark {\n    text-align: left; }\n\n.table td.remark ion-textarea {\n      border-radius: 5px;\n      border: 1px double #ccc;\n      width: 120px;\n      height: 60px; }\n\n.table .uploadfile .pos-r {\n    overflow: hidden; }\n\n.table .uploadfile .pos-r input[type='file'] {\n      opacity: 0;\n      font-size: 100px;\n      top: 0;\n      left: 0; }\n\n.table .uploadfile .img-responsive {\n    height: 50px !important; }\n\n.text-c {\n  text-align: center; }\n\n.bot-box {\n  padding: 0 10px;\n  height: 80px;\n  background: #fff;\n  z-index: 200002;\n  box-shadow: 2px 2px 10px #555;\n  position: fixed;\n  bottom: 0;\n  width: 100%; }\n\n.bot-box .choice-date {\n    background: #f3f3f3;\n    color: #555;\n    font-weight: bold;\n    border-radius: 3px;\n    display: flex;\n    align-items: center;\n    justify-content: flex-start; }\n\n.bot-box .choice-date ion-datetime {\n      --padding-end: 20px;\n      border-radius: 5px; }\n\n.thumbnail {\n  width: 40px;\n  margin-bottom: 0 !important;\n  height: 40px; }\n\nh6 {\n  color: #555; }\n\n.select-text-c {\n  text-align: center;\n  -moz-text-align-last: center;\n       text-align-last: center; }\n\n.wd-50 {\n  width: 50px;\n  height: 50px !important; }\n\n.wd-5 {\n  height: 50px !important;\n  width: 5px; }\n\n.hg-0 {\n  height: 0px; }\n\n.wd-he-150 {\n  width: 100px;\n  display: inline;\n  height: 50px; }\n\n.control-label {\n  width: 100px;\n  padding: 0; }\n\n.flex-layout {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start; }\n\n.desc-item {\n  display: flex;\n  justify-content: flex-start;\n  align-items: center; }\n\n.desc-item input {\n    width: 200px !important;\n    height: 30px !important;\n    line-height: 30px;\n    text-align: left; }\n\n.desc-item button {\n    margin-top: 3px; }\n\n.desc-show {\n  width: 100px; }\n\n.desc-item::after {\n  content: '';\n  display: block;\n  clear: both; }\n\n.container {\n  overflow: hidden;\n  width: 100%;\n  position: absolute;\n  height: calc(100% - 135px);\n  top: 55px;\n  box-sizing: border-box; }\n\nion-content {\n  overflow: hidden; }\n\np {\n  margin-bottom: 0 !important; }\n\n.mr-20 {\n  margin-right: 20px !important; }\n\n#fixed-thead {\n  position: relative;\n  z-index: 999; }\n\n.ant-input-group {\n  position: static !important; }\n\n.ant-input {\n  position: static !important; }\n\nion-button .button-native {\n  position: static !important; }\n\n.ant-btn {\n  position: static !important; }\n\n.sc-ion-textarea-md-h {\n  position: static !important; }\n\n.w100 {\n  width: 100px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9jdXN0b20tcG9wdXAvY3VzdG9tLXBvcHVwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBVztFQUNYLGNBQWM7RUFDZCxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxXQUFXO0VBQ1gsc0JBQXNCO0VBQ3RCLFlBQVksRUFBQTs7QUFIaEI7SUFNUSwyQkFBMkIsRUFBQTs7QUFObkM7SUFTUSxnQkFBZ0IsRUFBQTs7QUFJeEI7RUFDSSxNQUFNO0VBQ04sT0FBTztFQUNQLFVBQVU7RUFDVixXQUFXLEVBQUE7O0FBR2Y7RUFFUSxXQUFXO0VBQ1gsdUJBQXVCLEVBQUE7O0FBSS9CO0VBQ0kscUJBQXFCLEVBQUE7O0FBR3pCO0VBQ0ksb0JBQW9CLEVBQUE7O0FBR3hCO0VBRVEsOEJBQThCLEVBQUE7O0FBSXRDO0VBQ0ksWUFBWSxFQUFBOztBQUVoQjtFQUNJLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLFlBQVk7RUFDWixXQUFXO0VBQ1gsZUFBZTtFQUNmLE1BQU07RUFDTixlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLE9BQU8sRUFBQTs7QUFWWDtJQVlRLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsbUJBQW1CLEVBQUE7O0FBRzNCO0VBQ0ksV0FBVztFQUNYLGNBQWM7RUFDZCxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxrQkFBa0I7RUFDbEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksV0FBVztFQUNYLGVBQWU7RUFDZixXQUFXO0VBQ1gsa0JBQWtCLEVBQUE7O0FBSnRCO0lBTVEsZUFBZTtJQUNmLDBCQUEwQjtJQUMxQiw2QkFBNkIsRUFBQTs7QUFSckM7SUFXUSx1QkFBdUI7SUFDdkIsa0JBQWtCO0lBQ2xCLGlDQUFpQyxFQUFBOztBQWJ6QztNQWVZLFlBQVk7TUFDWixrQkFBa0I7TUFDbEIsWUFBWSxFQUFBOztBQWpCeEI7SUFxQlEsZ0JBQWdCLEVBQUE7O0FBckJ4QjtNQXVCWSxrQkFBa0I7TUFDbEIsdUJBQXVCO01BQ3ZCLFlBQVk7TUFDWixZQUFZLEVBQUE7O0FBMUJ4QjtJQStCWSxnQkFBZ0IsRUFBQTs7QUEvQjVCO01BaUNnQixVQUFVO01BQ1YsZ0JBQWdCO01BQ2hCLE1BQU07TUFDTixPQUFPLEVBQUE7O0FBcEN2QjtJQXdDWSx1QkFBdUIsRUFBQTs7QUFJbkM7RUFDSSxrQkFBa0IsRUFBQTs7QUFHdEI7RUFDSSxlQUFlO0VBQ2YsWUFBWTtFQUNaLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLGVBQWU7RUFDZixTQUFTO0VBQ1QsV0FBVyxFQUFBOztBQVJmO0lBVVEsbUJBQW1CO0lBQ25CLFdBQVc7SUFDWCxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixtQkFBbUI7SUFDbkIsMkJBQTJCLEVBQUE7O0FBaEJuQztNQWtCWSxtQkFBYztNQUNkLGtCQUFrQixFQUFBOztBQUs5QjtFQUNJLFdBQVc7RUFDWCwyQkFBMkI7RUFDM0IsWUFBWSxFQUFBOztBQUdoQjtFQUVJLFdBQVcsRUFBQTs7QUFHZjtFQUNJLGtCQUFrQjtFQUVsQiw0QkFBdUI7T0FBdkIsdUJBQXVCLEVBQUE7O0FBRTNCO0VBQ0ksV0FBVztFQUNYLHVCQUF1QixFQUFBOztBQUUzQjtFQUNJLHVCQUF1QjtFQUN2QixVQUFVLEVBQUE7O0FBRWQ7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxZQUFZO0VBQ1osZUFBZTtFQUNmLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxZQUFZO0VBQ1osVUFBVSxFQUFBOztBQUdkO0VBQ0ksYUFBYTtFQUNiLG1CQUFtQjtFQUNuQiwyQkFBMkIsRUFBQTs7QUFHL0I7RUFDSSxhQUFhO0VBQ2IsMkJBQTJCO0VBQzNCLG1CQUFtQixFQUFBOztBQUh2QjtJQUtRLHVCQUF1QjtJQUN2Qix1QkFBdUI7SUFDdkIsaUJBQWlCO0lBQ2pCLGdCQUFnQixFQUFBOztBQVJ4QjtJQVdRLGVBQWUsRUFBQTs7QUFJdkI7RUFDSSxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksV0FBVztFQUNYLGNBQWM7RUFDZCxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLGtCQUFrQjtFQUNsQiwwQkFBMEI7RUFDMUIsU0FBUztFQUNULHNCQUFzQixFQUFBOztBQUcxQjtFQUNJLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLDJCQUEyQixFQUFBOztBQUcvQjtFQUNJLDZCQUE2QixFQUFBOztBQUVqQztFQUNJLGtCQUFrQjtFQUNsQixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksMkJBQTJCLEVBQUE7O0FBRy9CO0VBQ0ksMkJBQTJCLEVBQUE7O0FBRy9CO0VBQ0ksMkJBQTJCLEVBQUE7O0FBRy9CO0VBQ0ksMkJBQTJCLEVBQUE7O0FBRy9CO0VBQ0ksMkJBQTJCLEVBQUE7O0FBRy9CO0VBQ0ksdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnQvY3VzdG9tLXBvcHVwL2N1c3RvbS1wb3B1cC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jbGVhcmZpeDphZnRlciB7XG4gICAgY29udGVudDogJyc7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgY2xlYXI6IGJvdGg7XG59XG5cbi5ib3gge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC8vIG92ZXJmbG93OiBzY3JvbGw7XG4gICAgdGQge1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIHRyOm50aC1jaGlsZCgxbiArIDApIHtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICB9XG59XG5cbi5maWxlLWltYWdlIHtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHdpZHRoOiAxMDAlO1xufVxuXG4ubG9hZC1pbWcge1xuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAzNXB4O1xuICAgICAgICBoZWlnaHQ6IDM1cHggIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5wZC0wIHtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5wYi04MCB7XG4gICAgcGFkZGluZy1ib3R0b206IDgwcHg7XG59XG5cbi5ib3guaGFzLW1iIHtcbiAgICA+IGRpdiB7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDgwcHggIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5mLXIge1xuICAgIGZsb2F0OiByaWdodDtcbn1cbi5jbG9zZS1ib3gge1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgei1pbmRleDogMjAwMDAyO1xuICAgIGJveC1zaGFkb3c6IDJweCAycHggMTBweCAjNTU1O1xuICAgIGhlaWdodDogNTVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICBsaW5lLWhlaWdodDogNTVweDtcbiAgICBsZWZ0OiAwO1xuICAgID4gZGl2IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzdGFydDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICB9XG59XG4uY2xvc2UtYm94OjphZnRlciB7XG4gICAgY29udGVudDogJyc7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgY2xlYXI6IGJvdGg7XG59XG5cbi5uby1kYXRhIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogNTBweDtcbn1cblxuLnRhYmxlIHtcbiAgICB3aWR0aDogYXV0bztcbiAgICBtaW4td2lkdGg6IDEwMCU7XG4gICAgY29sb3I6ICM2NjY7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHRoZWFkIHtcbiAgICAgICAgcGFkZGluZzogMTBweCAwO1xuICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzY2NjtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM2NjY7XG4gICAgfVxuICAgIHRkIHtcbiAgICAgICAgcGFkZGluZzogMXB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZSAhaW1wb3J0YW50O1xuICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICB3aWR0aDogMTAwcHg7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdGQucmVtYXJrIHtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgaW9uLXRleHRhcmVhIHtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IGRvdWJsZSAjY2NjO1xuICAgICAgICAgICAgd2lkdGg6IDEyMHB4O1xuICAgICAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIC51cGxvYWRmaWxlIHtcbiAgICAgICAgLnBvcy1yIHtcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgICBpbnB1dFt0eXBlPSdmaWxlJ10ge1xuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMDBweDtcbiAgICAgICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAuaW1nLXJlc3BvbnNpdmUge1xuICAgICAgICAgICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cbiAgICB9XG59XG4udGV4dC1jIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5ib3QtYm94IHtcbiAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgei1pbmRleDogMjAwMDAyO1xuICAgIGJveC1zaGFkb3c6IDJweCAycHggMTBweCAjNTU1O1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBib3R0b206IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgLmNob2ljZS1kYXRlIHtcbiAgICAgICAgYmFja2dyb3VuZDogI2YzZjNmMztcbiAgICAgICAgY29sb3I6ICM1NTU7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgICAgICAgaW9uLWRhdGV0aW1lIHtcbiAgICAgICAgICAgIC0tcGFkZGluZy1lbmQ6IDIwcHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi50aHVtYm5haWwge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDAgIWltcG9ydGFudDtcbiAgICBoZWlnaHQ6IDQwcHg7XG59XG5cbmg2IHtcbiAgICAvLyAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgY29sb3I6ICM1NTU7XG59XG5cbi5zZWxlY3QtdGV4dC1jIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICB0ZXh0LWFsaWduLWxhc3Q6IGNlbnRlcjtcbn1cbi53ZC01MCB7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XG59XG4ud2QtNSB7XG4gICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAgd2lkdGg6IDVweDtcbn1cbi5oZy0wIHtcbiAgICBoZWlnaHQ6IDBweDtcbn1cblxuLndkLWhlLTE1MCB7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGRpc3BsYXk6IGlubGluZTtcbiAgICBoZWlnaHQ6IDUwcHg7XG59XG5cbi5jb250cm9sLWxhYmVsIHtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgcGFkZGluZzogMDtcbn1cblxuLmZsZXgtbGF5b3V0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xufVxuXG4uZGVzYy1pdGVtIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGlucHV0IHtcbiAgICAgICAgd2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIGhlaWdodDogMzBweCAhaW1wb3J0YW50O1xuICAgICAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICB9XG4gICAgYnV0dG9uIHtcbiAgICAgICAgbWFyZ2luLXRvcDogM3B4O1xuICAgIH1cbn1cblxuLmRlc2Mtc2hvdyB7XG4gICAgd2lkdGg6IDEwMHB4O1xufVxuXG4uZGVzYy1pdGVtOjphZnRlciB7XG4gICAgY29udGVudDogJyc7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgY2xlYXI6IGJvdGg7XG59XG5cbi5jb250YWluZXIge1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGhlaWdodDogY2FsYygxMDAlIC0gMTM1cHgpO1xuICAgIHRvcDogNTVweDtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuXG5pb24tY29udGVudCB7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxucCB7XG4gICAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuXG4ubXItMjAge1xuICAgIG1hcmdpbi1yaWdodDogMjBweCAhaW1wb3J0YW50O1xufVxuI2ZpeGVkLXRoZWFkIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgei1pbmRleDogOTk5O1xufVxuXG4uYW50LWlucHV0LWdyb3VwIHtcbiAgICBwb3NpdGlvbjogc3RhdGljICFpbXBvcnRhbnQ7XG59XG5cbi5hbnQtaW5wdXQge1xuICAgIHBvc2l0aW9uOiBzdGF0aWMgIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiAuYnV0dG9uLW5hdGl2ZSB7XG4gICAgcG9zaXRpb246IHN0YXRpYyAhaW1wb3J0YW50O1xufVxuXG4uYW50LWJ0biB7XG4gICAgcG9zaXRpb246IHN0YXRpYyAhaW1wb3J0YW50O1xufVxuXG4uc2MtaW9uLXRleHRhcmVhLW1kLWgge1xuICAgIHBvc2l0aW9uOiBzdGF0aWMgIWltcG9ydGFudDtcbn1cblxuLncxMDB7XG4gICAgd2lkdGg6IDEwMHB4ICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/component/custom-popup/custom-popup.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/component/custom-popup/custom-popup.component.ts ***!
  \******************************************************************/
/*! exports provided: CustomPopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomPopupComponent", function() { return CustomPopupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");






var CustomPopupComponent = /** @class */ (function () {
    function CustomPopupComponent(inspectService, baseData, effectCtrl, msg) {
        this.inspectService = inspectService;
        this.baseData = baseData;
        this.effectCtrl = effectCtrl;
        this.msg = msg;
        this.loading = false;
        this.chipboardDestroy = true;
        this.currentTime = this.baseData.utilFn.Format('yyyy-MM-dd');
        this.use_estimated_loading_time = true;
        this.estimated_loading_time = this.baseData.utilFn.Format('yyyy-MM-dd');
        this.timeChange = false;
        this.is_new_factory = '';
        this.config = {};
        this.showCancel = true;
        this.data = {
            data: {
                inspection_date: this.currentTime,
                estimated_loading_time: this.estimated_loading_time,
                is_new_factory: this.is_new_factory,
                content: [],
            },
        };
        this._descriptionAry = [];
    }
    Object.defineProperty(CustomPopupComponent.prototype, "contract", {
        set: function (input) {
            if (!!input) {
                this._contract = input;
                (this._contract.sku_list ? this._contract.sku_list : this._contract.sku_num).forEach(function (element, i) {
                    element.index = i;
                });
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CustomPopupComponent.prototype, "applyInspectId", {
        set: function (input) {
            if (!!input)
                this._applyInspectId = input;
        },
        enumerable: true,
        configurable: true
    });
    CustomPopupComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.sku_list =
            this._contract.sku_list && this._contract.sku_list.length
                ? this._contract.sku_list
                : this._contract.sku_num;
        this.data.data.content = JSON.parse(JSON.stringify(this.sku_list));
        this.data.data.content.forEach(function (sku, i) {
            var description = [];
            sku.numIsCom = '';
            sku.isNew = '';
            sku.group = '';
            sku.is_need_drop_test = sku.is_need_drop_test ? sku.is_need_drop_test : '';
            sku.has_strap = sku.has_strap ? sku.has_strap : '';
            sku.is_need_sample = sku.is_need_sample ? sku.is_need_sample : '';
            sku.need_bring_back_instructor = sku.need_bring_back_instructor ? sku.need_bring_back_instructor : '';
            sku.news_or_return_product = sku.news_or_return_product ? sku.news_or_return_product : '';
            (sku.photo = sku.photo && sku.photo.length ? sku.photo : []),
                (sku.description =
                    typeof sku.description == 'string'
                        ? [sku.description]
                        : description.concat(sku.description ? sku.description : ['']));
            sku.description.forEach(function (desc, j) {
                var _a;
                _this._descriptionAry[i] = (_a = {}, _a[j] = desc, _a);
            });
        });
        this.baseData.printDebug && console.log(this.data.data);
    };
    CustomPopupComponent.prototype.enter = function (type) {
        var _this = this;
        if (type == 'enter') {
            var upDateData = JSON.parse(JSON.stringify(this.data)), upDateSkuData_1 = [];
            this.data.data.content.forEach(function (sku, i) {
                upDateSkuData_1.push({
                    complete: sku.numIsCom,
                    quantity: sku.num || 0,
                    sku: sku.sku,
                    isNew: sku.isNew,
                    group: sku.group,
                    photo: sku.photo,
                    logo_desc: sku.logo_desc,
                    is_need_drop_test: sku.is_need_drop_test,
                    has_strap: sku.has_strap,
                    is_need_sample: sku.is_need_sample,
                    need_bring_back_instructor: sku.need_bring_back_instructor,
                    must_quantity: sku.must_quantity || 0,
                    warehouse: sku.warehouse,
                    // estimated_loading_time:sku.estimate未提交质检部d_loading_time,
                    news_or_return_product: sku.news_or_return_product,
                    description: _this.getAryToObj(_this._descriptionAry[i]),
                });
            });
            upDateData.data.inspection_date = this.currentTime;
            upDateData.data.is_new_factory = this.is_new_factory;
            upDateData.data.estimated_loading_time = this.estimated_loading_time;
            upDateData.data.content = upDateSkuData_1;
            this.effectCtrl.modalCtrl.dismiss({
                refresh: upDateData,
            });
        }
        else {
            this.effectCtrl.modalCtrl.dismiss();
        }
    };
    CustomPopupComponent.prototype.regValid = function (e) {
        if (!/^(?!0+(?:\0+)?$)(?:[1-9]\d*|0)(?:\\d{1,2})?$/.test(e.target.value)) {
            e.target.value = null;
        }
    };
    CustomPopupComponent.prototype.getAryToObj = function (obj) {
        var ary = [];
        for (var key in obj) {
            ary.push(obj[key]);
        }
        return ary;
    };
    CustomPopupComponent.prototype.choice = function (e, p) {
        if (e.target.files.length) {
            var reader = new FileReader();
            reader.onload = (function (file) {
                return function (e) {
                    p.photo.push(this.result);
                };
            })(e.target.files[0]);
            reader.readAsDataURL(e.target.files[0]);
        }
    };
    CustomPopupComponent.prototype.toggleStatus = function () {
        if (this.use_estimated_loading_time) {
            this.estimated_loading_time = this.baseData.utilFn.Format('yyyy-MM-dd');
        }
        else {
            this.estimated_loading_time = '';
        }
    };
    CustomPopupComponent.prototype.inspectIptVer = function (sku, p) {
        var msg = '';
        if (p === 'num' && sku[p] > sku.inspection_left_num) {
            msg = '验货数量不能大于剩余数量喔,请重新输入';
        }
        else if (p === 'must_quantity' && sku[p] > sku.num) {
            msg = '抽检数量不能大于验货数量喔,请重新输入';
        }
        if (!msg)
            return;
        this.effectCtrl.showAlert({
            header: '提示',
            backdropDismiss: false,
            message: msg,
            buttons: [
                {
                    text: '重新输入',
                    handler: function () {
                        sku[p] = null;
                    },
                },
            ],
        });
    };
    CustomPopupComponent.prototype.setChipboardDestroy = function (e) {
        this.chipboardDestroy = e;
    };
    CustomPopupComponent.prototype.ionViewWillEnter = function () {
        this.config = this.baseData.utilFn.getSwiperPublicConfig();
        this.config.mousewheel = false;
    };
    CustomPopupComponent.prototype.applyInspectModifyDesc = function (p) {
        var _this = this;
        this.inspectService
            .applyInspectModifyDesc({
            apply_id: this._applyInspectId,
            sku: p.sku,
            temporary_description: p.temporary_description,
        })
            .subscribe(function (res) {
            _this.effectCtrl.showAlert({
                message: res.message,
            });
        });
    };
    CustomPopupComponent.prototype.revoke = function (p, i) {
        var _this = this;
        console.log(p, this._applyInspectId);
        var params = {
            apply_id: this._applyInspectId,
            sku: p.sku
        };
        this.inspectService.revokeInspect(params)
            .subscribe(function (res) {
            console.log(res);
            _this.msg[res.status ? 'success' : 'danger'](res.message);
            if (res.status) {
                _this.data.data.content.splice(i, 1);
                _this.data.data.content = _this.data.data.content.slice();
                _this.effectCtrl.modalCtrl.dismiss({
                    refresh: true,
                });
            }
        });
    };
    CustomPopupComponent.prototype.cancelInspect = function (item) {
        var _this = this;
        this.inspectService.skuCancelInspect(item.sku, this._applyInspectId).subscribe(function (res) {
            if (res.status == 1) {
                item.skuCanceled = true;
            }
            _this.msg[res.status ? 'success' : 'error'](res.message);
        });
    };
    CustomPopupComponent.prototype.onscroll = function (e) {
        document.getElementById('fixed-thead').setAttribute('style', "transform:translateY(" + e.target.scrollTop + "px)");
    };
    CustomPopupComponent.ctorParameters = function () { return [
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"] },
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], CustomPopupComponent.prototype, "contract", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Number])
    ], CustomPopupComponent.prototype, "applyInspectId", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CustomPopupComponent.prototype, "showBtnGroup", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CustomPopupComponent.prototype, "showType", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], CustomPopupComponent.prototype, "showCancel", void 0);
    CustomPopupComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-custom-popup',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./custom-popup.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/custom-popup/custom-popup.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./custom-popup.component.scss */ "./src/app/component/custom-popup/custom-popup.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"],
            _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzMessageService"]])
    ], CustomPopupComponent);
    return CustomPopupComponent;
}());



/***/ }),

/***/ "./src/app/component/edit-task/edit-task.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/component/edit-task/edit-task.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".tips {\n  text-align: center;\n  background: #f5f5f5; }\n\n.container {\n  height: calc(100% - 125px);\n  overflow-y: scroll; }\n\n.min-width-100 {\n  min-width: 325px !important; }\n\n.search-bar {\n  width: 320px; }\n\n.clearfix {\n  clear: both; }\n\nnz-date-picker {\n  width: 155px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9lZGl0LXRhc2svZWRpdC10YXNrLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQWtCO0VBQ2xCLG1CQUFtQixFQUFBOztBQUd2QjtFQUNJLDBCQUEwQjtFQUMxQixrQkFBa0IsRUFBQTs7QUFHdEI7RUFDSSwyQkFBMkIsRUFBQTs7QUFHL0I7RUFDSSxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksWUFBWSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L2VkaXQtdGFzay9lZGl0LXRhc2suY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGlwc3tcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcbn1cblxuLmNvbnRhaW5lcntcbiAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDEyNXB4KTtcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG59XG5cbi5taW4td2lkdGgtMTAwe1xuICAgIG1pbi13aWR0aDogMzI1cHggIWltcG9ydGFudDtcbn1cblxuLnNlYXJjaC1iYXJ7XG4gICAgd2lkdGg6IDMyMHB4O1xufVxuXG4uY2xlYXJmaXh7XG4gICAgY2xlYXI6IGJvdGg7XG59XG5cbm56LWRhdGUtcGlja2Vye1xuICAgIHdpZHRoOiAxNTVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/component/edit-task/edit-task.component.ts":
/*!************************************************************!*\
  !*** ./src/app/component/edit-task/edit-task.component.ts ***!
  \************************************************************/
/*! exports provided: EditTaskComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditTaskComponent", function() { return EditTaskComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/_@angular_forms@8.2.14@@angular/forms/fesm5/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/operators/index.js");







var EditTaskComponent = /** @class */ (function () {
    function EditTaskComponent(inspect, msg, effectCtrl) {
        this.inspect = inspect;
        this.msg = msg;
        this.effectCtrl = effectCtrl;
        this.list = [];
        this.disabled = false;
        this.index = 0;
        this.tree = [];
        this.currentFactory = '';
        this.selectedValue = '';
        this.inspectors = [];
        this.inspector = { id: '', name: '' };
        this.factoryKeywords = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('');
        this.treeKeywords = '';
        this.metaTasks = [];
        this.startTime = null;
        this.endTime = null;
        this.onComplete = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.treeChecked = [];
        this.params = {
            sku_info: [],
            probable_inspection_date: [],
            inspection_user_id_arr: [],
            desc: '',
        };
        this.canClick = true;
    }
    EditTaskComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.getList();
        this.inspect.getGroupUserList().subscribe(function (res) {
            _this.inspectors = res.data;
        });
        this.factoryKeywords.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["debounceTime"])(700)).subscribe(function (res) {
            _this._tasks = res ? _this._tasks.filter(function (item) { return item.title.indexOf(res) !== -1; }) : _this.metaTasks;
        });
    };
    EditTaskComponent.prototype.getList = function () {
        var _this = this;
        this.inspect.getMergeTaskData().subscribe(function (res) {
            _this._tasks = _this.treeFactory(res);
            _this.metaTasks = JSON.parse(JSON.stringify(_this._tasks));
        });
    };
    EditTaskComponent.prototype.select = function (ret) {
        console.log('nzSelectChange', ret);
    };
    EditTaskComponent.prototype.change = function (ret) { };
    EditTaskComponent.prototype.onIndexChange = function (event) {
        this.index = event;
    };
    EditTaskComponent.prototype.nzEvent = function (e) { };
    EditTaskComponent.prototype.searchFactory = function () {
        // if (this.factoryKeywords.length) {
        //     this._tasks = this._tasks.filter(item => item.title.indexOf(this.factoryKeywords) !== -1);
        // } else this._tasks = this.metaTasks;
    };
    EditTaskComponent.prototype.treeFactory = function (data) {
        var value = [];
        for (var index = 0; index < data.length; index++) {
            var element = data[index];
            value.push({
                title: element.factory_name,
                key: element.factory_code ? element.factory_code : index,
                expanded: true,
                children: [],
                disableCheckbox: true,
            });
            if (element.apply_arr && element.apply_arr.length) {
                for (var j = 0; j < element.apply_arr.length; j++) {
                    var data_1 = element.apply_arr[j];
                    value[index].children.push({
                        title: "\u6279\u6B21\u53F7:    " + data_1.apply_inspection_no,
                        key: data_1.apply_inspection_no,
                        expanded: true,
                        children: [],
                        disableCheckbox: true,
                    });
                    if (data_1.contract_arr && data_1.contract_arr.length) {
                        for (var k = 0; k < data_1.contract_arr.length; k++) {
                            var contract = data_1.contract_arr[k];
                            value[index].children[j].children.push({
                                title: "\u5408\u540C\u53F7:   " + contract.contract_no,
                                key: data_1.apply_inspection_no + '$' + contract.contract_no,
                                expanded: true,
                                children: [],
                                disableCheckbox: true,
                            });
                            if (contract.sku_arr && contract.sku_arr.length) {
                                for (var p = 0; p < contract.sku_arr.length; p++) {
                                    var sku = contract.sku_arr[p];
                                    value[index].children[j].children[k].children.push({
                                        title: sku.sku_chinese + " - " + sku.sku,
                                        key: data_1.apply_inspection_no + '$' + contract.contract_no + '&' + sku.sku,
                                        expanded: true,
                                        children: [],
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
        return value;
    };
    EditTaskComponent.prototype.treeOnChange = function (e) {
        this.treeChecked = e.keys;
    };
    EditTaskComponent.prototype.onChange = function (e, type) {
        this.params.probable_inspection_date[type === 'start' ? 0 : 1] = e;
    };
    EditTaskComponent.prototype.treeKeyChange = function (e) {
        // console.log(e.target.value);
        // if (!e.target.value) {
        //     this.a = false;
        //     setTimeout(() => {
        //         this.a = true;
        //     }, 1000);
        // }
    };
    EditTaskComponent.prototype.submit = function () {
        var _this = this;
        this.canClick = false;
        this.params.inspection_user_id_arr = []; //先清空
        this.params.sku_info = [];
        this.treeChecked.forEach(function (node) {
            _this.params.sku_info.push({
                apply_inspection_no: node.slice(0, node.indexOf('$')),
                contract_no: node.slice(node.indexOf('$') + 1, node.indexOf('&')),
                sku: node.slice(node.indexOf('&') + 1, node.length),
            });
        });
        for (var key in this.inspector) {
            if (typeof this.inspector[key] === 'number') {
                this.params.inspection_user_id_arr.push(this.inspector[key]);
            }
        }
        if (this.params.sku_info && !this.params.sku_info.length) {
            this.msg.error('请返回上一步勾选SKU！');
            this.index = 1;
            return;
        }
        else if (this.params.inspection_user_id_arr && !this.params.inspection_user_id_arr.length) {
            this.msg.error('请选择验货人！');
            return;
        }
        else if (this.params.probable_inspection_date && !this.params.probable_inspection_date.length) {
            this.msg.error('请选择验货时间！');
            return;
        }
        this.inspect.submitMergeData(this.params).subscribe(function (res) {
            _this.canClick = true;
            _this.msg[res.status ? 'success' : 'error'](res.message);
            if (res.status) {
                _this.index = 0;
                _this.currentFactory = null;
                _this.getList();
                _this.effectCtrl.modalCtrl.dismiss({ refresh: true });
                _this.inspector = { id: '', name: '' };
            }
            _this.params.sku_info = [];
            _this.params.inspection_user_id_arr = [];
            _this.params.desc = '';
        });
    };
    EditTaskComponent.ctorParameters = function () { return [
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__["PageEffectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], EditTaskComponent.prototype, "onComplete", void 0);
    EditTaskComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-edit-task',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./edit-task.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/edit-task/edit-task.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./edit-task.component.scss */ "./src/app/component/edit-task/edit-task.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__["PageEffectService"]])
    ], EditTaskComponent);
    return EditTaskComponent;
}());



/***/ }),

/***/ "./src/app/component/editor/editor.component.scss":
/*!********************************************************!*\
  !*** ./src/app/component/editor/editor.component.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("::ng-deep .w-e-toolbar .w-e-menu {\n  width: 25px !important; }\n\n.root {\n  margin-top: 5px;\n  width: 100%; }\n\n.root > div {\n    width: 100%; }\n\n.f-r {\n  float: right; }\n\n.enter {\n  position: absolute;\n  right: 10px;\n  bottom: 10px;\n  z-index: 99999; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9lZGl0b3IvZWRpdG9yLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQXNCLEVBQUE7O0FBRzFCO0VBQ0ksZUFBZTtFQUNmLFdBQVcsRUFBQTs7QUFGZjtJQUlRLFdBQVcsRUFBQTs7QUFJbkI7RUFDSSxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxZQUFZO0VBQ1osY0FBYyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L2VkaXRvci9lZGl0b3IuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAgLnctZS10b29sYmFyIC53LWUtbWVudXtcbiAgICB3aWR0aDogMjVweCAhaW1wb3J0YW50O1xufVxuXG4ucm9vdHtcbiAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgPmRpdntcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxufVxuXG4uZi1ye1xuICAgIGZsb2F0OiByaWdodDtcbn1cblxuLmVudGVye1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMTBweDtcbiAgICBib3R0b206IDEwcHg7XG4gICAgei1pbmRleDogOTk5OTk7XG59Il19 */");

/***/ }),

/***/ "./src/app/component/editor/editor.component.ts":
/*!******************************************************!*\
  !*** ./src/app/component/editor/editor.component.ts ***!
  \******************************************************/
/*! exports provided: EditorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditorComponent", function() { return EditorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment.js */ "./src/environments/environment.js");
/* harmony import */ var src_app_services_base_data_service_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/base-data.service.js */ "./src/app/services/base-data.service.js");
/* harmony import */ var src_app_services_commit_service_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/commit.service.js */ "./src/app/services/commit.service.js");





var EditorComponent = /** @class */ (function () {
    function EditorComponent(baseData, commit) {
        this.baseData = baseData;
        this.commit = commit;
        this.imgOrigin = src_environments_environment_js__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl;
        this.defaultMessage = '';
        this.id = new Date().getTime();
        this.onData = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    EditorComponent.prototype.ngOnInit = function () { };
    EditorComponent.prototype.ngAfterViewInit = function () {
        this.commit._init();
    };
    EditorComponent.ctorParameters = function () { return [
        { type: src_app_services_base_data_service_js__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"] },
        { type: src_app_services_commit_service_js__WEBPACK_IMPORTED_MODULE_4__["CommitService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], EditorComponent.prototype, "onData", void 0);
    EditorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-editor',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./editor.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/editor/editor.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./editor.component.scss */ "./src/app/component/editor/editor.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_base_data_service_js__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"], src_app_services_commit_service_js__WEBPACK_IMPORTED_MODULE_4__["CommitService"]])
    ], EditorComponent);
    return EditorComponent;
}());



/***/ }),

/***/ "./src/app/component/funnel/funnel.component.scss":
/*!********************************************************!*\
  !*** ./src/app/component/funnel/funnel.component.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-icon {\n  cursor: pointer !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9mdW5uZWwvZnVubmVsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMEJBQ0osRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9mdW5uZWwvZnVubmVsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWljb257XG4gICAgY3Vyc29yOiBwb2ludGVyICFpbXBvcnRhbnRcbn0iXX0= */");

/***/ }),

/***/ "./src/app/component/funnel/funnel.component.ts":
/*!******************************************************!*\
  !*** ./src/app/component/funnel/funnel.component.ts ***!
  \******************************************************/
/*! exports provided: FunnelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FunnelComponent", function() { return FunnelComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var FunnelComponent = /** @class */ (function () {
    function FunnelComponent() {
        this.onSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this._list = [];
    }
    Object.defineProperty(FunnelComponent.prototype, "list", {
        set: function (input) {
            if (!!input)
                this._list = input;
        },
        enumerable: true,
        configurable: true
    });
    FunnelComponent.prototype.ngOnInit = function () { };
    FunnelComponent.prototype.openSelector = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Array])
    ], FunnelComponent.prototype, "list", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], FunnelComponent.prototype, "onSelected", void 0);
    FunnelComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-funnel',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./funnel.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/funnel/funnel.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./funnel.component.scss */ "./src/app/component/funnel/funnel.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FunnelComponent);
    return FunnelComponent;
}());



/***/ }),

/***/ "./src/app/component/inspect-setting-box/inspect-setting-box.component.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/component/inspect-setting-box/inspect-setting-box.component.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9pbnNwZWN0LXNldHRpbmctYm94L2luc3BlY3Qtc2V0dGluZy1ib3guY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/component/inspect-setting-box/inspect-setting-box.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/component/inspect-setting-box/inspect-setting-box.component.ts ***!
  \********************************************************************************/
/*! exports provided: InspectSettingBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectSettingBoxComponent", function() { return InspectSettingBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");





var InspectSettingBoxComponent = /** @class */ (function () {
    function InspectSettingBoxComponent(modalService, inspectService, effectCtrl) {
        this.modalService = modalService;
        this.inspectService = inspectService;
        this.effectCtrl = effectCtrl;
    }
    Object.defineProperty(InspectSettingBoxComponent.prototype, "contract", {
        set: function (input) {
            this._contract = JSON.parse(JSON.stringify(input));
        },
        enumerable: true,
        configurable: true
    });
    InspectSettingBoxComponent.prototype.ngOnInit = function () { };
    InspectSettingBoxComponent.prototype.enter = function () {
        var _this = this;
        var params = {
            is_contacted_factory: this._contract.is_c_ontackedfactory ? 1 : 0,
            is_bought_ticket: this._contract.is_bought_ticket ? 1 : 0,
            is_inspected_factory: this._contract.is_inspected_factory ? 1 : 0,
            is_inspected_product: this._contract.is_inspected_product ? 1 : 0,
            is_plan_date: this._contract.is_plan_date ? 1 : 0,
            is_know_demand: this._contract.is_know_demand ? 1 : 0,
            apply_id: this._contract.id,
        };
        this.inspectService.inspecerSetting(params).subscribe(function (data) {
            if (data.status == 1) {
                _this.modalService.dismiss({
                    refresh: _this.contract,
                });
            }
            else
                _this.modalService.dismiss();
            _this.effectCtrl.showAlert({
                header: '提示',
                message: data.message,
            });
        });
    };
    InspectSettingBoxComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], InspectSettingBoxComponent.prototype, "contract", null);
    InspectSettingBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-inspect-setting-box',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./inspect-setting-box.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/inspect-setting-box/inspect-setting-box.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./inspect-setting-box.component.scss */ "./src/app/component/inspect-setting-box/inspect-setting-box.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], InspectSettingBoxComponent);
    return InspectSettingBoxComponent;
}());



/***/ }),

/***/ "./src/app/component/loadding/loadding.component.scss":
/*!************************************************************!*\
  !*** ./src/app/component/loadding/loadding.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".dis-flex {\n  width: 100%;\n  height: 100%;\n  position: fixed;\n  top: 55px;\n  left: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  background: rgba(0, 0, 0, 0.5);\n  flex-direction: column;\n  color: #b7ebf0; }\n  .dis-flex img {\n    width: 60px;\n    height: 60px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9sb2FkZGluZy9sb2FkZGluZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQVc7RUFDWCxZQUFZO0VBQ1osZUFBZTtFQUNmLFNBQVM7RUFDVCxPQUFPO0VBQ1AsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsOEJBQThCO0VBQzlCLHNCQUFzQjtFQUN0QixjQUFjLEVBQUE7RUFYbEI7SUFhUSxXQUFXO0lBQ1gsWUFBWSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L2xvYWRkaW5nL2xvYWRkaW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRpcy1mbGV4IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIHRvcDogNTVweDtcbiAgICBsZWZ0OiAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBjb2xvcjogI2I3ZWJmMDtcbiAgICBpbWcge1xuICAgICAgICB3aWR0aDogNjBweDtcbiAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "./src/app/component/loadding/loadding.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/component/loadding/loadding.component.ts ***!
  \**********************************************************/
/*! exports provided: LoaddingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaddingComponent", function() { return LoaddingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var LoaddingComponent = /** @class */ (function () {
    function LoaddingComponent() {
    }
    LoaddingComponent.prototype.ngOnInit = function () { };
    LoaddingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-loadding',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./loadding.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/loadding/loadding.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./loadding.component.scss */ "./src/app/component/loadding/loadding.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LoaddingComponent);
    return LoaddingComponent;
}());



/***/ }),

/***/ "./src/app/component/no-data-show/no-data-show.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/component/no-data-show/no-data-show.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9uby1kYXRhLXNob3cvbm8tZGF0YS1zaG93LmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/component/no-data-show/no-data-show.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/component/no-data-show/no-data-show.component.ts ***!
  \******************************************************************/
/*! exports provided: NoDataShowComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoDataShowComponent", function() { return NoDataShowComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var NoDataShowComponent = /** @class */ (function () {
    function NoDataShowComponent() {
    }
    NoDataShowComponent.prototype.ngOnInit = function () { };
    NoDataShowComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-no-data-show',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./no-data-show.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/no-data-show/no-data-show.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./no-data-show.component.scss */ "./src/app/component/no-data-show/no-data-show.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], NoDataShowComponent);
    return NoDataShowComponent;
}());



/***/ }),

/***/ "./src/app/component/pagination/pagination.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/component/pagination/pagination.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".page-box {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start; }\n  .page-box .text {\n    margin: 0 15px; }\n  .page-box p {\n    line-height: 100%; }\n  input {\n  width: 40px;\n  text-align: center;\n  line-height: 20px;\n  border-radius: 5px;\n  --padding-start: 0;\n  height: 26px;\n  border: 1px solid #e8e8e8; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9wYWdpbmF0aW9uL3BhZ2luYXRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLDJCQUEyQixFQUFBO0VBSC9CO0lBV1EsY0FBYyxFQUFBO0VBWHRCO0lBY1EsaUJBQWlCLEVBQUE7RUFJekI7RUFDSSxXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsa0JBQWdCO0VBQ2hCLFlBQVk7RUFDWix5QkFBeUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9wYWdpbmF0aW9uL3BhZ2luYXRpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGFnZS1ib3gge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG4gICAgLy8gaW9uLWlucHV0e1xuICAgIC8vICAgICB3aWR0aDogNDBweDtcbiAgICAvLyAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC8vICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgLy8gICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2NcbiAgICAvLyB9XG4gICAgLnRleHQge1xuICAgICAgICBtYXJnaW46IDAgMTVweDtcbiAgICB9XG4gICAgcCB7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxMDAlO1xuICAgIH1cbn1cblxuaW5wdXQge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMjBweDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAgIGhlaWdodDogMjZweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xufVxuIl19 */");

/***/ }),

/***/ "./src/app/component/pagination/pagination.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/component/pagination/pagination.component.ts ***!
  \**************************************************************/
/*! exports provided: PaginationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaginationComponent", function() { return PaginationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");




var PaginationComponent = /** @class */ (function () {
    function PaginationComponent(es, msg) {
        this.es = es;
        this.msg = msg;
        this.pagechange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onPagingTotalChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.hidePaging = false;
        this.pagingTotal = 20;
    }
    Object.defineProperty(PaginationComponent.prototype, "pageNum", {
        get: function () {
            return this.pagging.pageNum;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaginationComponent.prototype, "pageTotal", {
        get: function () {
            return this.pagging.pageTotal;
        },
        enumerable: true,
        configurable: true
    });
    PaginationComponent.prototype.changePage = function (num) {
        if (num > this.pagging.pageTotal || num < 0) {
            this.msg.error('不能超过页码总数');
            this.paging = 0;
            return;
        }
        this.pagging.pageNum = num;
        this.pagechange.emit(this.pagging);
    };
    PaginationComponent.prototype.ngOnChanges = function (changes) {
        // console.log(this.pagging)
    };
    PaginationComponent.prototype.regValid = function (e) {
        if (!/^(?!0+(?:\0+)?$)(?:[1-9]\d*|0)(?:\\d{1,2})?$/.test(e.target.value)) {
            e.target.value = null;
        }
    };
    PaginationComponent.prototype.ngOnInit = function () { };
    PaginationComponent.prototype.pagingTotalChange = function (e) {
        this.onPagingTotalChange.emit(e);
    };
    PaginationComponent.ctorParameters = function () { return [
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "pagging", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], PaginationComponent.prototype, "pagechange", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], PaginationComponent.prototype, "onPagingTotalChange", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], PaginationComponent.prototype, "hidePaging", void 0);
    PaginationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-pagination',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./pagination.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/pagination/pagination.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./pagination.component.scss */ "./src/app/component/pagination/pagination.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"]])
    ], PaginationComponent);
    return PaginationComponent;
}());



/***/ }),

/***/ "./src/app/component/permission-tree/permission-tree.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/component/permission-tree/permission-tree.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu {\n  color: gray; }\n\n.btn {\n  color: blue; }\n\n.field {\n  color: red; }\n\n.inspect-report {\n  color: green; }\n\n:host ::ng-deep .ant-tree .ant-tree-treenode[ng-reflect-is-leaf='true'] {\n  display: inline; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9wZXJtaXNzaW9uLXRyZWUvcGVybWlzc2lvbi10cmVlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBVyxFQUFBOztBQUVmO0VBQ0ksV0FBVyxFQUFBOztBQUVmO0VBQ0ksVUFBVSxFQUFBOztBQUVkO0VBQ0ksWUFBWSxFQUFBOztBQUdoQjtFQUNJLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9wZXJtaXNzaW9uLXRyZWUvcGVybWlzc2lvbi10cmVlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnUge1xuICAgIGNvbG9yOiBncmF5O1xufVxuLmJ0biB7XG4gICAgY29sb3I6IGJsdWU7XG59XG4uZmllbGQge1xuICAgIGNvbG9yOiByZWQ7XG59XG4uaW5zcGVjdC1yZXBvcnQge1xuICAgIGNvbG9yOiBncmVlbjtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5hbnQtdHJlZSAuYW50LXRyZWUtdHJlZW5vZGVbbmctcmVmbGVjdC1pcy1sZWFmPSd0cnVlJ10ge1xuICAgIGRpc3BsYXk6IGlubGluZTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/component/permission-tree/permission-tree.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/component/permission-tree/permission-tree.component.ts ***!
  \************************************************************************/
/*! exports provided: PermissionTreeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionTreeComponent", function() { return PermissionTreeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_pages_permission_permission_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pages/permission/permission.component */ "./src/app/pages/permission/permission.component.ts");



var PermissionTreeComponent = /** @class */ (function () {
    function PermissionTreeComponent() {
        this._permissions = [];
        this.permissionTypeMap = src_app_pages_permission_permission_component__WEBPACK_IMPORTED_MODULE_2__["PermissionType"];
        this._permissionListFiled = [];
        this.permissionReport = [];
        this.treePermission = [];
        this.onChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    Object.defineProperty(PermissionTreeComponent.prototype, "permissionListFiled", {
        set: function (input) {
            if (input && input.length)
                this._permissionListFiled = this.setListFieldData(input);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PermissionTreeComponent.prototype, "permission", {
        set: function (input) {
            if (input && input.length)
                this._permissions = input;
            if (!this.nzCheckable) {
                this._permissions = this.setReadonly(this._permissions);
            }
            var fn = this.getSelectedIdForTree();
            var selectedTreeIds = JSON.parse(JSON.stringify(fn(this._permissions)));
            fn = null;
            this.onChange.emit(selectedTreeIds); //将选中的id数组emit出去
        },
        enumerable: true,
        configurable: true
    });
    PermissionTreeComponent.prototype.ngOnInit = function () {
    };
    PermissionTreeComponent.prototype.setReadonly = function (permissions) {
        var _this = this;
        permissions.forEach(function (permission) {
            if (permission.children && permission.children.length) {
                _this.setReadonly(permission.children);
            }
            else
                permission.disableCheckbox = true;
        });
        return permissions;
    };
    /**
     * 设置permission的value和label配合ng-zorro的nz-checkbox-group使用
     * @param permissions
     */
    PermissionTreeComponent.prototype.setListFieldData = function (permissions) {
        permissions.forEach(function (item) {
            item.children.forEach(function (child) {
                child.label = child.title;
                child.value = child.key;
            });
        });
        return permissions;
    };
    PermissionTreeComponent.prototype.logReportFiled = function (e) {
        this.onChange.emit(this.treePermission.concat(this.getCheckedId())); //将选中的id数组emit出去
        console.log(e);
        // this.dataBind(e);
    };
    /**
     * 废弃
     * @param e
     */
    PermissionTreeComponent.prototype.dataBind = function (e) {
        //将列表字段的key和菜单按钮保持一致
        //通过父级的id找到permission 从而匹配其字段子级
        this._permissions.forEach(function (permission) {
            if (permission.id === e.id) {
                //嵌套循环
                permission.children.forEach(function (child) {
                    e.children.forEach(function (item) {
                        var next = true;
                        if (child.id === item.id) {
                            child.checked = item.checked;
                        }
                        else if (!child.checked) {
                        }
                    });
                });
            }
        });
        this._permissions = this._permissions.slice();
    };
    PermissionTreeComponent.prototype.getTreePermission = function (e) {
        var selectedTreeId = [];
        this.treePermission = e;
        var fn = this.getSelectedIdForTree();
        selectedTreeId = JSON.parse(JSON.stringify(fn(this._permissions)));
        fn = null;
        this.onChange.emit(selectedTreeId.concat(this.getCheckedId()));
    };
    //遍历tree将为true的
    PermissionTreeComponent.prototype.getSelectedIdForTree = function () {
        var value = [];
        return function map(permissions) {
            permissions.forEach(function (permission) {
                permission.checked && value.push(permission.key);
                permission.children && permission.children.length && map(permission.children);
            });
            return value;
        };
    };
    /**
     * 将permissionListField和permissionReport checked为true的value取出来
     */
    PermissionTreeComponent.prototype.getCheckedId = function () {
        var value = [], listFiled = this._permissionListFiled, reportFiled = this.permissionReport;
        listFiled.forEach(function (item) {
            item.children.forEach(function (sItem) {
                sItem.checked && value.push(sItem.id);
            });
        });
        reportFiled.forEach(function (item) {
            item.checked && value.push(item.value);
        });
        return value;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], PermissionTreeComponent.prototype, "nzCheckable", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Array])
    ], PermissionTreeComponent.prototype, "permissionListFiled", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Array])
    ], PermissionTreeComponent.prototype, "permission", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], PermissionTreeComponent.prototype, "onChange", void 0);
    PermissionTreeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-permission-tree',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./permission-tree.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/permission-tree/permission-tree.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./permission-tree.component.scss */ "./src/app/component/permission-tree/permission-tree.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PermissionTreeComponent);
    return PermissionTreeComponent;
}());



/***/ }),

/***/ "./src/app/component/progress/progress.component.scss":
/*!************************************************************!*\
  !*** ./src/app/component/progress/progress.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".progress {\n  min-width: 100px; }\n  .progress .progress-bar {\n    color: #e6e6e6; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9wcm9ncmVzcy9wcm9ncmVzcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFnQixFQUFBO0VBRHBCO0lBR1EsY0FBYyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L3Byb2dyZXNzL3Byb2dyZXNzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2dyZXNzIHtcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xuICAgIC5wcm9ncmVzcy1iYXIge1xuICAgICAgICBjb2xvcjogI2U2ZTZlNjtcbiAgICB9XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/component/progress/progress.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/component/progress/progress.component.ts ***!
  \**********************************************************/
/*! exports provided: ProgressComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProgressComponent", function() { return ProgressComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var ProgressComponent = /** @class */ (function () {
    function ProgressComponent() {
    }
    ProgressComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], ProgressComponent.prototype, "total", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], ProgressComponent.prototype, "current", void 0);
    ProgressComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-progress',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./progress.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/progress/progress.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./progress.component.scss */ "./src/app/component/progress/progress.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ProgressComponent);
    return ProgressComponent;
}());



/***/ }),

/***/ "./src/app/component/reply-mode/reply-mode.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/component/reply-mode/reply-mode.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9yZXBseS1tb2RlL3JlcGx5LW1vZGUuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/component/reply-mode/reply-mode.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/component/reply-mode/reply-mode.component.ts ***!
  \**************************************************************/
/*! exports provided: ReplyModeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReplyModeComponent", function() { return ReplyModeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var ReplyModeComponent = /** @class */ (function () {
    function ReplyModeComponent() {
    }
    ReplyModeComponent.prototype.ngOnInit = function () { };
    ReplyModeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-reply-mode',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./reply-mode.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/reply-mode/reply-mode.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./reply-mode.component.scss */ "./src/app/component/reply-mode/reply-mode.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ReplyModeComponent);
    return ReplyModeComponent;
}());



/***/ }),

/***/ "./src/app/component/reply/reply.component.scss":
/*!******************************************************!*\
  !*** ./src/app/component/reply/reply.component.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".reply-input {\n  width: 70%;\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-end;\n  border: 1px solid;\n  padding: 10px; }\n  .reply-input textarea {\n    height: 60px;\n    flex-grow: 1; }\n  #screen {\n  padding: 10px; }\n  .comment-img img {\n  display: block;\n  width: 50px;\n  height: 50px; }\n  .comment-video video {\n  display: block;\n  width: 300px;\n  height: 210px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9yZXBseS9yZXBseS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQVU7RUFDVixhQUFhO0VBQ2IsOEJBQThCO0VBQzlCLHFCQUFxQjtFQUNyQixpQkFBaUI7RUFDakIsYUFBYSxFQUFBO0VBTmpCO0lBUVEsWUFBWTtJQUNaLFlBQVksRUFBQTtFQVlwQjtFQUNJLGFBQWEsRUFBQTtFQUdqQjtFQUVRLGNBQWM7RUFDZCxXQUFXO0VBQ1gsWUFBWSxFQUFBO0VBSXBCO0VBRVEsY0FBYztFQUNkLFlBQVk7RUFDWixhQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnQvcmVwbHkvcmVwbHkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVwbHktaW5wdXQge1xuICAgIHdpZHRoOiA3MCU7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkO1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgdGV4dGFyZWEge1xuICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgIGZsZXgtZ3JvdzogMTtcbiAgICB9XG59XG5cbjpob3N0IDo6bmctZGVlcCAuYW50LWNvbW1lbnQtaW5uZXIge1xuICAgIC8vIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5hbnQtZm9ybS1pdGVtIHtcbiAgICAvLyBtYXJnaW4tYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbiNzY3JlZW4ge1xuICAgIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5jb21tZW50LWltZyB7XG4gICAgaW1nIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgfVxufVxuXG4uY29tbWVudC12aWRlbyB7XG4gICAgdmlkZW8ge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgd2lkdGg6IDMwMHB4O1xuICAgICAgICBoZWlnaHQ6IDIxMHB4O1xuICAgIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "./src/app/component/reply/reply.component.ts":
/*!****************************************************!*\
  !*** ./src/app/component/reply/reply.component.ts ***!
  \****************************************************/
/*! exports provided: ReplyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReplyComponent", function() { return ReplyComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_examine_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/examine.service */ "./src/app/services/examine.service.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");







var ReplyComponent = /** @class */ (function () {
    function ReplyComponent(baseData, http, msg, examine) {
        var _this = this;
        this.baseData = baseData;
        this.http = http;
        this.msg = msg;
        this.examine = examine;
        this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl;
        this.env = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"];
        this.onSubmit = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.onDataUrl = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.onImgOrVideoComplete = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.onDelTreeNode = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.currentComment = {
            id: null,
            contents: '',
            pid: null,
            path: null,
            inspection_task_pre_id: null,
            created_at: '',
            updated_at: '',
        };
        this.commentBoxShow = true;
        this._data = null;
        this.submitting = false;
        this.fileList = [];
        this.previewImage = '';
        this.previewVisible = false;
        this.shouldRemoveImg = true;
        this.customRequest = function (e) {
            var formData = new FormData();
            formData.append('apply_inspection_no', _this.apo);
            formData.append('id', _this.currentComment.id);
            formData.append('advise_img', e.file, e.file.name);
            return _this.http
                .post(_this.apiUrl + '/task/add_inspection_task_review_advise_data', formData, {
                headers: {
                    Accept: 'multipart/form-data',
                    Authorization: _this.baseData.userInfo.api_token
                        ? "Bearer " + _this.baseData.userInfo.api_token
                        : undefined,
                },
            })
                .subscribe(function (res) {
                if (res.status)
                    e.onSuccess(null, e.file, null);
                else
                    e.onError(null, e.file);
                _this.onImgOrVideoComplete.emit(true);
                _this.commentBoxShow = !_this.commentBoxShow;
            });
        };
        this.customRequestVideo = function (e) {
            var formData = new FormData();
            formData.append('apply_inspection_no', _this.apo);
            formData.append('id', _this.currentComment.id);
            formData.append('advise_video', e.file, e.file.name);
            return _this.http
                .post(_this.apiUrl + '/task/add_inspection_task_review_advise_data', formData, {
                headers: {
                    Accept: 'multipart/form-data',
                    Authorization: _this.baseData.userInfo.api_token
                        ? "Bearer " + _this.baseData.userInfo.api_token
                        : undefined,
                },
            })
                .subscribe(function (res) {
                if (res.status)
                    e.onSuccess(null, e.file, null);
                else
                    e.onError(null, e.file);
                _this.onImgOrVideoComplete.emit(true);
                _this.commentBoxShow = !_this.commentBoxShow;
            });
        };
        this.handlePreview = function (file) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            var _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!(!file.url && !file.preview)) return [3 /*break*/, 2];
                        _a = file;
                        return [4 /*yield*/, getBase64(file.originFileObj)];
                    case 1:
                        _a.preview = _b.sent();
                        _b.label = 2;
                    case 2:
                        this.previewImage = file.url || file.preview;
                        this.previewVisible = true;
                        return [2 /*return*/];
                }
            });
        }); };
    }
    Object.defineProperty(ReplyComponent.prototype, "data", {
        set: function (input) {
            if (!!input) {
                this._data = input;
            }
        },
        enumerable: true,
        configurable: true
    });
    ReplyComponent.prototype.handleChange = function (info) {
        if (info.file.status === 'done') {
            this.msg.success(info.file.name + " \u4E0A\u4F20\u6210\u529F");
        }
        else if (info.file.status === 'error') {
            this.msg.error(info.file.name + " \u4E0A\u4F20\u5931\u8D25");
        }
    };
    ReplyComponent.prototype.handleSubmit = function (p) {
        var $this = this;
        var advise = {
            id: new Date().getTime(),
            contents: this.inputValue,
            pid: p.id,
            inspection_task_pre_id: null,
            created_at: new Date().toString(),
        };
        p.son ? p.son.push(advise) : (p.son = [advise]);
        var _a = { id: p.id, contents: $this.inputValue }, id = _a.id, contents = _a.contents;
        $this.onSubmit.emit({ id: id, contents: contents });
        this.commentBoxShow = !this.commentBoxShow;
        this.msg.success('审核成功！');
    };
    ReplyComponent.prototype.ngOnInit = function () { };
    ReplyComponent.prototype.recursionTree = function (pid, tree) {
        for (var i = 0; i < tree.length; i++) {
            if (tree[i].id == pid) {
                var advise = {
                    id: new Date().getTime(),
                    contents: this.inputValue,
                    pid: tree[i].id,
                    inspection_task_pre_id: null,
                    created_at: new Date().toString(),
                };
                tree[i].son.push(advise);
                this.inputValue = '';
            }
            else {
                if (tree[i].son && tree[i].son.length) {
                    this.recursionTree(pid, tree[i].son);
                }
                else
                    continue;
            }
        }
    };
    ReplyComponent.prototype.reply = function (p) {
        this.currentComment = p;
    };
    ReplyComponent.prototype.delConfirm = function (p) {
        if (this.baseData.userInfo.id === p.user.id)
            this.onDelTreeNode.emit(p.id);
        else
            this.msg.error('只能删除自己的留言！');
    };
    ReplyComponent.ctorParameters = function () { return [
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["NzMessageService"] },
        { type: src_app_services_examine_service__WEBPACK_IMPORTED_MODULE_5__["ExamineService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], ReplyComponent.prototype, "data", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ReplyComponent.prototype, "apo", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('screen', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"])
    ], ReplyComponent.prototype, "screen", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"])
    ], ReplyComponent.prototype, "onSubmit", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"])
    ], ReplyComponent.prototype, "onDataUrl", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"])
    ], ReplyComponent.prototype, "onImgOrVideoComplete", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"])
    ], ReplyComponent.prototype, "onDelTreeNode", void 0);
    ReplyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-reply',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./reply.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/reply/reply.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./reply.component.scss */ "./src/app/component/reply/reply.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["NzMessageService"],
            src_app_services_examine_service__WEBPACK_IMPORTED_MODULE_5__["ExamineService"]])
    ], ReplyComponent);
    return ReplyComponent;
}());

function getBase64(file) {
    return new Promise(function (resolve, reject) {
        var reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () { return resolve(reader.result); };
        reader.onerror = function (error) { return reject(error); };
    });
}


/***/ }),

/***/ "./src/app/component/sku-desc-popup/sku-desc-popup.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/component/sku-desc-popup/sku-desc-popup.component.scss ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-input {\n  border: 1px solid #dedede;\n  width: 260px; }\n\ntable {\n  border-collapse: collapse;\n  text-align: center;\n  padding: 0; }\n\ntable thead th {\n  border: 1px solid #cecece; }\n\ntable thead td {\n  border: 1px solid #cecece; }\n\ntable tbody td {\n  border-bottom: 1px solid #cecece; }\n\n.table2 tr td:nth-child(1) {\n  border-left: 0; }\n\n.table2 tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.table2 tr:nth-child(1) td {\n  border-top: 0; }\n\n.table2 tr:nth-last-child(1) td {\n  border-bottom: 0; }\n\n.table3 tr td:nth-child(1) {\n  border-left: 0; }\n\n.table3 tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.table3 tr:nth-child(1) td {\n  border-top: 0; }\n\n.table3 tr:nth-last-child(1) td {\n  border-bottom: 0; }\n\n.three-table tr td:nth-child(1) {\n  border-left: 0; }\n\n.three-table tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.three-table tr:nth-child(1) td {\n  border-top: 0; }\n\n.three-table tr:nth-last-child(1) td {\n  border-bottom: 0; }\n\n.w20 {\n  width: 20px !important;\n  overflow: hidden; }\n\n.w50 {\n  width: 50px !important;\n  overflow: hidden; }\n\n.w30 {\n  width: 30px !important;\n  overflow: hidden; }\n\n.w60 {\n  width: 60px !important;\n  overflow: hidden; }\n\n.w40 {\n  width: 40px !important;\n  overflow: hidden; }\n\n.w70 {\n  width: 70px !important;\n  overflow: hidden; }\n\n.w80 {\n  width: 80px !important;\n  overflow: hidden; }\n\n.w180 {\n  width: 180px !important;\n  overflow: hidden; }\n\n.w90 {\n  width: 90px !important;\n  overflow: hidden; }\n\n.w100 {\n  width: 100px !important;\n  overflow: hidden; }\n\n.w120 {\n  width: 120px !important;\n  overflow: hidden; }\n\n.w110 {\n  width: 110px !important;\n  overflow: hidden; }\n\n.w220 {\n  width: 220px !important;\n  overflow: hidden; }\n\n.w230 {\n  width: 230px !important;\n  overflow: hidden; }\n\n.w150 {\n  width: 150px !important;\n  overflow: hidden; }\n\n.w200 {\n  width: 200px !important;\n  overflow: hidden; }\n\n.w300 {\n  width: 300px !important;\n  overflow: hidden; }\n\ntd {\n  padding: 0 !important; }\n\n#table1 {\n  min-width: 1000px;\n  width: 1600px; }\n\n.table2 tr {\n  background: transparent !important; }\n\n.swiper-container .swiper-slide {\n  width: 1600px;\n  min-width: 1000px; }\n\n.search-box {\n  width: 1070px; }\n\n.td-overflow-text-btn {\n  height: 36px;\n  width: 36px;\n  text-align: center;\n  line-height: 36px;\n  font-size: 24px;\n  color: #919191;\n  cursor: pointer;\n  background: #f0f0f0;\n  right: 0;\n  top: 0;\n  z-index: 1; }\n\n.name-div,\n.user-div,\n.inspec-no-div,\n.inner-div,\n.address-div,\n.inspec-date-div,\n.probable-date-div {\n  line-height: 36px; }\n\n.name-div {\n  width: 80px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.user-div {\n  width: 100px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.inspec-no-div {\n  width: 120px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.inner-div {\n  width: 180px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.address-div {\n  width: 120px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.inspec-date-div {\n  width: 100px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.probable-date-div {\n  width: 100px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.three-table {\n  table-layout: fixed;\n  width: 350px !important; }\n\n.three-table tr {\n    height: 36px;\n    background: transparent;\n    border: 0; }\n\ntd {\n  border: 1px solid #cecece;\n  box-sizing: border-box !important;\n  height: 36px; }\n\n.choice-date {\n  background: #f3f3f3;\n  color: #555;\n  font-weight: bold;\n  border-radius: 3px;\n  display: flex;\n  align-items: center;\n  justify-content: flex-start; }\n\n.choice-date ion-datetime {\n    --padding-end: 20px;\n    border-radius: 5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9za3UtZGVzYy1wb3B1cC9za3UtZGVzYy1wb3B1cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUF5QjtFQUN6QixZQUFZLEVBQUE7O0FBR2hCO0VBQ0kseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixVQUFVLEVBQUE7O0FBRWQ7RUFDSSx5QkFBeUIsRUFBQTs7QUFFN0I7RUFDSSx5QkFBeUIsRUFBQTs7QUFHN0I7RUFDSSxnQ0FBZ0MsRUFBQTs7QUFFcEM7RUFDSSxjQUFjLEVBQUE7O0FBRWxCO0VBQ0ksZUFBZSxFQUFBOztBQUVuQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxjQUFjLEVBQUE7O0FBRWxCO0VBQ0ksZUFBZSxFQUFBOztBQUVuQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxjQUFjLEVBQUE7O0FBRWxCO0VBQ0ksZUFBZSxFQUFBOztBQUVuQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFPcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBRXBCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHFCQUFxQixFQUFBOztBQUd6QjtFQUNJLGlCQUFpQjtFQUNqQixhQUFhLEVBQUE7O0FBR2pCO0VBRVEsa0NBQWtDLEVBQUE7O0FBSTFDO0VBRVEsYUFBYTtFQUNiLGlCQUFpQixFQUFBOztBQUl6QjtFQUNJLGFBQWEsRUFBQTs7QUFHakI7RUFDSSxZQUFZO0VBQ1osV0FBVztFQUNYLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLGNBQXlCO0VBQ3pCLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIsUUFBUTtFQUNSLE1BQU07RUFDTixVQUFVLEVBQUE7O0FBR2Q7Ozs7Ozs7RUFPSSxpQkFBaUIsRUFBQTs7QUFHckI7RUFDSSxXQUFXO0VBQ1gsTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxtQkFBbUI7RUFDbkIsdUJBQXVCLEVBQUE7O0FBRjNCO0lBSVEsWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixTQUFTLEVBQUE7O0FBR2pCO0VBQ0kseUJBQXlCO0VBQ3pCLGlDQUFpQztFQUNqQyxZQUFZLEVBQUE7O0FBRWhCO0VBQ0ksbUJBQW1CO0VBQ25CLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsMkJBQTJCLEVBQUE7O0FBUC9CO0lBU1EsbUJBQWM7SUFDZCxrQkFBa0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9za3UtZGVzYy1wb3B1cC9za3UtZGVzYy1wb3B1cC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pbnB1dCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2RlZGVkZTtcbiAgICB3aWR0aDogMjYwcHg7XG59XG5cbnRhYmxlIHtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAwO1xufVxudGFibGUgdGhlYWQgdGgge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjZWNlY2U7XG59XG50YWJsZSB0aGVhZCB0ZCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NlY2VjZTtcbn1cblxudGFibGUgdGJvZHkgdGQge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2VjZWNlO1xufVxuLnRhYmxlMiB0ciB0ZDpudGgtY2hpbGQoMSkge1xuICAgIGJvcmRlci1sZWZ0OiAwO1xufVxuLnRhYmxlMiB0ciB0ZDpudGgtbGFzdC1jaGlsZCgxKSB7XG4gICAgYm9yZGVyLXJpZ2h0OiAwO1xufVxuLnRhYmxlMiB0cjpudGgtY2hpbGQoMSkgdGQge1xuICAgIGJvcmRlci10b3A6IDA7XG59XG4udGFibGUyIHRyOm50aC1sYXN0LWNoaWxkKDEpIHRkIHtcbiAgICBib3JkZXItYm90dG9tOiAwO1xufVxuXG4udGFibGUzIHRyIHRkOm50aC1jaGlsZCgxKSB7XG4gICAgYm9yZGVyLWxlZnQ6IDA7XG59XG4udGFibGUzIHRyIHRkOm50aC1sYXN0LWNoaWxkKDEpIHtcbiAgICBib3JkZXItcmlnaHQ6IDA7XG59XG4udGFibGUzIHRyOm50aC1jaGlsZCgxKSB0ZCB7XG4gICAgYm9yZGVyLXRvcDogMDtcbn1cbi50YWJsZTMgdHI6bnRoLWxhc3QtY2hpbGQoMSkgdGQge1xuICAgIGJvcmRlci1ib3R0b206IDA7XG59XG5cbi50aHJlZS10YWJsZSB0ciB0ZDpudGgtY2hpbGQoMSkge1xuICAgIGJvcmRlci1sZWZ0OiAwO1xufVxuLnRocmVlLXRhYmxlIHRyIHRkOm50aC1sYXN0LWNoaWxkKDEpIHtcbiAgICBib3JkZXItcmlnaHQ6IDA7XG59XG4udGhyZWUtdGFibGUgdHI6bnRoLWNoaWxkKDEpIHRkIHtcbiAgICBib3JkZXItdG9wOiAwO1xufVxuLnRocmVlLXRhYmxlIHRyOm50aC1sYXN0LWNoaWxkKDEpIHRkIHtcbiAgICBib3JkZXItYm90dG9tOiAwO1xufVxuXG50ZCB7XG4gICAgLy8gYm9yZGVyOiAxcHggc29saWRcbn1cblxuLncyMCB7XG4gICAgd2lkdGg6IDIwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzUwIHtcbiAgICB3aWR0aDogNTBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MzAge1xuICAgIHdpZHRoOiAzMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnc2MCB7XG4gICAgd2lkdGg6IDYwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzQwIHtcbiAgICB3aWR0aDogNDBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53NzAge1xuICAgIHdpZHRoOiA3MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnc4MCB7XG4gICAgd2lkdGg6IDgwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzE4MCB7XG4gICAgd2lkdGg6IDE4MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnc5MCB7XG4gICAgd2lkdGg6IDkwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzEwMCB7XG4gICAgd2lkdGg6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLncxMjAge1xuICAgIHdpZHRoOiAxMjBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MTEwIHtcbiAgICB3aWR0aDogMTEwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzIyMCB7XG4gICAgd2lkdGg6IDIyMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi53MjMwIHtcbiAgICB3aWR0aDogMjMwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzE1MCB7XG4gICAgd2lkdGg6IDE1MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLncyMDAge1xuICAgIHdpZHRoOiAyMDBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MzAwIHtcbiAgICB3aWR0aDogMzAwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG50ZCB7XG4gICAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xufVxuXG4jdGFibGUxIHtcbiAgICBtaW4td2lkdGg6IDEwMDBweDtcbiAgICB3aWR0aDogMTYwMHB4O1xufVxuXG4udGFibGUyIHtcbiAgICB0ciB7XG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgfVxufVxuXG4uc3dpcGVyLWNvbnRhaW5lciB7XG4gICAgLnN3aXBlci1zbGlkZSB7XG4gICAgICAgIHdpZHRoOiAxNjAwcHg7XG4gICAgICAgIG1pbi13aWR0aDogMTAwMHB4O1xuICAgIH1cbn1cblxuLnNlYXJjaC1ib3gge1xuICAgIHdpZHRoOiAxMDcwcHg7XG59XG5cbi50ZC1vdmVyZmxvdy10ZXh0LWJ0biB7XG4gICAgaGVpZ2h0OiAzNnB4O1xuICAgIHdpZHRoOiAzNnB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMzZweDtcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgY29sb3I6IHJnYigxNDUsIDE0NSwgMTQ1KTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYmFja2dyb3VuZDogI2YwZjBmMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDA7XG4gICAgei1pbmRleDogMTtcbn1cblxuLm5hbWUtZGl2LFxuLnVzZXItZGl2LFxuLmluc3BlYy1uby1kaXYsXG4uaW5uZXItZGl2LFxuLmFkZHJlc3MtZGl2LFxuLmluc3BlYy1kYXRlLWRpdixcbi5wcm9iYWJsZS1kYXRlLWRpdiB7XG4gICAgbGluZS1oZWlnaHQ6IDM2cHg7XG59XG5cbi5uYW1lLWRpdiB7XG4gICAgd2lkdGg6IDgwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnVzZXItZGl2IHtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmluc3BlYy1uby1kaXYge1xuICAgIHdpZHRoOiAxMjBweDtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uaW5uZXItZGl2IHtcbiAgICB3aWR0aDogMTgwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmFkZHJlc3MtZGl2IHtcbiAgICB3aWR0aDogMTIwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmluc3BlYy1kYXRlLWRpdiB7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5wcm9iYWJsZS1kYXRlLWRpdiB7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50aHJlZS10YWJsZSB7XG4gICAgdGFibGUtbGF5b3V0OiBmaXhlZDtcbiAgICB3aWR0aDogMzUwcHggIWltcG9ydGFudDtcbiAgICB0ciB7XG4gICAgICAgIGhlaWdodDogMzZweDtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIGJvcmRlcjogMDtcbiAgICB9XG59XG50ZCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NlY2VjZTtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94ICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiAzNnB4O1xufVxuLmNob2ljZS1kYXRlIHtcbiAgICBiYWNrZ3JvdW5kOiAjZjNmM2YzO1xuICAgIGNvbG9yOiAjNTU1O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgIGlvbi1kYXRldGltZSB7XG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDIwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICB9XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/component/sku-desc-popup/sku-desc-popup.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/component/sku-desc-popup/sku-desc-popup.component.ts ***!
  \**********************************************************************/
/*! exports provided: SkuDescPopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuDescPopupComponent", function() { return SkuDescPopupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var SkuDescPopupComponent = /** @class */ (function () {
    function SkuDescPopupComponent() {
    }
    SkuDescPopupComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
    ], SkuDescPopupComponent.prototype, "skuDesc", void 0);
    SkuDescPopupComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sku-desc-popup',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./sku-desc-popup.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sku-desc-popup/sku-desc-popup.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./sku-desc-popup.component.scss */ "./src/app/component/sku-desc-popup/sku-desc-popup.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SkuDescPopupComponent);
    return SkuDescPopupComponent;
}());



/***/ }),

/***/ "./src/app/component/sku-info/sku-info.component.scss":
/*!************************************************************!*\
  !*** ./src/app/component/sku-info/sku-info.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("img {\n  width: 50px;\n  height: 50px;\n  display: block; }\n\nnz-table table td {\n  text-align: left !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9za3UtaW5mby9za3UtaW5mby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQVc7RUFDWCxZQUFZO0VBQ1osY0FBYyxFQUFBOztBQUdsQjtFQUNJLDJCQUEyQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L3NrdS1pbmZvL3NrdS1pbmZvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW1ne1xuICAgIHdpZHRoOiA1MHB4O1xuICAgIGhlaWdodDogNTBweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbn1cblxubnotdGFibGUgdGFibGUgdGR7XG4gICAgdGV4dC1hbGlnbjogbGVmdCAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/component/sku-info/sku-info.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/component/sku-info/sku-info.component.ts ***!
  \**********************************************************/
/*! exports provided: SkuInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuInfoComponent", function() { return SkuInfoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/base-data.service */ "./src/app/services/base-data.service.ts");



var SkuInfoComponent = /** @class */ (function () {
    function SkuInfoComponent(baseData) {
        this.baseData = baseData;
    }
    Object.defineProperty(SkuInfoComponent.prototype, "contract", {
        set: function (input) {
            if (!!input)
                this._contract = input;
        },
        enumerable: true,
        configurable: true
    });
    SkuInfoComponent.prototype.ngOnInit = function () { };
    SkuInfoComponent.ctorParameters = function () { return [
        { type: src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], SkuInfoComponent.prototype, "contract", null);
    SkuInfoComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sku-info',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./sku-info.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sku-info/sku-info.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./sku-info.component.scss */ "./src/app/component/sku-info/sku-info.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"]])
    ], SkuInfoComponent);
    return SkuInfoComponent;
}());



/***/ }),

/***/ "./src/app/component/sort/sort.component.scss":
/*!****************************************************!*\
  !*** ./src/app/component/sort/sort.component.scss ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".dis-flex {\n  padding: 0 12px;\n  cursor: pointer;\n  width: 100%;\n  align-items: center;\n  justify-content: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC9zb3J0L3NvcnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFlO0VBQ2YsZUFBZTtFQUNmLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnQvc29ydC9zb3J0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRpcy1mbGV4IHtcbiAgICBwYWRkaW5nOiAwIDEycHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/component/sort/sort.component.ts":
/*!**************************************************!*\
  !*** ./src/app/component/sort/sort.component.ts ***!
  \**************************************************/
/*! exports provided: SortComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SortComponent", function() { return SortComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var SortComponent = /** @class */ (function () {
    function SortComponent() {
        this.icon = 'more';
        this.value = '';
        this.sortObj = {
            name: this.sortName,
            value: '',
        };
        this.outFn = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    SortComponent.prototype.change = function () {
        this.sortObj.name = this.sortField;
        switch (this.value) {
            case 'desc':
                this.value = 'asc';
                this.icon = 'arrow-dropup';
                this.sortObj.value = 'asc';
                break;
            case 'asc':
                this.value = '';
                this.icon = 'more';
                this.sortObj.value = '';
                break;
            case '':
                this.value = 'desc';
                this.icon = 'arrow-dropdown';
                this.sortObj.value = 'desc';
        }
        this.outFn.emit(this.sortObj);
    };
    SortComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], SortComponent.prototype, "sortName", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], SortComponent.prototype, "sortField", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], SortComponent.prototype, "outFn", void 0);
    SortComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sort',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./sort.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/sort/sort.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./sort.component.scss */ "./src/app/component/sort/sort.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SortComponent);
    return SortComponent;
}());



/***/ }),

/***/ "./src/app/component/td-overflow-text/td-overflow-text.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/component/td-overflow-text/td-overflow-text.component.scss ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".out-div {\n  top: 0;\n  left: 0;\n  z-index: 2000;\n  padding: 5px;\n  background: #fff;\n  color: #000;\n  font-size: 14px;\n  box-shadow: 2px 2px 5px #333333; }\n\n.close-s {\n  color: #fff;\n  width: 30px;\n  border-radius: 100%;\n  height: 30px;\n  line-height: 22px;\n  background: #666;\n  font-size: 16px;\n  font-weight: bold;\n  right: -15px;\n  top: -15px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC90ZC1vdmVyZmxvdy10ZXh0L3RkLW92ZXJmbG93LXRleHQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxNQUFNO0VBQ04sT0FBTztFQUNQLGFBQWE7RUFDYixZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsK0JBQStCLEVBQUE7O0FBR25DO0VBQ0ksV0FBVztFQUNYLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osVUFBVSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L3RkLW92ZXJmbG93LXRleHQvdGQtb3ZlcmZsb3ctdGV4dC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5vdXQtZGl2IHtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICB6LWluZGV4OiAyMDAwO1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBib3gtc2hhZG93OiAycHggMnB4IDVweCAjMzMzMzMzO1xufVxuXG4uY2xvc2UtcyB7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgd2lkdGg6IDMwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgYmFja2dyb3VuZDogIzY2NjtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcmlnaHQ6IC0xNXB4O1xuICAgIHRvcDogLTE1cHg7XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/component/td-overflow-text/td-overflow-text.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/component/td-overflow-text/td-overflow-text.component.ts ***!
  \**************************************************************************/
/*! exports provided: TdOverflowTextComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TdOverflowTextComponent", function() { return TdOverflowTextComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var TdOverflowTextComponent = /** @class */ (function () {
    function TdOverflowTextComponent() {
        this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    TdOverflowTextComponent.prototype.ngOnInit = function () { };
    TdOverflowTextComponent.prototype.closeTips = function () {
        this.close.emit(true);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], TdOverflowTextComponent.prototype, "text", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], TdOverflowTextComponent.prototype, "close", void 0);
    TdOverflowTextComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-td-overflow-text',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./td-overflow-text.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/td-overflow-text/td-overflow-text.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./td-overflow-text.component.scss */ "./src/app/component/td-overflow-text/td-overflow-text.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], TdOverflowTextComponent);
    return TdOverflowTextComponent;
}());



/***/ }),

/***/ "./src/app/component/track-exclude/track-exclude.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/component/track-exclude/track-exclude.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("nz-table thead tr {\n  height: auto;\n  font-weight: normal;\n  font-size: 14px;\n  color: #404040; }\n\nnz-table tr:nth-child(1n + 0) {\n  background: transparent !important; }\n\nnz-table tr:nth-child(2n + 0) {\n  background: transparent !important; }\n\nnz-table td {\n  text-align: left;\n  vertical-align: middle !important; }\n\n.footer {\n  display: flex;\n  width: 100%;\n  align-items: flex-end;\n  justify-content: space-between; }\n\n.color-red {\n  color: red; }\n\n.m-0 {\n  margin: 0 !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC90cmFjay1leGNsdWRlL3RyYWNrLWV4Y2x1ZGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFUSxZQUFZO0VBQ1osbUJBQW1CO0VBQ25CLGVBQWU7RUFDZixjQUFjLEVBQUE7O0FBTHRCO0VBUVEsa0NBQWtDLEVBQUE7O0FBUjFDO0VBV1Esa0NBQWtDLEVBQUE7O0FBWDFDO0VBY1EsZ0JBQWdCO0VBQ2hCLGlDQUFpQyxFQUFBOztBQUl6QztFQUNJLGFBQWE7RUFDYixXQUFXO0VBQ1gscUJBQXFCO0VBQ3JCLDhCQUE4QixFQUFBOztBQUdsQztFQUNJLFVBQVUsRUFBQTs7QUFJZDtFQUNJLG9CQUFvQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L3RyYWNrLWV4Y2x1ZGUvdHJhY2stZXhjbHVkZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIm56LXRhYmxlIHtcbiAgICB0aGVhZCB0ciB7XG4gICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICBjb2xvcjogIzQwNDA0MDtcbiAgICB9XG4gICAgdHI6bnRoLWNoaWxkKDFuICsgMCkge1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIH1cbiAgICB0cjpudGgtY2hpbGQoMm4gKyAwKSB7XG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIHRkIHtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZSAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxuLmZvb3RlcntcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG5cbi5jb2xvci1yZWR7XG4gICAgY29sb3I6IHJlZDtcbn1cblxuXG4ubS0we1xuICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/component/track-exclude/track-exclude.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/component/track-exclude/track-exclude.component.ts ***!
  \********************************************************************/
/*! exports provided: TrackExcludeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrackExcludeComponent", function() { return TrackExcludeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");





var TrackExcludeComponent = /** @class */ (function () {
    function TrackExcludeComponent(taskService, modalService, baseData, message) {
        this.taskService = taskService;
        this.modalService = modalService;
        this.baseData = baseData;
        this.message = message;
        this.drawerStatus = false;
        this.contract = {
            contract_no: '',
            factory_name: '',
            schedule_list_select: [],
            sku_list: [],
        };
        this.emitStatusFn = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.onSubmit = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    TrackExcludeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.taskService.getNeedSchedule(this.currentContract.id).subscribe(function (data) {
            data.schedule_list_select = _this.takeInverse(data.schedule_list_select);
            data.schedule_list_select.forEach(function (data) {
                data.meta_is_need = data.is_need ? true : false;
            });
            _this.contract = data;
            _this.baseData.printDebug && console.log(data);
        });
    };
    TrackExcludeComponent.prototype.scheduleEditSubmit = function () {
        var _this = this;
        //提交 进度排除项 的内容
        var needScheduleParams = {
            contract_id: this.currentContract.id,
            need_params: [],
        };
        this.contract.schedule_list_select.forEach(function (schedule) {
            needScheduleParams.need_params.push({
                is_need: schedule.is_need ? '0' : '1',
                schedule_id: schedule.id,
            });
        });
        if (this.judgeMaiHeader()) {
            this.taskService.updateNeedSchedule(needScheduleParams).subscribe(function (data) {
                _this.modalService.info({
                    nzTitle: '提示',
                    nzContent: data.message,
                });
                if (data.status == 1) {
                    setTimeout(function () {
                        _this.onSubmit.emit(true);
                    }, 1000);
                }
            });
        }
        else {
            this.modalService.error({
                nzTitle: '提示',
                nzContent: '唛头必须留一个喔！',
            });
        }
    };
    TrackExcludeComponent.prototype.judgeMaiHeader = function () {
        //判断是有留有一个唛头 （合规）
        var some = [], arr = [];
        this.contract.schedule_list_select.forEach(function (value) {
            if (value.description == '说明书/唛头使用TOBBI品牌' ||
                value.description == '说明书/唛头使用JAXPETY品牌' ||
                value.description == '说明书/唛头无需使用我司指定品牌' ||
                value.description == '说明书/唛头使用SANDINRAYLI品牌') {
                arr.push(value);
            }
        });
        some = arr.filter(function (value) {
            return value.is_need;
        });
        return some.length > 2 ? true : false;
    };
    TrackExcludeComponent.prototype.takeInverse = function (statusList) {
        //修改过后的状态 服务器返回的是相反的
        var some = false;
        statusList.forEach(function (value) {
            value.is_need && (some = true);
        });
        if (some) {
            statusList.forEach(function (value) {
                value.is_need = value.is_need ? false : true;
            });
        }
        else {
            statusList.forEach(function (value) {
                value.is_need = value.is_need ? true : false;
            });
        }
        return statusList;
    };
    TrackExcludeComponent.prototype.setStatusJudgeFn = function (p) {
        var arr = [
            '说明书/唛头使用TOBBI品牌',
            '说明书/唛头使用JAXPETY品牌',
            '说明书/唛头使用SANDINRAYLI品牌',
            '说明书/唛头无需使用我司指定品牌',
        ];
        if (arr.indexOf(p.description) != -1) {
            if (!p.is_need && this.judgeMaiHeader()) {
                this.modalService.error({
                    nzTitle: '提示',
                    nzContent: '唛头必须留一个喔！',
                    nzOnOk: function () {
                        debugger;
                        p.is_need = false;
                    },
                });
            }
        }
    };
    TrackExcludeComponent.prototype.consoles = function (e) {
        console.log(e);
    };
    TrackExcludeComponent.prototype.emit = function (value) {
        this.emitStatusFn.emit(value);
    };
    TrackExcludeComponent.prototype.reset = function () { };
    TrackExcludeComponent.prototype.confirm = function () {
        var _this = this;
        this.taskService.resetSchedule(this.currentContract.id).subscribe(function (res) {
            if (res.status) {
                _this.contract.schedule_list_select.forEach(function (schedule) {
                    schedule.is_need = false;
                });
                _this.message.success('更新成功');
            }
            else
                _this.message.success('更新失败');
            _this.onSubmit.emit(true);
        });
    };
    TrackExcludeComponent.prototype.cancel = function () { };
    TrackExcludeComponent.ctorParameters = function () { return [
        { type: src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzModalService"] },
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], TrackExcludeComponent.prototype, "currentContract", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"])
    ], TrackExcludeComponent.prototype, "emitStatusFn", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"])
    ], TrackExcludeComponent.prototype, "onSubmit", void 0);
    TrackExcludeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-track-exclude',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./track-exclude.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/track-exclude/track-exclude.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./track-exclude.component.scss */ "./src/app/component/track-exclude/track-exclude.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzModalService"],
            _services_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"]])
    ], TrackExcludeComponent);
    return TrackExcludeComponent;
}());



/***/ }),

/***/ "./src/app/component/uploadimg/uploadimg.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/component/uploadimg/uploadimg.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".file-box {\n  position: relative; }\n  .file-box input {\n    position: absolute;\n    width: 100%;\n    height: 100%;\n    font-size: 100px;\n    top: 0;\n    left: 0;\n    opacity: 0; }\n  .img-box {\n  width: 100%;\n  max-height: 300px;\n  overflow: hidden; }\n  .img-box li {\n    width: 20%;\n    margin-bottom: 20px;\n    float: left;\n    overflow: hidden;\n    margin-right: 10px;\n    padding: 10px;\n    box-sizing: border-box; }\n  .img-box li img {\n      width: 100%;\n      transform: rotateZ(-90deg);\n      height: auto;\n      max-height: 100px; }\n  .progress {\n  height: 6px; }\n  .program {\n  height: 10px;\n  background: #f00;\n  border-radius: 25px;\n  margin-bottom: 0; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL2NvbXBvbmVudC91cGxvYWRpbWcvdXBsb2FkaW1nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksa0JBQWtCLEVBQUE7RUFGdEI7SUFJUSxrQkFBa0I7SUFDbEIsV0FBVztJQUNYLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVLEVBQUE7RUFHbEI7RUFDSSxXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLGdCQUFnQixFQUFBO0VBSHBCO0lBS1EsVUFBVTtJQUNWLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2Isc0JBQXNCLEVBQUE7RUFYOUI7TUFhWSxXQUFXO01BQ1gsMEJBQTBCO01BQzFCLFlBQVk7TUFDWixpQkFBaUIsRUFBQTtFQUs3QjtFQUNJLFdBQVcsRUFBQTtFQUdmO0VBQ0ksWUFBWTtFQUNaLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsZ0JBQWdCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnQvdXBsb2FkaW1nL3VwbG9hZGltZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5maWxlLWJveCB7XG4gICAgLy8gYm9yZGVyOiAxcHggc29saWQgI2YwMDtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgaW5wdXQge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIGZvbnQtc2l6ZTogMTAwcHg7XG4gICAgICAgIHRvcDogMDtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG59XG4uaW1nLWJveCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWF4LWhlaWdodDogMzAwcHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBsaSB7XG4gICAgICAgIHdpZHRoOiAyMCU7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgICAgIGZsb2F0OiBsZWZ0O1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICAgIGltZyB7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpO1xuICAgICAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICAgICAgbWF4LWhlaWdodDogMTAwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5wcm9ncmVzcyB7XG4gICAgaGVpZ2h0OiA2cHg7XG59XG5cbi5wcm9ncmFtIHtcbiAgICBoZWlnaHQ6IDEwcHg7XG4gICAgYmFja2dyb3VuZDogI2YwMDtcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgIG1hcmdpbi1ib3R0b206IDA7XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/component/uploadimg/uploadimg.component.ts":
/*!************************************************************!*\
  !*** ./src/app/component/uploadimg/uploadimg.component.ts ***!
  \************************************************************/
/*! exports provided: UploadimgComponent, FileOfGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadimgComponent", function() { return UploadimgComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileOfGroup", function() { return FileOfGroup; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng2-file-upload */ "./node_modules/_ng2-file-upload@1.4.0@ng2-file-upload/fesm5/ng2-file-upload.js");





var UploadimgComponent = /** @class */ (function () {
    function UploadimgComponent(baseData, effectCtrl) {
        this.baseData = baseData;
        this.effectCtrl = effectCtrl;
        this.imgUploadList = [
            {
                url: '',
                data: '',
                index: null,
            },
        ];
        this.selectedImgLength = 0;
        this.selectedImgUrl = [];
        this.uploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_4__["FileUploader"]({
            url: this.baseData.apiUrl + '/file/upload',
            method: 'POST',
            isHTML5: true,
            authTokenHeader: 'authorization',
            authToken: 'Bearer ' + this.baseData.userInfo.api_token,
            itemAlias: 'photo',
        });
    }
    UploadimgComponent.prototype.ngOnDestroy = function () {
        this.uploader.destroy();
    };
    UploadimgComponent.prototype.initUploader = function () {
        this.uploader.onBuildItemForm = function (fileItem) {
            console.log(fileItem);
        };
    };
    UploadimgComponent.prototype.selectedFileOnChanged = function () {
        //选中的事件  input  index: number, type: string, e: any
    };
    UploadimgComponent.prototype.upload = function () {
        var params = {
            type: this.uploadField,
            task_id: this.contract_task_info.task_id,
            contract_id: this.contract_task_info.contract_id,
            sku: this.contract_task_info.sku,
        };
        this.contract_task_info.parentSku && (params.parentSku = this.contract_task_info.parentSku);
        this.uploader.setOptions({ additionalParameter: params });
        this.uploader.uploadAll();
    };
    UploadimgComponent.prototype.streamline = function () {
        for (var i = 0; i < this.uploader.queue.length; i++) {
            if (this.uploader.queue[i]) {
            }
        }
    };
    UploadimgComponent.prototype.removeImg = function (img) {
        this.uploader.queue[img.uploadID].remove();
    };
    UploadimgComponent.prototype.ngOnInit = function () {
        this.contract_task_info = JSON.parse(sessionStorage.getItem('TASK_CONTRACT_INFO'));
    };
    UploadimgComponent.ctorParameters = function () { return [
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"])('fileUpLoad', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ElementRef"])
    ], UploadimgComponent.prototype, "fileUpLoad", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], UploadimgComponent.prototype, "uploadField", void 0);
    UploadimgComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-uploadimg',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./uploadimg.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/component/uploadimg/uploadimg.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./uploadimg.component.scss */ "./src/app/component/uploadimg/uploadimg.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"], _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], UploadimgComponent);
    return UploadimgComponent;
}());

var FileOfGroup = /** @class */ (function () {
    function FileOfGroup(photo) {
        this.photo = photo;
    }
    return FileOfGroup;
}());



/***/ }),

/***/ "./src/app/config.ts":
/*!***************************!*\
  !*** ./src/app/config.ts ***!
  \***************************/
/*! exports provided: config */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "config", function() { return config; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");


var config = /** @class */ (function () {
    function config() {
    }
    config.upLoadMaxImgLength = 5; //最多上传图片张数
    config.maxRenewInitRequest = 2; //重新发起请求次数
    config.renewInitRequestTime = 150000000; //重新发起请求间隔
    config.avoidInterception = [src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].apiUrl + '/task/add_inspection_task_review_summary_pic_video'];
    return config;
}());

// TODO 记住页码 （sessionStroge）


/***/ }),

/***/ "./src/app/directive/chipboard.directive.ts":
/*!**************************************************!*\
  !*** ./src/app/directive/chipboard.directive.ts ***!
  \**************************************************/
/*! exports provided: ChipboardDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChipboardDirective", function() { return ChipboardDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var ChipboardDirective = /** @class */ (function () {
    function ChipboardDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.chipboardDestroy = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"](); //just for ‘custom-popup.component’ component's ‘input' element for bug
    }
    ChipboardDirective.prototype.onclick = function (e) {
        this.chipboardDestroy && this.chipboardDestroy.emit(false);
        var $this = this;
        var clickBeforeColor = this.el.nativeElement.style.color;
        this.renderer.setElementStyle(this.el.nativeElement, 'color', 'rgb(51,143,255)');
        var clipText = new ClipboardJS('.chip-text', {
            text: function (trigger) {
                return trigger.innerText;
            },
        });
        // e.stopPropagation()
        clipText.on('success', function (e) {
            setTimeout(function () {
                $this.renderer.setElementStyle($this.el.nativeElement, 'color', clickBeforeColor ? clickBeforeColor : '#333');
                $this.chipboardDestroy && $this.chipboardDestroy.emit(true);
            }, 200);
            clipText.destroy();
        });
    };
    ChipboardDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ChipboardDirective.prototype, "chipboardDestroy", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], ChipboardDirective.prototype, "onclick", null);
    ChipboardDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[Chipboard]',
        })
        //must be input  " class='chip-text' Chipboard"
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer"]])
    ], ChipboardDirective);
    return ChipboardDirective;
}());



/***/ }),

/***/ "./src/app/directive/directive.module.ts":
/*!***********************************************!*\
  !*** ./src/app/directive/directive.module.ts ***!
  \***********************************************/
/*! exports provided: DirectiveModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectiveModule", function() { return DirectiveModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _chipboard_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chipboard.directive */ "./src/app/directive/chipboard.directive.ts");
/* harmony import */ var _input_blur_ver_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./input-blur-ver.directive */ "./src/app/directive/input-blur-ver.directive.ts");
/* harmony import */ var _img_prevload_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./img-prevload.directive */ "./src/app/directive/img-prevload.directive.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _gallery_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./gallery.directive */ "./src/app/directive/gallery.directive.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _mouse_scroll_bar_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./mouse-scroll-bar.directive */ "./src/app/directive/mouse-scroll-bar.directive.ts");
/* harmony import */ var _pipe_filter_text_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../pipe/filter-text.pipe */ "./src/app/pipe/filter-text.pipe.ts");










var DirectiveModule = /** @class */ (function () {
    function DirectiveModule() {
    }
    DirectiveModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
            declarations: [
                _gallery_directive__WEBPACK_IMPORTED_MODULE_6__["GalleryDirective"],
                _img_prevload_directive__WEBPACK_IMPORTED_MODULE_3__["ImgPrevloadDirective"],
                _input_blur_ver_directive__WEBPACK_IMPORTED_MODULE_2__["InputBlurVerDirective"],
                _mouse_scroll_bar_directive__WEBPACK_IMPORTED_MODULE_8__["MouseScrollBarDirective"],
                _chipboard_directive__WEBPACK_IMPORTED_MODULE_1__["ChipboardDirective"],
                _pipe_filter_text_pipe__WEBPACK_IMPORTED_MODULE_9__["FilterTextPipe"],
            ],
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"]],
            exports: [
                _gallery_directive__WEBPACK_IMPORTED_MODULE_6__["GalleryDirective"],
                _img_prevload_directive__WEBPACK_IMPORTED_MODULE_3__["ImgPrevloadDirective"],
                _input_blur_ver_directive__WEBPACK_IMPORTED_MODULE_2__["InputBlurVerDirective"],
                _mouse_scroll_bar_directive__WEBPACK_IMPORTED_MODULE_8__["MouseScrollBarDirective"],
                _chipboard_directive__WEBPACK_IMPORTED_MODULE_1__["ChipboardDirective"],
                _pipe_filter_text_pipe__WEBPACK_IMPORTED_MODULE_9__["FilterTextPipe"],
            ],
        })
    ], DirectiveModule);
    return DirectiveModule;
}());



/***/ }),

/***/ "./src/app/directive/gallery.directive.ts":
/*!************************************************!*\
  !*** ./src/app/directive/gallery.directive.ts ***!
  \************************************************/
/*! exports provided: GalleryDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GalleryDirective", function() { return GalleryDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var GalleryDirective = /** @class */ (function () {
    function GalleryDirective(el) {
        this.el = el;
        this.viewer = new Viewer(this.el.nativeElement, {
            inline: false,
            toolbar: false,
        });
    }
    GalleryDirective.prototype.onclick = function () {
        this.viewer.update();
    };
    GalleryDirective.prototype.ngOnDestroy = function () {
        //销毁viewer
        this.viewer && this.viewer.destroy();
    };
    GalleryDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], GalleryDirective.prototype, "onclick", null);
    GalleryDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[imgGallery]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]])
    ], GalleryDirective);
    return GalleryDirective;
}());



/***/ }),

/***/ "./src/app/directive/img-prevload.directive.ts":
/*!*****************************************************!*\
  !*** ./src/app/directive/img-prevload.directive.ts ***!
  \*****************************************************/
/*! exports provided: ImgPrevloadDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImgPrevloadDirective", function() { return ImgPrevloadDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var ImgPrevloadDirective = /** @class */ (function () {
    function ImgPrevloadDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
    }
    ImgPrevloadDirective.prototype.ngOnChanges = function (changes) {
        var reader = new FileReader();
        var el = this.el;
        reader.onload = function (e) {
            el.nativeElement.src = reader.result;
        };
        if (this.image) {
            return reader.readAsDataURL(this.image);
        }
    };
    ImgPrevloadDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ImgPrevloadDirective.prototype, "image", void 0);
    ImgPrevloadDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: 'img[imgPreview]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer"]])
    ], ImgPrevloadDirective);
    return ImgPrevloadDirective;
}());



/***/ }),

/***/ "./src/app/directive/input-blur-ver.directive.ts":
/*!*******************************************************!*\
  !*** ./src/app/directive/input-blur-ver.directive.ts ***!
  \*******************************************************/
/*! exports provided: InputBlurVerDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputBlurVerDirective", function() { return InputBlurVerDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/page-effect.service */ "./src/app/services/page-effect.service.ts");



var InputBlurVerDirective = /** @class */ (function () {
    function InputBlurVerDirective(el, effectCtrl) {
        this.el = el;
        this.effectCtrl = effectCtrl;
    }
    InputBlurVerDirective.prototype.onBlur = function (btn) {
        if (btn.value) {
            //btn.value
            for (var key in this.inspectoonMetadata.sku_sys) {
                if (key == this.verObject.verField) {
                    if (Number(this.inspectoonMetadata.sku_sys[key]) != NaN) {
                        this.verFieldValue = Number(this.inspectoonMetadata.sku_sys[key]);
                    }
                    else {
                        this.verFieldValue = this.inspectoonMetadata.sku_sys[key];
                    }
                }
            }
            if (btn.value != this.verFieldValue) {
                this.effectCtrl.showAlert({
                    header: '提示',
                    backdropDismiss: false,
                    message: "\u60A8\u8F93\u5165\u7684 " + this.verObject.verName + " \u786E\u5B9A\u662F\u5426\u8F93\u5165\u6B63\u786E\uFF1F",
                    buttons: [
                        {
                            text: '重新输入',
                            role: 'cancel',
                            handler: function () {
                                btn.value = null;
                                btn.focus();
                            },
                        },
                        {
                            text: '正确无误',
                            handler: function () { },
                        },
                    ],
                });
            }
        }
        console.log(btn.innerHTML);
    };
    InputBlurVerDirective.prototype.ngOnInit = function () {
        this.inspectoonMetadata = JSON.parse(sessionStorage.getItem('INSPECTION_META_DATA'));
    };
    InputBlurVerDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], InputBlurVerDirective.prototype, "verObject", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('blur', ['$event.target']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], InputBlurVerDirective.prototype, "onBlur", null);
    InputBlurVerDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[onBlurVer]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"]])
    ], InputBlurVerDirective);
    return InputBlurVerDirective;
}());



/***/ }),

/***/ "./src/app/directive/mouse-scroll-bar.directive.ts":
/*!*********************************************************!*\
  !*** ./src/app/directive/mouse-scroll-bar.directive.ts ***!
  \*********************************************************/
/*! exports provided: MouseScrollBarDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MouseScrollBarDirective", function() { return MouseScrollBarDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var MouseScrollBarDirective = /** @class */ (function () {
    function MouseScrollBarDirective(el) {
        this.el = el;
        this.isDown = false;
        this.distance = 0;
    }
    MouseScrollBarDirective.prototype.onmousedown = function (e) {
        if (e.target.tagName != 'INPUT' || e.target.tagName != 'SELECT') {
            this.isDown = !this.isDown;
        }
        this.distance = e.clientX;
    };
    MouseScrollBarDirective.prototype.mouseover = function (e) {
        if (this.isDown) {
            var clientX = e.clientX;
            var actual = this.distance - clientX; //拖动的距离
            this.el.nativeElement.scrollLeft += actual;
        }
    };
    MouseScrollBarDirective.prototype.mouseleave = function (e) {
        this.isDown = !this.isDown;
        this.distance = 0;
    };
    MouseScrollBarDirective.prototype.mouseup = function (e) {
        this.isDown = !this.isDown;
        this.distance = 0;
    };
    MouseScrollBarDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('mousedown', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], MouseScrollBarDirective.prototype, "onmousedown", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('mouseover', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], MouseScrollBarDirective.prototype, "mouseover", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('mouseleave', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], MouseScrollBarDirective.prototype, "mouseleave", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('mouseup', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], MouseScrollBarDirective.prototype, "mouseup", null);
    MouseScrollBarDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[MouseScrollBar]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]])
    ], MouseScrollBarDirective);
    return MouseScrollBarDirective;
}());



/***/ }),

/***/ "./src/app/guard/login-can-enter.guard.ts":
/*!************************************************!*\
  !*** ./src/app/guard/login-can-enter.guard.ts ***!
  \************************************************/
/*! exports provided: LoginCanEnterGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginCanEnterGuard", function() { return LoginCanEnterGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");



var LoginCanEnterGuard = /** @class */ (function () {
    function LoginCanEnterGuard(Router) {
        this.Router = Router;
    }
    LoginCanEnterGuard.prototype.canActivate = function (route, state) {
        var isLogin = sessionStorage.getItem('USERINFO') != null ? true : false;
        if (isLogin) {
            this.Router.navigate(['/welcome']);
        }
        return !isLogin;
    };
    LoginCanEnterGuard.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    LoginCanEnterGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginCanEnterGuard);
    return LoginCanEnterGuard;
}());



/***/ }),

/***/ "./src/app/guard/login-can-leave.guard.ts":
/*!************************************************!*\
  !*** ./src/app/guard/login-can-leave.guard.ts ***!
  \************************************************/
/*! exports provided: LoginCanLeaveGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginCanLeaveGuard", function() { return LoginCanLeaveGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var LoginCanLeaveGuard = /** @class */ (function () {
    function LoginCanLeaveGuard() {
    }
    LoginCanLeaveGuard.prototype.canDeactivate = function (component, currentRoute, currentState, nextState) {
        var isLogin = sessionStorage.getItem('USERINFO') != null ? true : false;
        return isLogin;
    };
    LoginCanLeaveGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        })
    ], LoginCanLeaveGuard);
    return LoginCanLeaveGuard;
}());



/***/ }),

/***/ "./src/app/guard/login.guard.ts":
/*!**************************************!*\
  !*** ./src/app/guard/login.guard.ts ***!
  \**************************************/
/*! exports provided: LoginGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginGuard", function() { return LoginGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");




var LoginGuard = /** @class */ (function () {
    function LoginGuard(Router, effectCtrl) {
        this.Router = Router;
        this.effectCtrl = effectCtrl;
    }
    LoginGuard.prototype.canActivate = function (route, state) {
        var _this = this;
        var isLogin = sessionStorage.getItem('USERINFO') != null ? true : false;
        if (!isLogin) {
            this.effectCtrl.showAlert({
                header: '提示',
                message: '登录失效，请重新登录',
                backdropDismiss: false,
                buttons: [
                    {
                        text: '确定',
                        handler: function () {
                            _this.Router.navigate(['/login']);
                        },
                    },
                ],
            });
        }
        return isLogin;
    };
    LoginGuard.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    LoginGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], LoginGuard);
    return LoginGuard;
}());



/***/ }),

/***/ "./src/app/layout/layout/router.ts":
/*!*****************************************!*\
  !*** ./src/app/layout/layout/router.ts ***!
  \*****************************************/
/*! exports provided: SimpleReuseStrategy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimpleReuseStrategy", function() { return SimpleReuseStrategy; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");

/**
 * 路由重用策略
 */
var SimpleReuseStrategy = /** @class */ (function () {
    function SimpleReuseStrategy() {
    }
    /**
     * 从缓存中获取快照
     * @param {ActivatedRouteSnapshot} route
     * @return {DetachedRouteHandle | null}
     */
    SimpleReuseStrategy.prototype.retrieve = function (route) {
        return route.routeConfig ? SimpleReuseStrategy.snapshots[route.routeConfig.path] : null;
    };
    /**
     * 是否允许还原
     * @param {ActivatedRouteSnapshot} route
     * @return {boolean} true-允许还原
     */
    SimpleReuseStrategy.prototype.shouldAttach = function (route) {
        return route.routeConfig && SimpleReuseStrategy.snapshots[route.routeConfig.path] ? true : false;
    };
    /**
     * 确定是否应该分离此路由（及其子树）以便以后重用
     * @param {ActivatedRouteSnapshot} route
     * @return {boolean}
     */
    SimpleReuseStrategy.prototype.shouldDetach = function (route) {
        // useCache 为自定义数据
        return route.routeConfig && route.routeConfig.data && route.routeConfig.data.useCache;
    };
    /**
     * 进入路由触发, 判断是否为同一路由
     * @param {ActivatedRouteSnapshot} future
     * @param {ActivatedRouteSnapshot} curr
     * @return {boolean}
     */
    SimpleReuseStrategy.prototype.shouldReuseRoute = function (future, curr) {
        // future - 未来的(下一个)路由快照
        return future.routeConfig === curr.routeConfig;
    };
    /**
     * 保存路由
     * @param {ActivatedRouteSnapshot} route
     * @param {DetachedRouteHandle | null} handle
     */
    SimpleReuseStrategy.prototype.store = function (route, handle) {
        // 通过 Route.path 映射路由快照, 一定要确保它的唯一性
        // 也可以通过 route.routeConfig.data.uid 或其他可以确定唯一性的数据作为映射key
        // 作者这里能够确保 path 的唯一性
        SimpleReuseStrategy.snapshots[route.routeConfig.path] = handle;
    };
    // 保存路由快照
    // [key:string] 键为字符串类型
    // DetachedRouteHandle 值为路由处理器
    SimpleReuseStrategy.snapshots = {};
    return SimpleReuseStrategy;
}());



/***/ }),

/***/ "./src/app/layout/theme.service.ts":
/*!*****************************************!*\
  !*** ./src/app/layout/theme.service.ts ***!
  \*****************************************/
/*! exports provided: themes, ThemeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "themes", function() { return themes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThemeService", function() { return ThemeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");



var themes = ['dark', 'secondary', 'tertiary', 'light', 'medium', 'primary'];
var ThemeService = /** @class */ (function () {
    function ThemeService() {
        var _this = this;
        this.themes = themes;
        this.theme = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        setTimeout(function () {
            _this.theme.next(_this.themes[0]);
        }, 1000);
    }
    ThemeService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ThemeService);
    return ThemeService;
}());



/***/ }),

/***/ "./src/app/pages/create-inspec-batch/create-inspec-batch.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/pages/create-inspec-batch/create-inspec-batch.page.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("table {\n  border-collapse: collapse;\n  text-align: center;\n  padding: 0;\n  word-break: break-all; }\n\ntable thead td {\n  border: 1px solid #cecece; }\n\ntable tbody td {\n  border-bottom: 1px solid #cecece; }\n\n.table2 tr td:nth-child(1) {\n  border-left: 0; }\n\n.table2 tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.table2 tr:nth-child(1) td {\n  border-top: 0; }\n\n.table2 tr:nth-last-child(1) td {\n  border-bottom: 0; }\n\n.table3 tr td:nth-child(1) {\n  border-left: 0; }\n\n.table3 tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.table3 tr:nth-child(1) td {\n  border-top: 0; }\n\n.table3 tr:last-child td {\n  border-bottom: 0; }\n\n.w180 {\n  width: 180px !important;\n  overflow: hidden; }\n\n.three-table tr td:nth-child(1) {\n  border-left: 0; }\n\n.three-table tr td:nth-last-child(1) {\n  border-right: 0; }\n\n.three-table tr:nth-child(1) td {\n  border-top: 0; }\n\n.three-table tr:last-child td {\n  border-bottom: 0; }\n\n.w20 {\n  width: 20px !important;\n  overflow: hidden; }\n\n.w50 {\n  width: 50px !important;\n  overflow: hidden; }\n\n.w30 {\n  width: 30px !important;\n  overflow: hidden; }\n\n.w60 {\n  width: 60px !important;\n  overflow: hidden; }\n\n.w40 {\n  width: 40px !important;\n  overflow: hidden; }\n\n.w70 {\n  width: 70px !important;\n  overflow: hidden; }\n\n.w80 {\n  width: 80px !important;\n  overflow: hidden; }\n\n.w90 {\n  width: 90px !important;\n  overflow: hidden; }\n\n.w100 {\n  width: 100px !important;\n  overflow: hidden; }\n\n.w120 {\n  width: 120px !important;\n  overflow: hidden; }\n\n.w110 {\n  width: 110px !important;\n  overflow: hidden; }\n\n.w220 {\n  width: 220px !important;\n  overflow: hidden; }\n\n.w230 {\n  width: 230px !important;\n  overflow: hidden; }\n\n.w150 {\n  width: 150px !important;\n  overflow: hidden; }\n\n.w870 {\n  width: 870px !important;\n  overflow: hidden; }\n\n.w200 {\n  width: 200px !important;\n  overflow: hidden; }\n\ntd {\n  padding: 0 !important;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden; }\n\n#table1 {\n  min-width: 1000px;\n  width: 1740px; }\n\n.table2 tr {\n  background: transparent !important; }\n\ntd {\n  border: 1px solid #cecece;\n  box-sizing: border-box !important;\n  height: 36px; }\n\n.swiper-container {\n  min-height: 0;\n  height: calc(100% - 200px); }\n\n.swiper-container .swiper-slide {\n    width: 1740px !important;\n    min-width: 1000px; }\n\n.search-box {\n  width: 1070px; }\n\n.table-text-no-break {\n  table-layout: fixed !important; }\n\n.name-div,\n.user-div,\n.inspec-no-div,\n.inner-div,\n.address-div,\n.inspec-date-div,\n.probable-date-div {\n  line-height: 36px; }\n\n.name-div {\n  width: 80px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.user-div {\n  width: 100px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.inspec-no-div {\n  width: 120px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.inner-div {\n  width: 180px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.address-div {\n  width: 120px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.inspec-date-div {\n  width: 100px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.probable-date-div {\n  width: 200px;\n  top: 0;\n  left: 0;\n  overflow: hidden; }\n\n.td-overflow-text-btn {\n  height: 36px;\n  width: 36px;\n  text-align: center;\n  line-height: 36px;\n  font-size: 24px;\n  color: #919191;\n  cursor: pointer;\n  background: #f0f0f0;\n  right: 0;\n  top: 0;\n  z-index: 1; }\n\n.three-table {\n  table-layout: fixed;\n  width: 350px; }\n\n.three-table tr {\n    border-bottom: 1px solid #cecece;\n    height: 36px;\n    background: transparent; }\n\n.three-table tr:last-child {\n    border: 0; }\n\n.word-break {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL3BhZ2VzL2NyZWF0ZS1pbnNwZWMtYmF0Y2gvY3JlYXRlLWluc3BlYy1iYXRjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixxQkFBcUIsRUFBQTs7QUFFekI7RUFDSSx5QkFBeUIsRUFBQTs7QUFHN0I7RUFDSSxnQ0FBZ0MsRUFBQTs7QUFFcEM7RUFDSSxjQUFjLEVBQUE7O0FBRWxCO0VBQ0ksZUFBZSxFQUFBOztBQUVuQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxjQUFjLEVBQUE7O0FBRWxCO0VBQ0ksZUFBZSxFQUFBOztBQUVuQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksY0FBYyxFQUFBOztBQUVsQjtFQUNJLGVBQWUsRUFBQTs7QUFFbkI7RUFDSSxhQUFhLEVBQUE7O0FBRWpCO0VBQ0ksZ0JBQWdCLEVBQUE7O0FBRXBCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxzQkFBc0I7RUFDdEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHNCQUFzQjtFQUN0QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBRXBCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSx1QkFBdUI7RUFDdkIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLHFCQUFxQjtFQUdyQixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLGlCQUFpQjtFQUNqQixhQUFhLEVBQUE7O0FBR2pCO0VBRVEsa0NBQWtDLEVBQUE7O0FBSTFDO0VBQ0kseUJBQXlCO0VBQ3pCLGlDQUFpQztFQUNqQyxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksYUFBYTtFQUNiLDBCQUEwQixFQUFBOztBQUY5QjtJQUlRLHdCQUF3QjtJQUN4QixpQkFBaUIsRUFBQTs7QUFJekI7RUFDSSxhQUFhLEVBQUE7O0FBR2pCO0VBQ0ksOEJBQThCLEVBQUE7O0FBR2xDOzs7Ozs7O0VBT0ksaUJBQWlCLEVBQUE7O0FBR3JCO0VBQ0ksV0FBVztFQUNYLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLE1BQU07RUFDTixPQUFPO0VBQ1AsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZixjQUF5QjtFQUN6QixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLFFBQVE7RUFDUixNQUFNO0VBQ04sVUFBVSxFQUFBOztBQUVkO0VBQ0ksbUJBQW1CO0VBQ25CLFlBQVksRUFBQTs7QUFGaEI7SUFJUSxnQ0FBZ0M7SUFDaEMsWUFBWTtJQUNaLHVCQUF1QixFQUFBOztBQU4vQjtJQVNRLFNBQVMsRUFBQTs7QUFJakI7RUFDSSxXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jcmVhdGUtaW5zcGVjLWJhdGNoL2NyZWF0ZS1pbnNwZWMtYmF0Y2gucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgd29yZC1icmVhazogYnJlYWstYWxsO1xufVxudGFibGUgdGhlYWQgdGQge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjZWNlY2U7XG59XG5cbnRhYmxlIHRib2R5IHRkIHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NlY2VjZTtcbn1cbi50YWJsZTIgdHIgdGQ6bnRoLWNoaWxkKDEpIHtcbiAgICBib3JkZXItbGVmdDogMDtcbn1cbi50YWJsZTIgdHIgdGQ6bnRoLWxhc3QtY2hpbGQoMSkge1xuICAgIGJvcmRlci1yaWdodDogMDtcbn1cbi50YWJsZTIgdHI6bnRoLWNoaWxkKDEpIHRkIHtcbiAgICBib3JkZXItdG9wOiAwO1xufVxuLnRhYmxlMiB0cjpudGgtbGFzdC1jaGlsZCgxKSB0ZCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbn1cblxuLnRhYmxlMyB0ciB0ZDpudGgtY2hpbGQoMSkge1xuICAgIGJvcmRlci1sZWZ0OiAwO1xufVxuLnRhYmxlMyB0ciB0ZDpudGgtbGFzdC1jaGlsZCgxKSB7XG4gICAgYm9yZGVyLXJpZ2h0OiAwO1xufVxuLnRhYmxlMyB0cjpudGgtY2hpbGQoMSkgdGQge1xuICAgIGJvcmRlci10b3A6IDA7XG59XG4udGFibGUzIHRyOmxhc3QtY2hpbGQgdGQge1xuICAgIGJvcmRlci1ib3R0b206IDA7XG59XG5cbi53MTgwIHtcbiAgICB3aWR0aDogMTgwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udGhyZWUtdGFibGUgdHIgdGQ6bnRoLWNoaWxkKDEpIHtcbiAgICBib3JkZXItbGVmdDogMDtcbn1cbi50aHJlZS10YWJsZSB0ciB0ZDpudGgtbGFzdC1jaGlsZCgxKSB7XG4gICAgYm9yZGVyLXJpZ2h0OiAwO1xufVxuLnRocmVlLXRhYmxlIHRyOm50aC1jaGlsZCgxKSB0ZCB7XG4gICAgYm9yZGVyLXRvcDogMDtcbn1cbi50aHJlZS10YWJsZSB0cjpsYXN0LWNoaWxkIHRkIHtcbiAgICBib3JkZXItYm90dG9tOiAwO1xufVxuLncyMCB7XG4gICAgd2lkdGg6IDIwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzUwIHtcbiAgICB3aWR0aDogNTBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MzAge1xuICAgIHdpZHRoOiAzMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnc2MCB7XG4gICAgd2lkdGg6IDYwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzQwIHtcbiAgICB3aWR0aDogNDBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53NzAge1xuICAgIHdpZHRoOiA3MHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnc4MCB7XG4gICAgd2lkdGg6IDgwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzkwIHtcbiAgICB3aWR0aDogOTBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MTAwIHtcbiAgICB3aWR0aDogMTAwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzEyMCB7XG4gICAgd2lkdGg6IDEyMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLncxMTAge1xuICAgIHdpZHRoOiAxMTBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MjIwIHtcbiAgICB3aWR0aDogMjIwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLncyMzAge1xuICAgIHdpZHRoOiAyMzBweCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi53MTUwIHtcbiAgICB3aWR0aDogMTUwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzg3MHtcbiAgICB3aWR0aDogODcwcHggIWltcG9ydGFudDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udzIwMCB7XG4gICAgd2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxudGQge1xuICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcblxuICAgIC8vIG92ZXJmbG93OiB1bnNldCAhaW1wb3J0YW50O1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuI3RhYmxlMSB7XG4gICAgbWluLXdpZHRoOiAxMDAwcHg7XG4gICAgd2lkdGg6IDE3NDBweDtcbn1cblxuLnRhYmxlMiB7XG4gICAgdHIge1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxudGQge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjZWNlY2U7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveCAhaW1wb3J0YW50O1xuICAgIGhlaWdodDogMzZweDtcbn1cblxuLnN3aXBlci1jb250YWluZXIge1xuICAgIG1pbi1oZWlnaHQ6IDA7XG4gICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAyMDBweCk7XG4gICAgLnN3aXBlci1zbGlkZSB7XG4gICAgICAgIHdpZHRoOiAxNzQwcHggIWltcG9ydGFudDtcbiAgICAgICAgbWluLXdpZHRoOiAxMDAwcHg7XG4gICAgfVxufVxuXG4uc2VhcmNoLWJveCB7XG4gICAgd2lkdGg6IDEwNzBweDtcbn1cblxuLnRhYmxlLXRleHQtbm8tYnJlYWsge1xuICAgIHRhYmxlLWxheW91dDogZml4ZWQgIWltcG9ydGFudDtcbn1cblxuLm5hbWUtZGl2LFxuLnVzZXItZGl2LFxuLmluc3BlYy1uby1kaXYsXG4uaW5uZXItZGl2LFxuLmFkZHJlc3MtZGl2LFxuLmluc3BlYy1kYXRlLWRpdixcbi5wcm9iYWJsZS1kYXRlLWRpdiB7XG4gICAgbGluZS1oZWlnaHQ6IDM2cHg7XG59XG5cbi5uYW1lLWRpdiB7XG4gICAgd2lkdGg6IDgwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnVzZXItZGl2IHtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmluc3BlYy1uby1kaXYge1xuICAgIHdpZHRoOiAxMjBweDtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uaW5uZXItZGl2IHtcbiAgICB3aWR0aDogMTgwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmFkZHJlc3MtZGl2IHtcbiAgICB3aWR0aDogMTIwcHg7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmluc3BlYy1kYXRlLWRpdiB7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5wcm9iYWJsZS1kYXRlLWRpdiB7XG4gICAgd2lkdGg6IDIwMHB4O1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50ZC1vdmVyZmxvdy10ZXh0LWJ0biB7XG4gICAgaGVpZ2h0OiAzNnB4O1xuICAgIHdpZHRoOiAzNnB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMzZweDtcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgY29sb3I6IHJnYigxNDUsIDE0NSwgMTQ1KTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYmFja2dyb3VuZDogI2YwZjBmMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDA7XG4gICAgei1pbmRleDogMTtcbn1cbi50aHJlZS10YWJsZSB7XG4gICAgdGFibGUtbGF5b3V0OiBmaXhlZDtcbiAgICB3aWR0aDogMzUwcHg7XG4gICAgdHIge1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NlY2VjZTtcbiAgICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICB9XG4gICAgdHI6bGFzdC1jaGlsZCB7XG4gICAgICAgIGJvcmRlcjogMDtcbiAgICB9XG59XG5cbi53b3JkLWJyZWFre1xuICAgIHdpZHRoOiAxMDAlO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/create-inspec-batch/create-inspec-batch.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/create-inspec-batch/create-inspec-batch.page.ts ***!
  \***********************************************************************/
/*! exports provided: CreateInspecBatchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateInspecBatchPage", function() { return CreateInspecBatchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_global_redo_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/global-redo.service */ "./src/app/services/global-redo.service.ts");
/* harmony import */ var _services_user_limit_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/user-limit.service */ "./src/app/services/user-limit.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var src_app_component_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/component/custom-popup/custom-popup.component */ "./src/app/component/custom-popup/custom-popup.component.ts");
/* harmony import */ var ag_grid_enterprise__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ag-grid-enterprise */ "./node_modules/_ag-grid-enterprise@21.2.2@ag-grid-enterprise/main.js");
/* harmony import */ var ag_grid_enterprise__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(ag_grid_enterprise__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var src_app_component_confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/component/confirmed-popupbox/confirmed-popupbox.component */ "./src/app/component/confirmed-popupbox/confirmed-popupbox.component.ts");
/* harmony import */ var src_app_component_confirmed_inspect_confirmed_inspect_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/component/confirmed-inspect/confirmed-inspect.component */ "./src/app/component/confirmed-inspect/confirmed-inspect.component.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");














var CreateInspecBatchPage = /** @class */ (function () {
    function CreateInspecBatchPage(router, userLimit, datePipe, baseData, inspectService, effectCtrl, globalRedo, msg) {
        var _this = this;
        this.router = router;
        this.userLimit = userLimit;
        this.datePipe = datePipe;
        this.baseData = baseData;
        this.inspectService = inspectService;
        this.effectCtrl = effectCtrl;
        this.globalRedo = globalRedo;
        this.msg = msg;
        this.swiperConfig = {};
        this.inspecGroup = [];
        this.getListParams = {
            type: 'contract_no',
            keywords: '',
            order_by: '',
            inspection_group_no_order_by: '',
            page: 1,
        };
        this.currentHoverItem = {
            id: null,
        };
        this.contracts = {
            last_page: 1,
        };
        this.tableWidth = 0;
        this.tableColSpanThreeWidth = 0;
        this.tableColSpanSixWidth = 0;
        this.tableColSpanTwoWidth = 0;
        this.twoColSpan = 0;
        this.sixColSpan = 0;
        this.threeColSpan = 0;
        this.globalRedo.refresh.subscribe(function (res) {
            if (!res)
                return;
            if (res.uid == 209) {
                _this.ngOnInit();
            }
        });
    }
    CreateInspecBatchPage.prototype.ngOnInit = function () {
        this.getinpectionGroup();
        this.swiperConfig = this.baseData.utilFn.getSwiperPublicConfig();
        this.setTableWidth();
    };
    CreateInspecBatchPage.prototype.setTableWidth = function () {
        var _this = this;
        this.tableWidth = 400;
        this.tableColSpanThreeWidth = 0;
        this.tableColSpanSixWidth = 200;
        this.tableColSpanTwoWidth = 0;
        this.twoColSpan = 0;
        this.threeColSpan = 0;
        this.sixColSpan = 0;
        var table = [
            {
                name: '验货人',
                width: 100,
                permission: 'inspector',
            },
            {
                name: '批次号',
                width: 120,
                permission: 'inspection-group-no',
            },
            {
                name: '最早可验货时间',
                width: 100,
                permission: 'earliest-inspection-time',
            },
            {
                name: '计划验货时间',
                width: 200,
                permission: 'inspection-time',
            },
            {
                name: '工厂名称',
                width: 180,
                permission: 'factory-name',
            },
            {
                name: '工厂地址',
                width: 100,
                permission: 'factory-address',
            },
            {
                name: '验货SKU数',
                width: 90,
                permission: 'inspection-sku-quantity',
            },
            {
                name: '备注',
                width: 100,
                permission: 'desc',
            },
            {
                name: '货号',
                width: 150,
                permission: 'sku',
            },
            {
                name: '货号备注',
                width: 200,
                permission: 'sku-desc',
            },
        ];
        table.forEach(function (td) {
            _this.userLimit.has(td.permission, 42) && (_this.tableWidth += td.width);
            if (td.name === '备注' || td.name === '货号' || td.name === '货号备注') {
                _this.userLimit.has(td.permission, 42) && _this.threeColSpan++;
                _this.userLimit.has(td.permission, 42) && (_this.tableColSpanThreeWidth += td.width);
                if (td.name === '货号' || td.name === '货号备注') {
                    _this.userLimit.has(td.permission, 42) && _this.twoColSpan++;
                    _this.userLimit.has(td.permission, 42) && (_this.tableColSpanTwoWidth += td.width);
                }
            }
            if (td.name === '最早验货时间' ||
                td.name === '计划验货时间' ||
                td.name === '工厂名' ||
                td.name === '工厂地址' ||
                td.name === '验货数') {
                _this.userLimit.has(td.permission, 42) && _this.sixColSpan++;
                _this.userLimit.has(td.permission, 42) && (_this.tableColSpanSixWidth += td.width);
            }
            !_this.userLimit.has(td.permission, 42) && console.log(td);
        });
        console.log(this.tableWidth, this.tableColSpanTwoWidth, this.tableColSpanThreeWidth, this.tableColSpanSixWidth);
    };
    CreateInspecBatchPage.prototype.getinpectionGroup = function (e) {
        var _this = this;
        e && (this.getListParams[e.name] = e.value);
        this.inspectService.getDistributedList(this.getListParams).subscribe(function (data) {
            _this.contracts = data;
            _this.inspecGroup = data.data;
            _this.inspecGroup.forEach(function (group) {
                group.apply_inspections.forEach(function (factory) {
                    if (group.info && group.info.length) {
                        group.info.forEach(function (info) {
                            if (factory.factory_name == info.factory_name) {
                                factory.date = info.date;
                                factory.desc = info.desc;
                            }
                        });
                    }
                    if (group.inspection_date && group.inspection_date.length) {
                        group.inspection_date.forEach(function (factoryInspectDate) {
                            if (factory.factory_name == factoryInspectDate.factory_name) {
                                factory.inspection_date = factoryInspectDate.inspection_date;
                            }
                        });
                    }
                });
            });
            _this.baseData.printDebug && console.log(data.data);
        });
    };
    CreateInspecBatchPage.prototype.getListByPaging = function (e) {
        this.getListParams.page = e.pageNum;
        this.getinpectionGroup();
    };
    CreateInspecBatchPage.prototype.seeSku = function (p) {
        var option = {
            component: src_app_component_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_8__["CustomPopupComponent"],
            cssClass: 'modal_a',
            componentProps: { contract: p, showType: 'list' },
        };
        this.effectCtrl.showModal(option);
    };
    CreateInspecBatchPage.prototype.seeDetail = function (p) {
        var option = {
            component: src_app_component_confirmed_popupbox_confirmed_popupbox_component__WEBPACK_IMPORTED_MODULE_11__["ConfirmedPopupBoxComponent"],
            componentProps: { contract: p },
            cssClass: 'see-confirmed',
        };
        this.effectCtrl.showModal(option);
    };
    CreateInspecBatchPage.prototype.seeOrder = function (p) {
        sessionStorage.setItem('DISTRIB-CONTRACT-INFO', JSON.stringify(p));
        this.router.navigate(['dashboard/distrib-to-user', p.id, 'list']);
    };
    CreateInspecBatchPage.prototype.revokeTask = function (p, type) {
        var _this = this;
        this.effectCtrl.showAlert({
            header: '提示',
            message: '确定要撤销此合同吗？',
            buttons: [
                {
                    text: '取消',
                    role: 'cancel',
                },
                {
                    text: '确定',
                    handler: function () {
                        _this.inspectService.cancelDistribInspection(p.id).subscribe(function (data) {
                            _this.effectCtrl.showAlert({
                                header: '提示',
                                message: data.message,
                            });
                            if (data.status == 1) {
                                _this.getinpectionGroup();
                            }
                        });
                    },
                },
            ],
        });
    };
    CreateInspecBatchPage.prototype.getListBySearch = function () {
        if (this.getListParams.type == '') {
            this.effectCtrl.clearEffectCtrl();
            this.msg.error('请选择搜索类型');
            return;
        }
        this.getinpectionGroup();
    };
    CreateInspecBatchPage.prototype.segmentChange = function () {
        if (this.getListParams.keywords) {
            this.getinpectionGroup();
        }
    };
    Object.defineProperty(CreateInspecBatchPage.prototype, "chinaeseType", {
        get: function () {
            var type = '';
            switch (this.getListParams.type) {
                case 'contract_no':
                    type = '合同号';
                    break;
                case 'manufacturer':
                    type = '工厂名称';
                    break;
                case 'factory_simple_address':
                    type = '工厂地址';
                    break;
                case 'user_name':
                    type = '验货人';
            }
            return type;
        },
        enumerable: true,
        configurable: true
    });
    CreateInspecBatchPage.prototype.enterReceiving = function (p) {
        var _this = this;
        var option = {
            component: src_app_component_confirmed_inspect_confirmed_inspect_component__WEBPACK_IMPORTED_MODULE_12__["confirmedInspectComponent"],
            componentProps: { group: p },
            cssClass: 'comfirm-confirmed',
        };
        this.effectCtrl.showModal(option, function (data) {
            _this.getinpectionGroup();
        });
    };
    CreateInspecBatchPage.prototype.setItemTipsShow = function (e, p) {
        e.stopPropagation();
        p.show_factory_tips = true;
    };
    CreateInspecBatchPage.prototype.cellClicked = function (e) {
        if (e.event.target.localName == 'ion-button') {
            if (e.event.target.innerText == '确认验货') {
                this.enterReceiving(e.data);
                this.baseData.printDebug && console.log(e, '确认验货');
            }
            else {
                this.revokeTask(e.data, 'group');
                this.baseData.printDebug && console.log(e, '撤销验货');
            }
        }
    };
    CreateInspecBatchPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
        { type: _services_user_limit_service__WEBPACK_IMPORTED_MODULE_2__["UserLimitService"] },
        { type: _angular_common__WEBPACK_IMPORTED_MODULE_10__["DatePipe"] },
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_4__["BaseDataService"] },
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_6__["InspectionService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"] },
        { type: _services_global_redo_service__WEBPACK_IMPORTED_MODULE_1__["GlobalRedoService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_13__["NzMessageService"] }
    ]; };
    CreateInspecBatchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: 'app-create-inspec-batch',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./create-inspec-batch.page.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/create-inspec-batch/create-inspec-batch.page.html")).default,
            providers: [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DatePipe"]],
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./create-inspec-batch.page.scss */ "./src/app/pages/create-inspec-batch/create-inspec-batch.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
            _services_user_limit_service__WEBPACK_IMPORTED_MODULE_2__["UserLimitService"],
            _angular_common__WEBPACK_IMPORTED_MODULE_10__["DatePipe"],
            _services_base_data_service__WEBPACK_IMPORTED_MODULE_4__["BaseDataService"],
            src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_6__["InspectionService"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"],
            _services_global_redo_service__WEBPACK_IMPORTED_MODULE_1__["GlobalRedoService"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_13__["NzMessageService"]])
    ], CreateInspecBatchPage);
    return CreateInspecBatchPage;
}());



/***/ }),

/***/ "./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.scss ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".clearfix:after {\n  content: '';\n  display: block;\n  clear: both; }\n\n.box {\n  padding: 55px 10px 0 10px;\n  width: 100%;\n  box-sizing: border-box;\n  height: 100%; }\n\n.pb-80 {\n  padding-bottom: 80px; }\n\n.box.has-mb > div {\n  margin-bottom: 80px !important; }\n\n.f-r {\n  float: right; }\n\n.close-box {\n  background: #fff;\n  z-index: 200002;\n  box-shadow: 2px 2px 10px #555;\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n  height: 55px;\n  width: 100%;\n  position: fixed;\n  top: 0;\n  padding: 0 10px;\n  left: 0; }\n\n.no-data {\n  text-align: center;\n  margin-top: 50px; }\n\n.table {\n  width: auto;\n  min-width: 100%;\n  color: #666;\n  text-align: center; }\n\n.table thead {\n    padding: 10px 0;\n    border-top: 1px solid #666;\n    border-bottom: 1px solid #666; }\n\n.table td {\n    text-align: center;\n    vertical-align: middle !important; }\n\n.table td input {\n      width: 100px;\n      text-align: center;\n      height: 50px; }\n\n.table td.remark {\n    text-align: left; }\n\n.table td.remark ion-textarea {\n      border-radius: 5px;\n      border: 1px double #ccc;\n      width: 120px;\n      height: 60px; }\n\n.table .uploadfile .pos-r {\n    overflow: hidden; }\n\n.table .uploadfile .pos-r input[type='file'] {\n      opacity: 0;\n      font-size: 100px;\n      top: 0;\n      left: 0; }\n\n.table .uploadfile .img-responsive {\n    height: 50px !important; }\n\n.text-c {\n  text-align: center; }\n\n.bot-box {\n  padding: 0 10px;\n  height: 80px;\n  background: #fff;\n  z-index: 200002;\n  box-shadow: 2px 2px 10px #555;\n  position: fixed;\n  bottom: 0;\n  width: 100%; }\n\n.bot-box .choice-date {\n    background: #fff;\n    color: #555;\n    border-radius: 3px;\n    display: flex;\n    align-items: center;\n    justify-content: flex-start; }\n\n.bot-box .choice-date ion-datetime {\n      --padding-end: 20px;\n      border-radius: 5px; }\n\n.thumbnail {\n  width: 50px;\n  height: 50px; }\n\nh6 {\n  margin-bottom: 20px;\n  color: #555; }\n\n.select-text-c {\n  text-align: center;\n  -moz-text-align-last: center;\n       text-align-last: center; }\n\n.wd-50 {\n  width: 50px;\n  height: 50px !important; }\n\n.wd-5 {\n  height: 50px !important;\n  width: 5px; }\n\n.hg-0 {\n  height: 0px; }\n\n.wd-he-150 {\n  width: 100px;\n  display: inline;\n  height: 50px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL3BhZ2VzL2Rpc3RyaWItc2VlLW9yZGVyLWRldGFpbC9kaXN0cmliLXNlZS1vcmRlci1kZXRhaWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFXO0VBQ1gsY0FBYztFQUNkLFdBQVcsRUFBQTs7QUFHZjtFQUNJLHlCQUF5QjtFQUN6QixXQUFXO0VBQ1gsc0JBQXNCO0VBQ3RCLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxvQkFBb0IsRUFBQTs7QUFHeEI7RUFFUSw4QkFBOEIsRUFBQTs7QUFJdEM7RUFDSSxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZiw2QkFBNkI7RUFDN0IsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix5QkFBeUI7RUFDekIsWUFBWTtFQUNaLFdBQVc7RUFDWCxlQUFlO0VBQ2YsTUFBTTtFQUNOLGVBQWU7RUFDZixPQUFPLEVBQUE7O0FBR1g7RUFDSSxrQkFBa0I7RUFDbEIsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksV0FBVztFQUNYLGVBQWU7RUFDZixXQUFXO0VBQ1gsa0JBQWtCLEVBQUE7O0FBSnRCO0lBTVEsZUFBZTtJQUNmLDBCQUEwQjtJQUMxQiw2QkFBNkIsRUFBQTs7QUFSckM7SUFXUSxrQkFBa0I7SUFDbEIsaUNBQWlDLEVBQUE7O0FBWnpDO01BY1ksWUFBWTtNQUNaLGtCQUFrQjtNQUNsQixZQUFZLEVBQUE7O0FBaEJ4QjtJQW9CUSxnQkFBZ0IsRUFBQTs7QUFwQnhCO01Bc0JZLGtCQUFrQjtNQUNsQix1QkFBdUI7TUFDdkIsWUFBWTtNQUNaLFlBQVksRUFBQTs7QUF6QnhCO0lBOEJZLGdCQUFnQixFQUFBOztBQTlCNUI7TUFnQ2dCLFVBQVU7TUFDVixnQkFBZ0I7TUFDaEIsTUFBTTtNQUNOLE9BQU8sRUFBQTs7QUFuQ3ZCO0lBdUNZLHVCQUF1QixFQUFBOztBQUluQztFQUNJLGtCQUFrQixFQUFBOztBQUd0QjtFQUNJLGVBQWU7RUFDZixZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZiw2QkFBNkI7RUFDN0IsZUFBZTtFQUNmLFNBQVM7RUFDVCxXQUFXLEVBQUE7O0FBUmY7SUFVUSxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLDJCQUEyQixFQUFBOztBQWZuQztNQWlCWSxtQkFBYztNQUNkLGtCQUFrQixFQUFBOztBQUs5QjtFQUNJLFdBQVc7RUFDWCxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQW1CO0VBQ25CLFdBQVcsRUFBQTs7QUFHZjtFQUNJLGtCQUFrQjtFQUVsQiw0QkFBdUI7T0FBdkIsdUJBQXVCLEVBQUE7O0FBRTNCO0VBQ0ksV0FBVztFQUNYLHVCQUF1QixFQUFBOztBQUUzQjtFQUNJLHVCQUF1QjtFQUN2QixVQUFVLEVBQUE7O0FBRWQ7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxZQUFZO0VBQ1osZUFBZTtFQUNmLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3RyaWItc2VlLW9yZGVyLWRldGFpbC9kaXN0cmliLXNlZS1vcmRlci1kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2xlYXJmaXg6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6ICcnO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGNsZWFyOiBib3RoO1xufVxuXG4uYm94IHtcbiAgICBwYWRkaW5nOiA1NXB4IDEwcHggMCAxMHB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ucGItODAge1xuICAgIHBhZGRpbmctYm90dG9tOiA4MHB4O1xufVxuXG4uYm94Lmhhcy1tYiB7XG4gICAgPiBkaXYge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA4MHB4ICFpbXBvcnRhbnQ7XG4gICAgfVxufVxuXG4uZi1yIHtcbiAgICBmbG9hdDogcmlnaHQ7XG59XG5cbi5jbG9zZS1ib3gge1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgei1pbmRleDogMjAwMDAyO1xuICAgIGJveC1zaGFkb3c6IDJweCAycHggMTBweCAjNTU1O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIGhlaWdodDogNTVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICBsZWZ0OiAwO1xufVxuXG4ubm8tZGF0YSB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG59XG5cbi50YWJsZSB7XG4gICAgd2lkdGg6IGF1dG87XG4gICAgbWluLXdpZHRoOiAxMDAlO1xuICAgIGNvbG9yOiAjNjY2O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB0aGVhZCB7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMDtcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICM2NjY7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjNjY2O1xuICAgIH1cbiAgICB0ZCB7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZSAhaW1wb3J0YW50O1xuICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICB3aWR0aDogMTAwcHg7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdGQucmVtYXJrIHtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgaW9uLXRleHRhcmVhIHtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IGRvdWJsZSAjY2NjO1xuICAgICAgICAgICAgd2lkdGg6IDEyMHB4O1xuICAgICAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIC51cGxvYWRmaWxlIHtcbiAgICAgICAgLnBvcy1yIHtcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgICBpbnB1dFt0eXBlPSdmaWxlJ10ge1xuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMDBweDtcbiAgICAgICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAuaW1nLXJlc3BvbnNpdmUge1xuICAgICAgICAgICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cbiAgICB9XG59XG4udGV4dC1jIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5ib3QtYm94IHtcbiAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgei1pbmRleDogMjAwMDAyO1xuICAgIGJveC1zaGFkb3c6IDJweCAycHggMTBweCAjNTU1O1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBib3R0b206IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgLmNob2ljZS1kYXRlIHtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgICAgY29sb3I6ICM1NTU7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgICAgICBpb24tZGF0ZXRpbWUge1xuICAgICAgICAgICAgLS1wYWRkaW5nLWVuZDogMjBweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnRodW1ibmFpbCB7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgaGVpZ2h0OiA1MHB4O1xufVxuXG5oNiB7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICBjb2xvcjogIzU1NTtcbn1cblxuLnNlbGVjdC10ZXh0LWMge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgIHRleHQtYWxpZ24tbGFzdDogY2VudGVyO1xufVxuLndkLTUwIHtcbiAgICB3aWR0aDogNTBweDtcbiAgICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcbn1cbi53ZC01IHtcbiAgICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcbiAgICB3aWR0aDogNXB4O1xufVxuLmhnLTAge1xuICAgIGhlaWdodDogMHB4O1xufVxuXG4ud2QtaGUtMTUwIHtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgZGlzcGxheTogaW5saW5lO1xuICAgIGhlaWdodDogNTBweDtcbn1cbiJdfQ== */");

/***/ }),

/***/ "./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.ts ***!
  \**************************************************************************************/
/*! exports provided: DistribSeeOrderDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DistribSeeOrderDetailComponent", function() { return DistribSeeOrderDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_global_redo_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/global-redo.service */ "./src/app/services/global-redo.service.ts");
/* harmony import */ var _services_inspection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");






var DistribSeeOrderDetailComponent = /** @class */ (function () {
    function DistribSeeOrderDetailComponent(effectCtrl, baseData, inspectService, globalRedo) {
        var _this = this;
        this.effectCtrl = effectCtrl;
        this.baseData = baseData;
        this.inspectService = inspectService;
        this.globalRedo = globalRedo;
        this.group = [];
        this.swiperConfig = {};
        this.globalRedo.refresh.subscribe(function (res) {
            // res && console.log(location.href.indexOf(res.path));
            if (!res)
                return;
            if (location.href.indexOf(res.path) != -1 || location.href.indexOf(res.parent) != -1) {
                _this.ngOnInit();
            }
        });
    }
    DistribSeeOrderDetailComponent.prototype.ngOnInit = function () {
        this.baseData.printDebug && console.log(this.group);
    };
    DistribSeeOrderDetailComponent.prototype.cancel = function () {
        this.effectCtrl.modalCtrl.dismiss();
    };
    DistribSeeOrderDetailComponent.prototype.ionViewWillEnter = function () {
        this.swiperConfig = this.baseData.utilFn.getSwiperPublicConfig();
    };
    DistribSeeOrderDetailComponent.prototype.revokeTask = function (p, type) {
        var _this = this;
        this.effectCtrl.showAlert({
            header: '提示',
            message: '确定要撤销此合同吗？',
            buttons: [
                {
                    text: '取消',
                    role: 'cancel',
                },
                {
                    text: '确定',
                    handler: function () {
                        _this.inspectService.cancelInspectionGroup(p.contract_id, type).subscribe(function (data) {
                            _this.effectCtrl.showAlert({
                                header: '提示',
                                message: data.message,
                            });
                            if (data.status == 1) {
                                _this.group.forEach(function (element, index) {
                                    if (element.id == p.id) {
                                        _this.group.splice(index, 1);
                                    }
                                });
                            }
                        });
                    },
                },
            ],
        });
    };
    DistribSeeOrderDetailComponent.ctorParameters = function () { return [
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__["PageEffectService"] },
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"] },
        { type: _services_inspection_service__WEBPACK_IMPORTED_MODULE_2__["InspectionService"] },
        { type: _services_global_redo_service__WEBPACK_IMPORTED_MODULE_1__["GlobalRedoService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DistribSeeOrderDetailComponent.prototype, "group", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], DistribSeeOrderDetailComponent.prototype, "type", void 0);
    DistribSeeOrderDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: 'app-distrib-see-order-detail',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./distrib-see-order-detail.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./distrib-see-order-detail.component.scss */ "./src/app/pages/distrib-see-order-detail/distrib-see-order-detail.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__["PageEffectService"],
            _services_base_data_service__WEBPACK_IMPORTED_MODULE_3__["BaseDataService"],
            _services_inspection_service__WEBPACK_IMPORTED_MODULE_2__["InspectionService"],
            _services_global_redo_service__WEBPACK_IMPORTED_MODULE_1__["GlobalRedoService"]])
    ], DistribSeeOrderDetailComponent);
    return DistribSeeOrderDetailComponent;
}());



/***/ }),

/***/ "./src/app/pages/permission/permission.component.scss":
/*!************************************************************!*\
  !*** ./src/app/pages/permission/permission.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("nz-table {\n  max-height: calc(100% - 70px);\n  overflow-y: scroll; }\n  nz-table td {\n    text-align: left !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL3BhZ2VzL3Blcm1pc3Npb24vcGVybWlzc2lvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDZCQUE2QjtFQUM3QixrQkFBa0IsRUFBQTtFQUZ0QjtJQUlRLDJCQUEyQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcGVybWlzc2lvbi9wZXJtaXNzaW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsibnotdGFibGV7XG4gICAgbWF4LWhlaWdodDogY2FsYygxMDAlIC0gNzBweCk7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIHRke1xuICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0ICFpbXBvcnRhbnQ7XG4gICAgfVxufSBcblxuIl19 */");

/***/ }),

/***/ "./src/app/pages/permission/permission.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/permission/permission.component.ts ***!
  \**********************************************************/
/*! exports provided: PermissionType, PermissionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionType", function() { return PermissionType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionComponent", function() { return PermissionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_permission_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/permission.service */ "./src/app/services/permission.service.ts");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var src_app_services_global_redo_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/global-redo.service */ "./src/app/services/global-redo.service.ts");







var PermissionType;
(function (PermissionType) {
    PermissionType["menu"] = "\u83DC\u5355";
    PermissionType["btn"] = "\u6309\u94AE";
    PermissionType["field"] = "\u5217\u8868\u5B57\u6BB5";
    PermissionType["inspect-report"] = "\u9A8C\u8D27\u62A5\u544A";
})(PermissionType || (PermissionType = {}));
var PermissionComponent = /** @class */ (function () {
    function PermissionComponent(permissionCtrl, baseData, route, activeRoute, msg, globalRedo) {
        var _this = this;
        this.permissionCtrl = permissionCtrl;
        this.baseData = baseData;
        this.route = route;
        this.activeRoute = activeRoute;
        this.msg = msg;
        this.globalRedo = globalRedo;
        this.permission = [];
        this.editIsVisible = false;
        this.currentPermission = { key: null, name: '', type: null };
        this.permissionTypeMap = PermissionType;
        this.mapOfExpandedData = {};
        this.globalRedo.refresh.subscribe(function (res) {
            if (!res)
                return;
            if (res.uid == 2019) {
                _this.ngOnInit();
            }
        });
    }
    PermissionComponent.prototype.ngOnInit = function () {
        this.getPermissionList();
    };
    PermissionComponent.prototype.getPermissionList = function () {
        var _this = this;
        this.permissionCtrl.getAllPermission().subscribe(function (res) {
            res.data.forEach(function (item) {
                item.expand = true;
                _this.mapOfExpandedData[item.key] = _this.convertTreeToList(item);
            });
            _this.permission = res.data;
        });
    };
    PermissionComponent.prototype.treeClick = function (e) {
        console.log(e);
    };
    PermissionComponent.prototype.editPermission = function (p) {
        this.editIsVisible = !this.editIsVisible;
        this.currentPermission = p ? p : { key: null, type: null, name: '' };
    };
    PermissionComponent.prototype.delPermission = function (p) {
        var _this = this;
        this.permissionCtrl.removePermission(p.key)
            .subscribe(function (res) {
            _this.msg[res.status ? 'success' : 'error'](res.message);
            if (res.status)
                _this.getPermissionList();
        });
    };
    PermissionComponent.prototype.treeHandleOk = function () {
        var _this = this;
        console.log(this.currentPermission);
        //如果key有值则是修改权限，反之
        this.permissionCtrl[this.currentPermission.key ? 'updatePermission' : 'addPermission'](this.currentPermission).subscribe(function (res) {
            console.log(res);
            _this.msg[res.status ? 'success' : 'error'](res.message);
            if (res.status) {
                _this.getPermissionList();
                _this.editIsVisible = !_this.editIsVisible;
            }
        });
    };
    PermissionComponent.prototype.onChange = function ($event) {
        console.log($event);
    };
    PermissionComponent.prototype.collapse = function (array, data, $event) {
        var _this = this;
        if (!$event) {
            if (data.children) {
                data.children.forEach(function (d) {
                    var target = array.find(function (a) { return a.key === d.key; });
                    target.expand = false;
                    _this.collapse(array, target, false);
                });
            }
            else {
                return;
            }
        }
    };
    PermissionComponent.prototype.visitNode = function (node, hashMap, array) {
        if (!hashMap[node.key]) {
            hashMap[node.key] = true;
            array.push(node);
        }
    };
    PermissionComponent.prototype.convertTreeToList = function (root) {
        var stack = [];
        var array = [];
        var hashMap = {};
        stack.push(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, root, { level: 0, expand: false }));
        while (stack.length !== 0) {
            var node = stack.pop();
            this.visitNode(node, hashMap, array);
            if (node.children) {
                for (var i = node.children.length - 1; i >= 0; i--) {
                    stack.push(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, node.children[i], { level: node.level + 1, expand: false, parent: node }));
                }
            }
        }
        return array;
    };
    PermissionComponent.ctorParameters = function () { return [
        { type: src_app_services_permission_service__WEBPACK_IMPORTED_MODULE_2__["PermissionService"] },
        { type: src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_5__["BaseDataService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"] },
        { type: src_app_services_global_redo_service__WEBPACK_IMPORTED_MODULE_6__["GlobalRedoService"] }
    ]; };
    PermissionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-permission',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./permission.component.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/permission/permission.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./permission.component.scss */ "./src/app/pages/permission/permission.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_permission_service__WEBPACK_IMPORTED_MODULE_2__["PermissionService"],
            src_app_services_base_data_service__WEBPACK_IMPORTED_MODULE_5__["BaseDataService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"],
            src_app_services_global_redo_service__WEBPACK_IMPORTED_MODULE_6__["GlobalRedoService"]])
    ], PermissionComponent);
    return PermissionComponent;
}());



/***/ }),

/***/ "./src/app/pipe/compare-text.pipe.ts":
/*!*******************************************!*\
  !*** ./src/app/pipe/compare-text.pipe.ts ***!
  \*******************************************/
/*! exports provided: CompareTextPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompareTextPipe", function() { return CompareTextPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var CompareTextPipe = /** @class */ (function () {
    function CompareTextPipe() {
    }
    CompareTextPipe.prototype.transform = function (value) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        if (typeof value === 'string') {
            return value;
        }
        else {
            return JSON.parse(value);
        }
    };
    CompareTextPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'compareText',
        })
    ], CompareTextPipe);
    return CompareTextPipe;
}());



/***/ }),

/***/ "./src/app/pipe/filter-text.pipe.ts":
/*!******************************************!*\
  !*** ./src/app/pipe/filter-text.pipe.ts ***!
  \******************************************/
/*! exports provided: FilterTextPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterTextPipe", function() { return FilterTextPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var FilterTextPipe = /** @class */ (function () {
    function FilterTextPipe() {
    }
    FilterTextPipe.prototype.transform = function (value, args) {
        if (!value || value == undefined)
            value = '';
        return value;
    };
    FilterTextPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'filterText',
        })
    ], FilterTextPipe);
    return FilterTextPipe;
}());



/***/ }),

/***/ "./src/app/services/base-data.service.js":
/*!***********************************************!*\
  !*** ./src/app/services/base-data.service.js ***!
  \***********************************************/
/*! exports provided: BaseDataService, userInfo, publicParams, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseDataService", function() { return BaseDataService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userInfo", function() { return userInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "publicParams", function() { return publicParams; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");
/* harmony import */ var _share_menu_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../share/menu.json */ "./src/app/share/menu.json.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");







var BaseDataService = /** @class */ (function () {
    function BaseDataService(http) {
        this.http = http;
        this.userInfo = new userInfo(null, '', '', ''); //用户信息
        this.permissionList = [];
        this.utilFn = {
            //公共方法
            toQueryString: function (obj) {
                var result = [];
                for (var key in obj) {
                    key = encodeURIComponent(key);
                    var values = obj[key];
                    if (values && values.constructor == Array) {
                        var queryValues = [];
                        for (var i = 0, len = values.length, value = void 0; i < len; i++) {
                            value = values[i];
                            queryValues.push(this.toQueryPair(key, value));
                        }
                        result = result.concat(queryValues);
                    }
                    else {
                        result.push(this.toQueryPair(key, values));
                    }
                }
                return result.join('&');
            },
            toQueryPair: function (key, value) {
                //参数序列化
                if (typeof value == 'undefined') {
                    return key;
                }
                return key + '=' + encodeURIComponent(value === null ? '' : String(value));
            },
            formatData: function (params) {
                var arr = [];
                Object.keys(params).forEach(function (el) {
                    arr.push(el + "=" + params[el]);
                });
                return arr.join('&');
            },
            Format: function (fmt) {
                var o = {
                    'M+': new Date().getMonth() + 1,
                    'd+': new Date().getDate(),
                    'H+': new Date().getHours(),
                    'm+': new Date().getMinutes(),
                    's+': new Date().getSeconds(),
                    'q+': Math.floor((new Date().getMonth() + 3) / 3),
                    S: new Date().getMilliseconds(),
                };
                if (/(y+)/.test(fmt))
                    fmt = fmt.replace(RegExp.$1, (new Date().getFullYear() + '').substr(4 - RegExp.$1.length));
                for (var k in o)
                    if (new RegExp('(' + k + ')').test(fmt))
                        fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
                return fmt;
            },
            getPlatform: function () {
                if (navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i)) {
                    /*window.location.href="你的手机版地址";*/
                    return 'mobile';
                }
                else {
                    /*window.location.href="你的电脑版地址";    */
                    return 'pc';
                }
            },
            goBack: function () {
                history.go(-1);
            },
            getSwiperPublicConfig: function () {
                return {
                    direction: 'horizontal',
                    slidesPerView: 'auto',
                    freeMode: true,
                    init: true,
                    scrollbar: {
                        el: '.swiper-scrollbar',
                    },
                    mousewheel: false,
                };
            },
        };
        this.appPages = _share_menu_json__WEBPACK_IMPORTED_MODULE_5__["menu"];
        this.pageSize = 10;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl;
        this.usFileUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].usFileUrl;
        this.fileUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].fileUrlPath;
        this.notShowMenuPageArr = ['login', 'task-detail', 'add-permission']; //不显示菜单的页面。
        this.printDebug = !src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].production;
        this.upLoadMaxImgLength = _config__WEBPACK_IMPORTED_MODULE_2__["config"].upLoadMaxImgLength; //图片上传限量
        this.renewInitRequestTime = _config__WEBPACK_IMPORTED_MODULE_2__["config"].renewInitRequestTime;
        this.maxRenewInitRequest = _config__WEBPACK_IMPORTED_MODULE_2__["config"].maxRenewInitRequest;
        this.loadding = false;
        this.valueUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"](); //为了发射loadding
        this.menuChanged = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.autoExpandMenu = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"](); //自动展开菜单项
    }
    BaseDataService.prototype.get = function (params, showLoading) {
        //登陆后的get请求
        !showLoading && this.setLoadding(true);
        return this.http.get(this.apiUrl + params.url, {
            headers: {
                Authorization: this.userInfo.api_token ? "Bearer " + this.userInfo.api_token : undefined,
            },
            params: params.params,
        });
    };
    BaseDataService.prototype.delete = function (params, showLoadding) {
        !showLoadding && this.setLoadding(true);
        return this.http.delete(this.apiUrl + params.url + '/' + params.params, {
            headers: {
                Authorization: this.userInfo.api_token ? "Bearer " + this.userInfo.api_token : undefined,
            },
        });
    };
    BaseDataService.prototype.post = function (params, showLoadding) {
        !showLoadding && this.setLoadding(true);
        var obj = {
            'Content-Type': 'application/json;charset=UTF-8',
            Authorization: this.userInfo.api_token ? "Bearer " + this.userInfo.api_token : undefined,
        };
        !this.userInfo.api_token && delete obj.Authorization;
        return this.http.post(this.apiUrl + params.url, JSON.stringify(params.params), {
            //json
            headers: obj,
        });
    };
    Object.defineProperty(BaseDataService.prototype, "localOrigin", {
        get: function () {
            return location.origin;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BaseDataService.prototype, "isPc", {
        get: function () {
            return window.innerWidth >= 1300 ? true : false;
        },
        enumerable: true,
        configurable: true
    });
    BaseDataService.prototype.setLoadding = function (val) {
        this.loadding = val;
        this.valueUpdated.next(this.loadding);
    };
    BaseDataService.prototype.getLoadding = function () {
        return this.loadding;
    };
    BaseDataService.prototype.setMenuChange = function (val) {
        this.menuChanged.next(val);
    };
    BaseDataService.prototype.setMenuExpand = function (menuItem) {
        this.autoExpandMenu.next(menuItem);
    };
    BaseDataService.prototype.isSystemManger = function () {
        var some = false, mangerCompany = ['XD118', 'XD006', 'XD111', 'XD147'];
        if (mangerCompany.indexOf(this.userInfo.company_no) != -1) {
            some = true;
        }
        return some;
    };
    BaseDataService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    BaseDataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], BaseDataService);
    return BaseDataService;
}());

var userInfo = /** @class */ (function () {
    function userInfo(id, name, email, api_token, level, company_no, department) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.api_token = api_token;
        this.level = level;
        this.company_no = company_no;
        this.department = department;
    }
    return userInfo;
}());

var publicParams = /** @class */ (function () {
    function publicParams(url, params) {
        this.url = url;
        this.params = params;
    }
    return publicParams;
}());

/* harmony default export */ __webpack_exports__["default"] = ([]);
//# sourceMappingURL=base-data.service.js.map

/***/ }),

/***/ "./src/app/services/base-data.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/base-data.service.ts ***!
  \***********************************************/
/*! exports provided: BaseDataService, userInfo, publicParams, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseDataService", function() { return BaseDataService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userInfo", function() { return userInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "publicParams", function() { return publicParams; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");
/* harmony import */ var _share_menu_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../share/menu.json */ "./src/app/share/menu.json.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");







var BaseDataService = /** @class */ (function () {
    function BaseDataService(http) {
        this.http = http;
        this.userInfo = new userInfo(null, '', '', ''); //用户信息
        this.permissionList = [];
        this.utilFn = {
            //公共方法
            toQueryString: function (obj) {
                var result = [];
                for (var key in obj) {
                    key = encodeURIComponent(key);
                    var values = obj[key];
                    if (values && values.constructor == Array) {
                        var queryValues = [];
                        for (var i = 0, len = values.length, value = void 0; i < len; i++) {
                            value = values[i];
                            queryValues.push(this.toQueryPair(key, value));
                        }
                        result = result.concat(queryValues);
                    }
                    else {
                        result.push(this.toQueryPair(key, values));
                    }
                }
                return result.join('&');
            },
            toQueryPair: function (key, value) {
                //参数序列化
                if (typeof value == 'undefined') {
                    return key;
                }
                return key + '=' + encodeURIComponent(value === null ? '' : String(value));
            },
            formatData: function (params) {
                var arr = [];
                Object.keys(params).forEach(function (el) {
                    arr.push(el + "=" + params[el]);
                });
                return arr.join('&');
            },
            Format: function (fmt) {
                var o = {
                    'M+': new Date().getMonth() + 1,
                    'd+': new Date().getDate(),
                    'H+': new Date().getHours(),
                    'm+': new Date().getMinutes(),
                    's+': new Date().getSeconds(),
                    'q+': Math.floor((new Date().getMonth() + 3) / 3),
                    S: new Date().getMilliseconds(),
                };
                if (/(y+)/.test(fmt))
                    fmt = fmt.replace(RegExp.$1, (new Date().getFullYear() + '').substr(4 - RegExp.$1.length));
                for (var k in o)
                    if (new RegExp('(' + k + ')').test(fmt))
                        fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
                return fmt;
            },
            getPlatform: function () {
                if (navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i)) {
                    /*window.location.href="你的手机版地址";*/
                    return 'mobile';
                }
                else {
                    /*window.location.href="你的电脑版地址";    */
                    return 'pc';
                }
            },
            goBack: function () {
                history.go(-1);
            },
            getSwiperPublicConfig: function () {
                return {
                    direction: 'horizontal',
                    slidesPerView: 'auto',
                    freeMode: true,
                    init: true,
                    scrollbar: {
                        el: '.swiper-scrollbar',
                    },
                    mousewheel: false,
                };
            },
        };
        this.appPages = _share_menu_json__WEBPACK_IMPORTED_MODULE_5__["menu"];
        this.pageSize = 10;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl;
        this.usFileUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].usFileUrl;
        this.fileUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].fileUrlPath;
        this.notShowMenuPageArr = ['login', 'task-detail', 'add-permission']; //不显示菜单的页面。
        this.printDebug = !src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].production;
        this.upLoadMaxImgLength = _config__WEBPACK_IMPORTED_MODULE_2__["config"].upLoadMaxImgLength; //图片上传限量
        this.renewInitRequestTime = _config__WEBPACK_IMPORTED_MODULE_2__["config"].renewInitRequestTime;
        this.maxRenewInitRequest = _config__WEBPACK_IMPORTED_MODULE_2__["config"].maxRenewInitRequest;
        this.loadding = false;
        this.valueUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"](); //为了发射loadding
        this.menuChanged = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.autoExpandMenu = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"](); //自动展开菜单项
    }
    BaseDataService.prototype.get = function (params, showLoading) {
        //登陆后的get请求
        !showLoading && this.setLoadding(true);
        return this.http.get(this.apiUrl + params.url, {
            headers: {
                Authorization: this.userInfo.api_token ? "Bearer " + this.userInfo.api_token : undefined,
            },
            params: params.params,
        });
    };
    BaseDataService.prototype.delete = function (params, showLoadding) {
        !showLoadding && this.setLoadding(true);
        return this.http.delete(this.apiUrl + params.url + '/' + params.params, {
            headers: {
                Authorization: this.userInfo.api_token ? "Bearer " + this.userInfo.api_token : undefined,
            },
        });
    };
    BaseDataService.prototype.post = function (params, showLoadding) {
        !showLoadding && this.setLoadding(true);
        var obj = {
            'Content-Type': 'application/json;charset=UTF-8',
            Authorization: this.userInfo.api_token ? "Bearer " + this.userInfo.api_token : undefined,
        };
        !this.userInfo.api_token && delete obj.Authorization;
        return this.http.post(this.apiUrl + params.url, JSON.stringify(params.params), {
            //json
            headers: obj,
        });
    };
    Object.defineProperty(BaseDataService.prototype, "localOrigin", {
        get: function () {
            return location.origin;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BaseDataService.prototype, "isPc", {
        get: function () {
            return window.innerWidth >= 1300 ? true : false;
        },
        enumerable: true,
        configurable: true
    });
    BaseDataService.prototype.setLoadding = function (val) {
        this.loadding = val;
        this.valueUpdated.next(this.loadding);
    };
    BaseDataService.prototype.getLoadding = function () {
        return this.loadding;
    };
    BaseDataService.prototype.setMenuChange = function (val) {
        this.menuChanged.next(val);
    };
    BaseDataService.prototype.setMenuExpand = function (menuItem) {
        this.autoExpandMenu.next(menuItem);
    };
    BaseDataService.prototype.isSystemManger = function () {
        var some = false, mangerCompany = ['XD118', 'XD006', 'XD111', 'XD147'];
        if (mangerCompany.indexOf(this.userInfo.company_no) != -1) {
            some = true;
        }
        return some;
    };
    BaseDataService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    BaseDataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], BaseDataService);
    return BaseDataService;
}());

var userInfo = /** @class */ (function () {
    function userInfo(id, name, email, api_token, level, company_no, department) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.api_token = api_token;
        this.level = level;
        this.company_no = company_no;
        this.department = department;
    }
    return userInfo;
}());

var publicParams = /** @class */ (function () {
    function publicParams(url, params) {
        this.url = url;
        this.params = params;
    }
    return publicParams;
}());

/* harmony default export */ __webpack_exports__["default"] = ([]);


/***/ }),

/***/ "./src/app/services/commit.service.js":
/*!********************************************!*\
  !*** ./src/app/services/commit.service.js ***!
  \********************************************/
/*! exports provided: CommitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommitService", function() { return CommitService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _base_data_service_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-data.service.js */ "./src/app/services/base-data.service.js");
/* harmony import */ var src_environments_environment_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment.js */ "./src/environments/environment.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/operators/index.js");


// import * as wangEditor from '../../../node_modules/wangeditor/dist/wangEditor.js';




var CommitService = /** @class */ (function () {
    function CommitService(baseData) {
        this.baseData = baseData;
        this.imgOrigin = src_environments_environment_js__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl;
        this.currentKey$ = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.editor = null;
        this._id = 0;
        this._destroy = false;
        // 富文本编辑器内容变化触发方法
        this.editorContentChange = function (html) {
            // console.log(html);
        };
        // 编辑器获取到焦点触发事件
        this.editorOnFocus = function () {
            // console.log('on focus');
        };
        // 编辑器失去焦点触发事件
        this.editorOnBlur = function (html) {
            // console.log('on blur');
            // console.log(html);
        };
    }
    CommitService.prototype.ngAfterViewInit = function () {
    };
    CommitService.prototype.ngOnDestroy = function () {
        this._destroy = true;
    };
    CommitService.prototype._init = function () {
        var _this = this;
        if (this.editor)
            this.editor = null;
        this.editor = new wangEditor('#editorMenu', '#editor');
        this.setEditorConfig();
        Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["timer"])(50)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["takeWhile"])(function () { return !_this._destroy && _this.editor; }))
            .subscribe(function () {
            _this.editor.create();
        });
        // setTimeout(() => {
        //     this.destroy();
        // },10000)
    };
    CommitService.prototype.destroy = function () {
        this.editor.destroy();
    };
    Object.defineProperty(CommitService.prototype, "applyInspectNo", {
        get: function () {
            return this.apply_inspect_no;
        },
        set: function (input) {
            if (!!input)
                this.apply_inspect_no = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "contract", {
        get: function () {
            return this._contract;
        },
        set: function (input) {
            if (!!input)
                this._contract = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (input) {
            this._id = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "Sku", {
        get: function () {
            return this.sku;
        },
        set: function (input) {
            if (!!input)
                this.sku = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "Index", {
        get: function () {
            return this.index;
        },
        set: function (input) {
            if (input !== undefined && input !== null)
                this.index = input;
        },
        enumerable: true,
        configurable: true
    });
    // 编辑器相关配置设置
    CommitService.prototype.setEditorConfig = function () {
        // 使用 base64 保存图片
        this.editor.config.uploadImgShowBase64 = true;
        // 菜单展示项配置
        // this.editor.customConfig.menus = this.getMenuConfig();
        // 自定义配置颜色（字体颜色、背景色）
        this.editor.config.colors = this.getColorConfig();
        // 表情面板可以有多个 tab ，因此要配置成一个数组。数组每个元素代表一个 tab 的配置
        // this.editor.customConfig.emotions = this.getEmotionsConfig();
        // 自定义字体
        // this.editor.customConfig.fontNames = this.getFontFamilyConfig();
        // 编辑区域的z-index默认为10000
        // this.editor.customConfig.zIndex = 100;
        // 配置编辑器内容改变触发方法
        this.editor.config.onchange = this.editorContentChange;
        // 编辑器获取到焦点触发方法
        this.editor.config.onfocus = this.editorOnFocus;
        // 编辑器失去焦点触发方法
        this.editor.config.onblur = this.editorOnBlur;
        this.editor.config.uploadImgHeaders = {
            Authorization: "Bearer " + this.baseData.userInfo.api_token,
        };
        this.editor.config.uploadImgServer = this.imgOrigin + "/task/add_inspection_task_review_summary_pic_video";
        this.editor.config.uploadFileName = 'img';
        this.editor.config.uploadImgParams = {
            apply_inspection_no: this.applyInspectNo,
            sku: this.Sku,
        };
        this.editor.config.fontNames = [
            '黑体',
            '仿宋',
            '楷体',
            '标楷体',
            '华文仿宋',
            '华文楷体',
            '宋体',
            '微软雅黑',
            'Arial',
            'Tahoma',
            'Verdana',
            'Times New Roman',
            'Courier New',
        ];
        this.editor.config.fontSizes = {
            'x-small': { name: '10px', value: '1' },
            small: { name: '13px', value: '2' },
            normal: { name: '16px', value: '3' },
            large: { name: '18px', value: '4' },
            'x-large': { name: '24px', value: '5' },
            'xx-large': { name: '32px', value: '6' },
            'xxx-large': { name: '48px', value: '7' },
        };
    };
    // 设置可选颜色
    CommitService.prototype.getColorConfig = function () {
        return [
            '#ffffff',
            '#000000',
            '#eeece0',
            '#1c487f',
            '#4d80bf',
            '#c24f4a',
            '#8baa4a',
            '#7b5ba1',
            '#46acc8',
            '#f9963b',
            '#0076B8',
            '#E2C08D',
            '#8EE153',
            '#B6001F',
        ];
    };
    CommitService.ctorParameters = function () { return [
        { type: _base_data_service_js__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] }
    ]; };
    CommitService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_base_data_service_js__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"]])
    ], CommitService);
    return CommitService;
}());

//# sourceMappingURL=commit.service.js.map

/***/ }),

/***/ "./src/app/services/commit.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/commit.service.ts ***!
  \********************************************/
/*! exports provided: CommitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommitService", function() { return CommitService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _base_data_service_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-data.service.js */ "./src/app/services/base-data.service.js");
/* harmony import */ var src_environments_environment_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment.js */ "./src/environments/environment.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/operators/index.js");


// import * as wangEditor from '../../../node_modules/wangeditor/dist/wangEditor.js';




var CommitService = /** @class */ (function () {
    function CommitService(baseData) {
        this.baseData = baseData;
        this.imgOrigin = src_environments_environment_js__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl;
        this.currentKey$ = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.editor = null;
        this._id = 0;
        this._destroy = false;
        // 富文本编辑器内容变化触发方法
        this.editorContentChange = function (html) {
            // console.log(html);
        };
        // 编辑器获取到焦点触发事件
        this.editorOnFocus = function () {
            // console.log('on focus');
        };
        // 编辑器失去焦点触发事件
        this.editorOnBlur = function (html) {
            // console.log('on blur');
            // console.log(html);
        };
    }
    CommitService.prototype.ngAfterViewInit = function () {
    };
    CommitService.prototype.ngOnDestroy = function () {
        this._destroy = true;
    };
    CommitService.prototype._init = function () {
        var _this = this;
        if (this.editor)
            this.editor = null;
        this.editor = new wangEditor('#editorMenu', '#editor');
        this.setEditorConfig();
        Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["timer"])(50)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["takeWhile"])(function () { return !_this._destroy && _this.editor; }))
            .subscribe(function () {
            _this.editor.create();
        });
        // setTimeout(() => {
        //     this.destroy();
        // },10000)
    };
    CommitService.prototype.destroy = function () {
        this.editor.destroy();
    };
    Object.defineProperty(CommitService.prototype, "applyInspectNo", {
        get: function () {
            return this.apply_inspect_no;
        },
        set: function (input) {
            if (!!input)
                this.apply_inspect_no = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "contract", {
        get: function () {
            return this._contract;
        },
        set: function (input) {
            if (!!input)
                this._contract = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (input) {
            this._id = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "Sku", {
        get: function () {
            return this.sku;
        },
        set: function (input) {
            if (!!input)
                this.sku = input;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CommitService.prototype, "Index", {
        get: function () {
            return this.index;
        },
        set: function (input) {
            if (input !== undefined && input !== null)
                this.index = input;
        },
        enumerable: true,
        configurable: true
    });
    // 编辑器相关配置设置
    CommitService.prototype.setEditorConfig = function () {
        // 使用 base64 保存图片
        this.editor.config.uploadImgShowBase64 = true;
        // 菜单展示项配置
        // this.editor.customConfig.menus = this.getMenuConfig();
        // 自定义配置颜色（字体颜色、背景色）
        this.editor.config.colors = this.getColorConfig();
        // 表情面板可以有多个 tab ，因此要配置成一个数组。数组每个元素代表一个 tab 的配置
        // this.editor.customConfig.emotions = this.getEmotionsConfig();
        // 自定义字体
        // this.editor.customConfig.fontNames = this.getFontFamilyConfig();
        // 编辑区域的z-index默认为10000
        // this.editor.customConfig.zIndex = 100;
        // 配置编辑器内容改变触发方法
        this.editor.config.onchange = this.editorContentChange;
        // 编辑器获取到焦点触发方法
        this.editor.config.onfocus = this.editorOnFocus;
        // 编辑器失去焦点触发方法
        this.editor.config.onblur = this.editorOnBlur;
        this.editor.config.uploadImgHeaders = {
            Authorization: "Bearer " + this.baseData.userInfo.api_token,
        };
        this.editor.config.uploadImgServer = this.imgOrigin + "/task/add_inspection_task_review_summary_pic_video";
        this.editor.config.uploadFileName = 'img';
        this.editor.config.uploadImgParams = {
            apply_inspection_no: this.applyInspectNo,
            sku: this.Sku,
        };
        this.editor.config.fontNames = [
            '黑体',
            '仿宋',
            '楷体',
            '标楷体',
            '华文仿宋',
            '华文楷体',
            '宋体',
            '微软雅黑',
            'Arial',
            'Tahoma',
            'Verdana',
            'Times New Roman',
            'Courier New',
        ];
        this.editor.config.fontSizes = {
            'x-small': { name: '10px', value: '1' },
            small: { name: '13px', value: '2' },
            normal: { name: '16px', value: '3' },
            large: { name: '18px', value: '4' },
            'x-large': { name: '24px', value: '5' },
            'xx-large': { name: '32px', value: '6' },
            'xxx-large': { name: '48px', value: '7' },
        };
    };
    // 设置可选颜色
    CommitService.prototype.getColorConfig = function () {
        return [
            '#ffffff',
            '#000000',
            '#eeece0',
            '#1c487f',
            '#4d80bf',
            '#c24f4a',
            '#8baa4a',
            '#7b5ba1',
            '#46acc8',
            '#f9963b',
            '#0076B8',
            '#E2C08D',
            '#8EE153',
            '#B6001F',
        ];
    };
    CommitService.ctorParameters = function () { return [
        { type: _base_data_service_js__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] }
    ]; };
    CommitService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_base_data_service_js__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"]])
    ], CommitService);
    return CommitService;
}());



/***/ }),

/***/ "./src/app/services/examine.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/examine.service.ts ***!
  \*********************************************/
/*! exports provided: ExamineService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExamineService", function() { return ExamineService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/operators/index.js");




var ExamineService = /** @class */ (function () {
    function ExamineService(baseData) {
        this.baseData = baseData;
    }
    //获取验货审核内容
    ExamineService.prototype.getReviewAdviseData = function (apply_inspection_no) {
        return this.baseData
            .get({
            url: '/task/get_inspection_task_review_advise_data',
            params: { apply_inspection_no: apply_inspection_no },
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) { return res.data; }));
    };
    //添加验货审核内容
    ExamineService.prototype.addReviewAdvise = function (params) {
        return this.baseData.post({ url: '/task/add_inspection_task_review_advise_data', params: params });
    };
    //修改验货审核内容
    ExamineService.prototype.modifyReviewAdvise = function (params) {
        return this.baseData.post({ url: '/task/edit_inspection_task_review_advise_data', params: params });
    };
    //删除验货审核内容
    ExamineService.prototype.deleteReviewAdvise = function (params) {
        return this.baseData.get({ url: '/task/del_inspection_task_review_advise_data', params: params });
    };
    //审核 添加总结 文字
    ExamineService.prototype.addReviewSummaryText = function (params) {
        return this.baseData.post({ url: '/task/add_inspection_task_review_summary_desc', params: params });
    };
    //审核 添加总结 图片/视频
    ExamineService.prototype.addReviewSummaryMedia = function (params) {
        return this.baseData.post({ url: '/task/add_inspection_task_review_summary_pic_video', params: params });
    };
    //删除 总结 图片/视频
    ExamineService.prototype.removeReviewSummaryMedia = function (params) {
        return this.baseData.post({ url: '/task/del_inspection_task_review_summary_pic_video', params: params });
    };
    //撤销验货申请功能 数据审核
    ExamineService.prototype.resetInspectTaskSku = function (params) {
        return this.baseData.get({ url: '/task/reset_inspection_task_sku', params: params });
    };
    ExamineService.ctorParameters = function () { return [
        { type: _base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] }
    ]; };
    ExamineService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"]])
    ], ExamineService);
    return ExamineService;
}());



/***/ }),

/***/ "./src/app/services/global-redo.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/global-redo.service.ts ***!
  \*************************************************/
/*! exports provided: GlobalRedoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalRedoService", function() { return GlobalRedoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");



var GlobalRedoService = /** @class */ (function () {
    function GlobalRedoService() {
        this.refresh = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](null);
    }
    GlobalRedoService.prototype.redo = function (tab) {
        this.refresh.next(tab);
    };
    GlobalRedoService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], GlobalRedoService);
    return GlobalRedoService;
}());



/***/ }),

/***/ "./src/app/services/inspection.service.ts":
/*!************************************************!*\
  !*** ./src/app/services/inspection.service.ts ***!
  \************************************************/
/*! exports provided: InspectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionService", function() { return InspectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _base_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");



var InspectionService = /** @class */ (function () {
    function InspectionService(baseData) {
        this.baseData = baseData;
    }
    InspectionService.prototype.submitData = function (uploadData) {
        //sku  提交
        return this.baseData.post({
            url: '/task/task-inspection-post',
            params: uploadData,
        });
    };
    InspectionService.prototype.applyInspec = function (uploadData) {
        return this.baseData.post({
            url: '/schedule/apply-inspection',
            params: uploadData,
        });
    };
    InspectionService.prototype.submitDataAcc = function (accUpload) {
        return this.baseData.post({
            url: '/task/task-inspection-acc-post',
            params: accUpload,
        });
    };
    InspectionService.prototype.getContractList = function () {
        return this.baseData.get({ url: '/contracts/get-contracts-for-api' });
    };
    InspectionService.prototype.updateStatus = function () {
        return this.baseData.get({ url: '/contracts/update-contracts-status' }, true);
    };
    InspectionService.prototype.getApplyInspecList = function (params) {
        //申请验货列表
        return this.baseData.get({
            url: '/schedule/apply-inspection-list',
            params: params,
        });
    };
    InspectionService.prototype.getdepartmentInspecList = function (params) {
        //验货列表
        return this.baseData.get({
            url: '/schedule/apply-department-list',
            params: params,
        });
    };
    InspectionService.prototype.postDepartment = function (department) {
        return this.baseData.post({
            url: '/schedule/post-inspection-department',
            params: department,
        });
    };
    InspectionService.prototype.getArrangeInspecList = function (params) {
        //安排验货列表
        return this.baseData.get({
            url: '/inspection/inspections_group_list',
            params: params,
        });
    };
    InspectionService.prototype.setInspecGroup = function (params) {
        return this.baseData.post({
            url: '/inspection/distribute_groups',
            params: params,
        });
    };
    InspectionService.prototype.getinpectionGroup = function (params) {
        var param = params ? params : {};
        return this.baseData.get({
            url: '/inspection/inspections_group',
            params: param,
        });
    };
    InspectionService.prototype.selectGroupUser = function (params) {
        return this.baseData.post({
            url: '/inspection/distribute_inspections',
            params: params,
        });
    };
    InspectionService.prototype.preDistribInspec = function (params) {
        //分配验货预处理
        return this.baseData.post({
            url: '/inspection/pre_distribute_inspections',
            params: params,
        });
    };
    InspectionService.prototype.getGroupUserList = function () {
        return this.baseData.get({
            url: '/inspection/select_group_useranddate_list',
        });
    };
    InspectionService.prototype.getDistributedList = function (params) {
        var param = params ? params : {};
        return this.baseData.get({
            url: '/inspection/select_distributed_list',
            params: param,
        });
    };
    InspectionService.prototype.cancelApplyInspec = function (id) {
        //取消验货
        return this.baseData.get({
            url: '/inspection/reset_apply_inspection',
            params: { id: id },
        });
    };
    InspectionService.prototype.cancelInspectionGroup = function (id, type) {
        //撤销验货组 （数据回验货批次）
        var params = {}, key = type == 'contract' ? 'apply_id' : 'inspection_group_id';
        params[key] = id;
        return this.baseData.get({
            url: '/inspection/reset_inspection_group',
            params: params,
        });
    };
    InspectionService.prototype.cancelDistribInspection = function (id) {
        //已分配撤销
        return this.baseData.get({
            url: '/inspection/reset_distribute_inspections',
            params: { inspection_group_id: id },
        });
    };
    InspectionService.prototype.cancelExamineInspection = function (id) {
        return this.baseData.get({
            url: '/inspection/reset_confirmed_inspection',
            params: { inspection_group_id: id },
        }); //已确认撤销
    };
    InspectionService.prototype.dragSortOfList = function (params) {
        return this.baseData.post({
            url: '/inspection/update_inspections_group_sort',
            params: params,
        });
    };
    InspectionService.prototype.confirmationOfReceipt = function (params) {
        return this.baseData.get({
            url: '/inspection/confirm_inspection',
            params: params,
        });
    };
    InspectionService.prototype.getConfirmedTask = function (params) {
        return this.baseData.get({
            url: '/inspection/confirmed_inspection_task',
            params: params,
        });
    };
    InspectionService.prototype.getCreatedBatches = function (params) {
        return this.baseData.get({
            url: '/inspection/distributed_group_list',
            params: params,
        });
    };
    InspectionService.prototype.generateInspecNo = function () {
        return this.baseData.get({
            url: '/inspection/generate_inspection_group_no',
        });
    };
    InspectionService.prototype.getInspecionTask = function () {
        return this.baseData.get({ url: '/inspection/get_inspection_task_data' });
    };
    InspectionService.prototype.inspecerSetting = function (params) {
        return this.baseData.post({
            url: '/inspection/pre_inspection_task',
            params: params,
        });
    };
    InspectionService.prototype.getInspecTaskList = function () {
        return this.baseData.get({ url: '/inspection/inspection_task_list' });
    };
    InspectionService.prototype.setApplyDate = function (params) {
        return this.baseData.post({
            url: '/schedule/edit_apply_inspection',
            params: params,
        });
    };
    InspectionService.prototype.applyInspectModifyDesc = function (params) {
        return this.baseData.post({
            url: '/schedule/add_apply_inspection_temporary_desc',
            params: params,
        });
    };
    InspectionService.prototype.skuCancelInspect = function (sku, apply_id) {
        return this.baseData.get({ url: '/inspection/reset_apply_inspection_sku', params: { sku: sku, id: apply_id } });
    };
    InspectionService.prototype.generateTaskGroup = function (params) {
        return this.baseData.post({
            url: '/inspection/generate_confirmed_inspection_task_to_group',
            params: { group_name: params.group_name, inspection_group_id_arr: params.inspection_group_id_arr },
        });
    };
    /**
     * 退出组
     */
    InspectionService.prototype.delGroupForTask = function (params) {
        return this.baseData.get({
            url: '/inspection/del_group_for_confirmed_inspection_task',
            params: { group_name: params.group_name, inspection_group_id: params.id },
        });
    };
    /**
     * 获取合并的工厂 和合同
     */
    InspectionService.prototype.getMergeTaskData = function () {
        return this.baseData.get({
            url: '/inspection/get_confirmed_factory_data',
        });
    };
    /**
     * 提交合并的sku数据
     */
    InspectionService.prototype.submitMergeData = function (params) {
        return this.baseData.post({
            url: '/inspection/merge_confirmed_data',
            params: params,
        });
    };
    /**
     * 撤销验货
     */
    InspectionService.prototype.revokeInspect = function (params) {
        return this.baseData.get({
            url: '/inspection/reset_apply_inspection_sku',
            params: params
        });
    };
    InspectionService.ctorParameters = function () { return [
        { type: _base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"] }
    ]; };
    InspectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"]])
    ], InspectionService);
    return InspectionService;
}());



/***/ }),

/***/ "./src/app/services/interceptor.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/interceptor.service.ts ***!
  \*************************************************/
/*! exports provided: DefaultInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DefaultInterceptor", function() { return DefaultInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _base_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../config */ "./src/app/config.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/operators/index.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/_ng-zorro-antd@8.3.0@ng-zorro-antd/fesm5/ng-zorro-antd.js");










var DefaultInterceptor = /** @class */ (function () {
    function DefaultInterceptor(router, baseData, effectCtrl, msg) {
        this.router = router;
        this.baseData = baseData;
        this.effectCtrl = effectCtrl;
        this.msg = msg;
        this.errArr = [401, 404, 500, 502, 301];
    }
    DefaultInterceptor.prototype.intercept = function (req, next) {
        var _this = this;
        // req = req.clone({
        //   setHeaders: {
        //     Authorization: `Bearer ${this.baseData.userInfo.api_token}`
        //   }
        // });
        // console.log('HttpInterceptor req', req);
        var obs;
        if (_config__WEBPACK_IMPORTED_MODULE_6__["config"].avoidInterception.indexOf(req.url) !== -1) {
            obs = next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["mergeMap"])(function (event) {
                // 允许统一对请求错误处理，这是因为一个请求若是业务上错误的情况下其HTTP请求的状态是200的情况下需要
                if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"] && event.status == 200)
                    return _this.handleData(event);
                // 若一切都正常，则后续操作
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(event);
            }));
        }
        else {
            obs = next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["mergeMap"])(function (event) {
                // 允许统一对请求错误处理，这是因为一个请求若是业务上错误的情况下其HTTP请求的状态是200的情况下需要
                if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"] && event.status == 200)
                    return _this.handleData(event);
                // 若一切都正常，则后续操作
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(event);
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["timeout"])(this.baseData.renewInitRequestTime), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["retryWhen"])(function (err$) {
                //重试 节奏控制器
                return err$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["scan"])(function (errCount, err) {
                    if (errCount >= _this.baseData.maxRenewInitRequest ||
                        _this.errArr.indexOf(err.status) != -1) {
                        throw err;
                    }
                    return errCount + 1;
                }, 0), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["delay"])(1000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["tap"])(function (errCount) {
                    if (errCount == 1) {
                        //第一次重试时显示友好信息
                        _this.msg.error('网络错误，正在进行第一次重新请求');
                    }
                    else if (errCount == 2) {
                        _this.effectCtrl.toastCtrl.dismiss();
                        _this.msg.error('网络错误，正在进行第二次重新请求');
                    }
                    else {
                    }
                }));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["catchError"])(function (err) { return _this.handleData(err); }));
        }
        return obs;
    };
    DefaultInterceptor.prototype.handleData = function (event) {
        var _this = this;
        // console.log('HttpInterceptor handleData', event);
        // 可能会因为 `throw` 导出无法执行 `_HttpClient` 的 `end()` 操作
        // this.injector.get(_HttpClient).end();
        // 业务处理：一些通用操作
        this.baseData.setLoadding(false);
        switch (event.status) {
            case 200:
                this.baseData.printDebug && console.log('成功发送请求');
                // 业务层级错误处理，以下是假定restful有一套统一输出格式（指不管成功与否都有相应的数据格式）情况下进行处理
                // 例如响应内容：
                //  错误内容：{ status: 1, msg: '非法参数' }
                //  正确内容：{ status: 0, response: {  } }
                // 则以下代码片断可直接适用
                // if (event instanceof HttpResponse) {
                //     const body: any = event.body;
                //     if (body && body.status !== 0) {
                //         this.msg.error(body.msg);
                //         // 继续抛出错误中断后续所有 Pipe、subscribe 操作，因此：
                //         // this.http.get('/').subscribe() 并不会触发
                //         return throwError({});
                //     } else {
                //         // 重新修改 `body` 内容为 `response` 内容，对于绝大多数场景已经无须再关心业务状态码
                //         return of(new HttpResponse(Object.assign(event, { body: body.response })));
                //         // 或者依然保持完整的格式
                //         return of(event);
                //     }
                // }
                this.clearEffectElem();
                if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"]) {
                    var body = event.body;
                    if (body && body.retCode === 1002) {
                        // this.msg.error(body.comment);
                        this.router.navigate(['/login']);
                    }
                }
                break;
            case 401: // 未登录状态码
                this.effectCtrl.alertCtrl
                    .getTop() //跨域的时候有时会发送两次请求  为了避免有两个弹框 先判断
                    .then(function (alert) {
                    if (!alert) {
                        _this.effectCtrl.showAlert({
                            header: '提示',
                            message: '登陆无效，请重新登录',
                            backdropDismiss: false,
                            buttons: [
                                {
                                    text: 'ok',
                                    handler: function () {
                                        _this.effectCtrl.alertCtrl.dismiss().then(function () {
                                            sessionStorage.removeItem('USERINFO');
                                            _this.router.navigate(['/login']);
                                        });
                                    },
                                },
                            ],
                        });
                    }
                });
                break;
            case 403:
            case 404:
                this.clearEffectElem();
                this.msg.error('请求错误，请稍后重试！');
            case 500:
                this.clearEffectElem();
                this.effectCtrl.showAlert({
                    header: '提示',
                    message: '服务器出错啦',
                    backdropDismiss: false,
                    buttons: [
                        {
                            text: 'ok',
                            handler: function () {
                                _this.effectCtrl.alertCtrl.dismiss();
                            },
                        },
                    ],
                });
                break;
            default:
                if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpErrorResponse"]) {
                    console.warn('未可知错误，大部分是由于后端不支持CORS或无效配置引起', event);
                }
                this.clearEffectElem();
                this.effectCtrl.showAlert({
                    header: '提示',
                    message: '网络错误，请稍后重试',
                    buttons: ['ok'],
                });
                break;
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_7__["of"])(event);
    };
    DefaultInterceptor.prototype.clearEffectElem = function () {
        var _this = this;
        this.effectCtrl.toastCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.toastCtrl.dismiss();
            }
        });
        this.effectCtrl.loadCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.loadCtrl.dismiss();
            }
        });
        this.effectCtrl.alertCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.alertCtrl.dismiss();
            }
        });
    };
    DefaultInterceptor.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"] },
        { type: _page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] },
        { type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__["NzMessageService"] }
    ]; };
    DefaultInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"], _page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_9__["NzMessageService"]])
    ], DefaultInterceptor);
    return DefaultInterceptor;
}());



/***/ }),

/***/ "./src/app/services/menu-permission.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/services/menu-permission.service.ts ***!
  \*****************************************************/
/*! exports provided: MenuPermissionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuPermissionService", function() { return MenuPermissionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");


var MenuPermissionService = /** @class */ (function () {
    function MenuPermissionService() {
        this.permissions = [];
    }
    MenuPermissionService.prototype.has = function (name, parentId) {
        return this.permissions.some(function (item) {
            if (parentId) {
                return name === item.name && parentId === item.parent_id;
            }
            else
                return name === item.name && !item.parent;
        });
    };
    MenuPermissionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], MenuPermissionService);
    return MenuPermissionService;
}());



/***/ }),

/***/ "./src/app/services/oa.service.ts":
/*!****************************************!*\
  !*** ./src/app/services/oa.service.ts ***!
  \****************************************/
/*! exports provided: OaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OaService", function() { return OaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");



var OaService = /** @class */ (function () {
    function OaService(http) {
        this.http = http;
    }
    OaService.prototype.getToken = function () {
        return this.http.get('https://oa.xdrlgroup.com/api/v1/get_token').toPromise();
    };
    OaService.prototype.getUserInfo = function (job_num, token) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.http
                            .get('https://oa.xdrlgroup.com/api/v1/user/info', { params: { job_num: job_num, token: token } })
                            .toPromise()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    OaService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    OaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], OaService);
    return OaService;
}());



/***/ }),

/***/ "./src/app/services/page-effect.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/page-effect.service.ts ***!
  \*************************************************/
/*! exports provided: PageEffectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageEffectService", function() { return PageEffectService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");



var PageEffectService = /** @class */ (function () {
    function PageEffectService(alertCtrl, loadCtrl, modalCtrl, toastCtrl) {
        this.alertCtrl = alertCtrl;
        this.loadCtrl = loadCtrl;
        this.modalCtrl = modalCtrl;
        this.toastCtrl = toastCtrl;
    }
    PageEffectService.prototype.showAlert = function (option) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create(option)];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.showLoad = function (option) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var load;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadCtrl.create(option)];
                    case 1:
                        load = _a.sent();
                        return [4 /*yield*/, load.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.showToast = function (option) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        option.duration = 1500;
                        option.position = 'top';
                        option.mode = 'ios';
                        return [4 /*yield*/, this.toastCtrl.create(option)];
                    case 1:
                        toast = _a.sent();
                        return [4 /*yield*/, toast.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, toast.onDidDismiss()];
                }
            });
        });
    };
    PageEffectService.prototype.showModal = function (option, callback) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal, data;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create(option)];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, modal.onDidDismiss()];
                    case 3:
                        data = (_a.sent()).data;
                        if (data && data.refresh) {
                            callback && callback(data.refresh);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.clearEffectCtrl = function () {
        var _this = this;
        this.toastCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.toastCtrl.dismiss();
            }
        });
        this.loadCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.loadCtrl.dismiss();
            }
        });
        this.alertCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.alertCtrl.dismiss();
            }
        });
    };
    PageEffectService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"] }
    ]; };
    PageEffectService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"]])
    ], PageEffectService);
    return PageEffectService;
}());



/***/ }),

/***/ "./src/app/services/permission.service.ts":
/*!************************************************!*\
  !*** ./src/app/services/permission.service.ts ***!
  \************************************************/
/*! exports provided: PermissionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionService", function() { return PermissionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _base_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");



var PermissionService = /** @class */ (function () {
    function PermissionService(baseData) {
        this.baseData = baseData;
    }
    PermissionService.prototype.getPermissionType = function () {
        return this.baseData.get({ url: '/permission/get_permission_type' });
    };
    PermissionService.prototype.getAllPermission = function () {
        return this.baseData.get({ url: '/permission/get_tree_permission_list' });
    };
    PermissionService.prototype.addPermission = function (params) {
        return this.baseData.post({ url: '/permission/add_permission', params: params });
    };
    PermissionService.prototype.removePermission = function (id) {
        return this.baseData.get({ url: '/permission/del_permission', params: { id: id } });
    };
    PermissionService.prototype.updatePermission = function (params) {
        return this.baseData.post({ url: '/permission/update_permission', params: params });
    };
    PermissionService.prototype.addPermissionGroups = function (params) {
        return this.baseData.post({ url: '/permission/add_permission_groups', params: params });
    };
    PermissionService.prototype.getPermissionGroups = function () {
        return this.baseData.get({ url: '/permission/get_permission_groups' });
    };
    /**
     * 根据roleId获取权限
     */
    PermissionService.prototype.getPermissionByRole = function (role_id) {
        return this.baseData.get({ url: '/permissionsNew/role_permission', params: { role_id: role_id } });
    };
    /**
     * 根据组id获取权限
     */
    PermissionService.prototype.getPermissionByGroupId = function (group_id) {
        return this.baseData.get({ url: '/permissionsNew/get_group_permission', params: { group_id: group_id } });
    };
    PermissionService.prototype.deletePermissionGroup = function (_a) {
        var id = _a.id;
        return this.baseData.post({ url: '/permission/del_permission_group', params: { group_id: id } });
    };
    PermissionService.prototype.updatePermissionGroup = function (params) {
        return this.baseData.post({ url: '/permission/update_permission_groups', params: params });
    };
    PermissionService.prototype.gavePermission = function (params) {
        return this.baseData.post({ url: '/permissionsNew/gave_permission', params: params });
    };
    /**
     * 给用户组分配用户
     */
    PermissionService.prototype.addUserPermissionGroup = function (params) {
        return this.baseData.post({ url: '/permissionsNew/add_user_permission_group', params: params });
    };
    PermissionService.ctorParameters = function () { return [
        { type: _base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"] }
    ]; };
    PermissionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"]])
    ], PermissionService);
    return PermissionService;
}());



/***/ }),

/***/ "./src/app/services/task.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/task.service.ts ***!
  \******************************************/
/*! exports provided: TaskService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskService", function() { return TaskService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");




var TaskService = /** @class */ (function () {
    function TaskService(http, baseData) {
        this.http = http;
        this.baseData = baseData;
    }
    TaskService.prototype.getTaskList = function () {
        //通过用户信息获取任务列表
        return this.baseData.get({ url: '/task' });
    };
    TaskService.prototype.getContractList = function (search) {
        return this.baseData.get({ url: '/schedule/contract-list', params: search }); //合同列表
    };
    TaskService.prototype.delTaskById = function (params) {
        //通过任务id删除任务
        return this.baseData.delete({ url: '/task/task-delete', params: { id: params.id } });
    };
    TaskService.prototype.upDateTask = function (params) {
        //修改任务
        return this.baseData.post({
            url: '/task/task-update',
            params: {
                id: params.id,
                user_id: params.user_id,
                contract_id: params.contract_id,
                date: params.date,
                count: params.count,
            },
        });
    };
    TaskService.prototype.addTask = function (params) {
        //添加任务
        return this.baseData.post({
            url: '/task/task-add',
            params: {
                user_id: params.user_id,
                contract_id: params.contract_id,
                date: params.date,
                count: params.count,
            },
        });
    };
    TaskService.prototype.getTaskById = function (taskId) {
        //通过任务id获取任务详情  sku-列表
        return this.baseData.get({ url: '/task/task-sku-list', params: { task_id: taskId } });
    };
    TaskService.prototype.toInspection = function (params) {
        //验货  （sku）
        return this.baseData.get({
            url: '/task/task-sku-view',
            params: { task_id: params.id, sku: params.sku, contract_id: params.contract_id },
        });
    };
    TaskService.prototype.getAccessbyTaskAndFac = function (params) {
        //验货   （acc）
        return this.baseData.get({
            url: '/task/task-acc-view',
            params: { task_id: params.task_id, contract_id: params.contract_id },
        });
    };
    TaskService.prototype.getPoListByTaskAndFactory = function (params) {
        //po列表
        return this.baseData.get({
            url: '/task/task-factory-contract',
            params: { task_id: params.task_id, factory_group: params.factory_group },
        });
    };
    TaskService.prototype.getSkuListByPoAndTask = function (task_id, contract_id) {
        return this.baseData.get({
            url: '/task/contract-sku-list',
            params: { task_id: task_id, contract_id: contract_id },
        });
    };
    TaskService.prototype.uploadTask = function (data) {
        //上传任务
        return this.baseData.post({ url: '/task/task-add', params: data });
    };
    TaskService.prototype.getScheduleList = function (contract_id) {
        //进度列表
        return this.baseData.get({ url: '/schedule/' + contract_id });
    };
    TaskService.prototype.updateSchedule = function (update) {
        //更新进度
        return this.baseData.post({ url: '/schedule', params: update });
    };
    TaskService.prototype.updateNeedSchedule = function (needScheduleParams) {
        return this.baseData.post({ url: '/schedule/update_schedule-isneed', params: needScheduleParams });
    };
    TaskService.prototype.getNeedSchedule = function (contract_id) {
        return this.baseData.get({ url: '/schedule/schedule-isneed', params: { contract_id: contract_id } });
    };
    TaskService.prototype.getHistoryList = function (contract_id) {
        return this.baseData.get({ url: '/schedule/history', params: { contract_id: contract_id } });
    };
    TaskService.prototype.getHistoryDetailByContract = function (id) {
        return this.baseData.get({ url: '/schedule/history-view', params: { id: id } });
    };
    TaskService.prototype.delayTrack = function (id) {
        return this.baseData.get({ url: '/schedule/delay-track', params: { contract_id: id } });
    };
    TaskService.prototype.recoveryDelay = function (id) {
        return this.baseData.get({ url: '/schedule/set-track', params: { contract_id: id } });
    };
    //////////////////////////////////////////////////////////////////////////////// 冗余api
    TaskService.prototype.getDoneTaskList = function () {
        return this.baseData.get({ url: '/task/inspection-result-task-list' });
    };
    TaskService.prototype.getDoneContractByTask = function (task_id) {
        return this.baseData.get({ url: '/task/inspection-result-contract-list', params: { task_id: task_id } });
    };
    TaskService.prototype.getDoneSkuByTaskAndContract = function (getPoParams) {
        return this.baseData.get({ url: '/task/inspection-result-contract-sku-list', params: getPoParams });
    };
    TaskService.prototype.getDoneSkuDetailByTaCaS = function (params) {
        return this.baseData.get({ url: '/task/sku-view', params: params });
    };
    //////////////////////////////////////////////////////////////////////////////// 冗余api
    TaskService.prototype.resetSchedule = function (contract_id) {
        return this.baseData.get({ url: '/schedule/reset_schedule_isNeed', params: { contract_id: contract_id } });
    };
    TaskService.prototype.multiApplyInspect = function (params) {
        return this.baseData.get({ url: '/schedule/get_sku_list_by_sku', params: params });
    };
    TaskService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
        { type: _base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] }
    ]; };
    TaskService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"]])
    ], TaskService);
    return TaskService;
}());



/***/ }),

/***/ "./src/app/services/user-limit.service.ts":
/*!************************************************!*\
  !*** ./src/app/services/user-limit.service.ts ***!
  \************************************************/
/*! exports provided: UserLimitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserLimitService", function() { return UserLimitService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _base_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");



var UserLimitService = /** @class */ (function () {
    function UserLimitService(baseData) {
        this.baseData = baseData;
        this.permissionList = [];
    }
    UserLimitService.prototype.has = function (permission, parentId) {
        permission = this.filterQueryString(permission);
        this.permissionList = this.baseData.permissionList;
        var some = this.permissionList.some(function (Permission) {
            !Permission.name && (Permission.name = '');
            if (!parentId) {
                return Permission.name === permission && Permission.checked;
            }
            else {
                return (Permission.name === permission &&
                    Permission.parent_id === parentId &&
                    Permission.checked);
            }
        });
        return some;
    };
    UserLimitService.prototype.filterQueryString = function (str) {
        var some = str;
        if (str.indexOf('?') != -1) {
            some = str.substring(0, str.indexOf('?'));
        }
        return some;
    };
    UserLimitService.prototype.hasField = function () {
        //把所有的父级权限拼接 判断
    };
    UserLimitService.ctorParameters = function () { return [
        { type: _base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"] }
    ]; };
    UserLimitService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"]])
    ], UserLimitService);
    return UserLimitService;
}());



/***/ }),

/***/ "./src/app/share/menu.json.ts":
/*!************************************!*\
  !*** ./src/app/share/menu.json.ts ***!
  \************************************/
/*! exports provided: menu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "menu", function() { return menu; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");

var appPages = [
    {
        title: '主页',
        url: '/home',
        type: 'link',
        icon: 'home',
        active: false,
        notModify: true,
    },
    {
        title: '订单跟踪',
        url: '/order-track',
        type: 'link',
        icon: 'analytics',
        active: false,
        limit: 'order-track-main',
        children: [
            {
                title: '订单跟踪',
                url: '/order-track',
                type: 'link',
                limit: 'order-track',
                icon: 'analytics',
                sonIndex: 0,
            },
            {
                title: '历史订单',
                url: '/history-order',
                type: 'link',
                limit: 'history-order',
                icon: 'code-working',
                sonIndex: 1,
            },
            {
                title: '获取合同接口',
                url: '/get-contract',
                limit: 'get-contract',
                type: 'link',
                icon: 'git-merge',
                sonIndex: 2,
            },
        ],
    },
    {
        title: '验货申请列表',
        url: '/apply-inspection',
        type: 'link',
        icon: 'paper',
        limit: 'inspection-application-main',
        active: false,
        children: [
            {
                title: '申请列表',
                url: '/apply-inspection',
                limit: 'apply-inspection',
                type: 'link',
                icon: 'paper',
                sonIndex: 0,
            },
            {
                title: '验货列表',
                url: '/inspection-list',
                type: 'link',
                limit: 'inspection-list',
                icon: 'done-all',
                sonIndex: 1,
            },
        ],
    },
    {
        title: '验货分配',
        url: '/order-grouping',
        type: 'link',
        icon: 'calendar',
        limit: 'inspection-distribution',
        active: false,
        children: [
            {
                title: '创建验货批次',
                url: '/order-grouping',
                type: 'link',
                limit: 'create-inspection-group',
                icon: 'options',
                sonIndex: 0,
            },
            {
                title: '已创建批次列表',
                url: '/distributed-group-list',
                type: 'link',
                limit: 'distributed-group-list',
                icon: 'checkbox-outline',
                sonIndex: 1,
            },
            {
                title: '分配验货',
                url: '/distribute-inspection',
                limit: 'distribute-inspect',
                type: 'link',
                icon: 'calendar',
                sonIndex: 2,
            },
            {
                title: '待审核任务',
                url: '/select-distributed-list',
                limit: 'select-distributed-list',
                type: 'link',
                icon: 'apps',
                sonIndex: 3,
            },
            {
                title: '已确认任务列表',
                url: '/confirmed-task-list',
                limit: 'confirmed-task-list',
                type: 'link',
                icon: 'repeat',
                sonIndex: 4,
            },
        ],
    },
    {
        title: '验货审核',
        url: '/data-compare',
        type: 'link',
        icon: 'git-compare',
        limit: 'inspection-check',
        active: false,
        children: [
            {
                title: '数据对比',
                url: '/data-compare',
                limit: 'inspection-compare',
                type: 'link',
                icon: 'git-compare',
                sonIndex: 5,
            },
        ],
    },
    {
        title: '排柜',
        url: '/arraying-container',
        type: 'link',
        icon: 'phone-landscape',
        limit: 'container-arrangement',
        active: false,
        children: [
            {
                title: '待排柜',
                url: '/stay-arraying-list',
                limit: 'container-arrangement-waiting',
                type: 'link',
                icon: 'phone-landscape',
                sonIndex: 0,
            },
            {
                title: '已排柜',
                url: '/arraying-container',
                limit: 'container-arranged',
                type: 'link',
                icon: 'flag',
                sonIndex: 1,
            },
            {
                title: '待装柜',
                url: '/installed-cabinets',
                limit: 'container-loading',
                type: 'link',
                icon: 'cube',
                sonIndex: 2,
            },
            {
                title: '最终列表',
                url: '/final-cabinets',
                limit: 'final-list-main',
                type: 'link',
                icon: 'checkmark',
                sonIndex: 3,
            },
        ],
    },
    {
        title: '用户管理',
        url: '/develope-list',
        type: 'link',
        limit: 'user-management',
        icon: 'contacts',
        active: false,
        notModify: true,
        children: [
            {
                title: '用户列表',
                url: '/user-list',
                limit: 'user-list-main',
                type: 'link',
                icon: 'person',
                sonIndex: 0,
            },
            {
                title: '修改密码',
                url: '/modify-pwd',
                limit: 'password-change',
                type: 'link',
                icon: 'key',
                sonIndex: 1,
            },
        ],
    },
    {
        title: '权限',
        url: '/permission',
        limit: 'permission',
        type: 'link',
        icon: 'hammer',
        active: false,
        notModify: false,
        children: [
            {
                title: '权限列表',
                url: '/permission',
                limit: 'permissions-list',
                type: 'link',
                icon: 'hammer',
                active: false,
                sonIndex: 0,
            },
            // {
            //     title: '角色管理',
            //     url: '/role',
            //     limit: 'role',
            //     type: 'link',
            //     icon: 'disc',
            //     active: false,
            //     sonIndex: 1,
            // },
            {
                title: '用户组',
                url: '/user-group',
                limit: 'user-group',
                type: 'link',
                icon: 'person',
                sonIndex: 1,
            },
            {
                title: '部门列表',
                url: '/develope-list',
                limit: 'department-list-main',
                type: 'link',
                icon: 'logo-codepen',
                sonIndex: 2,
            },
        ],
    },
    {
        title: '退出',
        type: 'btn',
        icon: 'exit',
        active: false,
    },
];
var menu = appPages;


/***/ }),

/***/ "./src/app/share/share.module.ts":
/*!***************************************!*\
  !*** ./src/app/share/share.module.ts ***!
  \***************************************/
/*! exports provided: ShareModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShareModule", function() { return ShareModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-swiper-wrapper */ "./node_modules/_ngx-swiper-wrapper@8.0.2@ngx-swiper-wrapper/dist/ngx-swiper-wrapper.es5.js");
/* harmony import */ var _directive_directive_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../directive/directive.module */ "./src/app/directive/directive.module.ts");
/* harmony import */ var _component_component_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../component/component.module */ "./src/app/component/component.module.ts");







var DEFAULT_SWIPER_CONFIG = {
    direction: 'horizontal',
    slidesPerView: 'auto',
};
var ShareModule = /** @class */ (function () {
    function ShareModule() {
    }
    ShareModule_1 = ShareModule;
    ShareModule.forRoot = function () {
        return {
            ngModule: ShareModule_1,
            providers: [
                {
                    provide: ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_3__["SWIPER_CONFIG"],
                    useValue: DEFAULT_SWIPER_CONFIG,
                },
            ],
        };
    };
    var ShareModule_1;
    ShareModule = ShareModule_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [],
            imports: [ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_3__["SwiperModule"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _component_component_module__WEBPACK_IMPORTED_MODULE_5__["ComponentModule"], _directive_directive_module__WEBPACK_IMPORTED_MODULE_4__["DirectiveModule"]],
            exports: [ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_3__["SwiperModule"], _component_component_module__WEBPACK_IMPORTED_MODULE_5__["ComponentModule"], _directive_directive_module__WEBPACK_IMPORTED_MODULE_4__["DirectiveModule"]],
        })
    ], ShareModule);
    return ShareModule;
}());



/***/ }),

/***/ "./src/environments/environment.js":
/*!*****************************************!*\
  !*** ./src/environments/environment.js ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

var environment = {
    production: false,
    // apiUrl: 'http://192.168.1.103/api/v1',
    // fileUrlPath: 'http://keyi.xdrlgroup.com',
    // usFileUrl: 'http://192.168.1.103/storage/',
    // origin: 'http://192.168.1.103', 
    apiUrl: 'http://121.196.179.68:8081/api/v1',
    fileUrlPath: 'http://keyi.xdrlgroup.com',
    usFileUrl: 'http://121.196.179.68:8081/',
    origin: 'http://121.196.179.68:8081'
    // apiUrl: 'http://121.196.179.68' + '/api/v1',
    // fileUrlPath: 'http://keyi.xdrlgroup.com',
    // usFileUrl: 'http://121.196.179.68' + '/storage/',
    // origin: 'http://121.196.179.68',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
//# sourceMappingURL=environment.js.map

/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

var environment = {
    production: false,
    // apiUrl: 'http://192.168.1.103/api/v1',
    // fileUrlPath: 'http://keyi.xdrlgroup.com',
    // usFileUrl: 'http://192.168.1.103/storage/',
    // origin: 'http://192.168.1.103', 
    apiUrl: 'http://121.196.179.68:8081/api/v1',
    fileUrlPath: 'http://keyi.xdrlgroup.com',
    usFileUrl: 'http://121.196.179.68:8081/',
    origin: 'http://121.196.179.68:8081'
    // apiUrl: 'http://121.196.179.68' + '/api/v1',
    // fileUrlPath: 'http://keyi.xdrlgroup.com',
    // usFileUrl: 'http://121.196.179.68' + '/storage/',
    // origin: 'http://121.196.179.68',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/_@angular_platform-browser-dynamic@8.2.14@@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])()
    .bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Volumes/Macintosh HD - 数据/web/hawkeye/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map