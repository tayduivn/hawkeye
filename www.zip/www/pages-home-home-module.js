(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"],{

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar color=\"light\">\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <img src=\"../../assets/img/slogan.png\" id=\"slogan\" />\n        <ion-title>\n            <div class=\"title\">\n                <div class=\"text-r\">\n                    <span class=\"text-r mr-40\">欢迎您：{{baseData.userInfo.name}}</span>\n                    <span>现在是：</span>\n                    <span>{{date | async | date:'yyyy年MM月dd日'}}</span>\n                </div>\n            </div>\n        </ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card class=\"welcome-card\">\n        <ion-img [src]=\"src\"></ion-img>\n        <ion-card-header>\n            <ion-card-subtitle>HELLO</ion-card-subtitle>\n            <ion-card-title>欢迎进入鹰眼系统</ion-card-title>\n            {{progress}}\n        </ion-card-header>\n        <ion-card-content> </ion-card-content>\n    </ion-card>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/_@angular_forms@8.2.14@@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");
/* harmony import */ var src_app_guard_login_guard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/guard/login.guard */ "./src/app/guard/login.guard.ts");








var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: 'home',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"],
                        canActivate: [src_app_guard_login_guard__WEBPACK_IMPORTED_MODULE_7__["LoginGuard"]],
                    },
                ]),
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]],
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".welcome-card ion-img {\n  overflow: hidden; }\n\n#slogan {\n  margin-left: 10px;\n  display: block !important;\n  width: auto !important;\n  float: left; }\n\nion-toolbar {\n  display: flex;\n  align-items: center;\n  justify-content: center; }\n\n.title {\n  float: right;\n  margin-top: 25px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center; }\n\n.title > span:first-child {\n    font-size: 0.6rem; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxpQkFBaUI7RUFDakIseUJBQXlCO0VBQ3pCLHNCQUFzQjtFQUN0QixXQUFXLEVBQUE7O0FBRWY7RUFDSSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHVCQUF1QixFQUFBOztBQUUzQjtFQUNJLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsYUFBYTtFQUNiLDhCQUE4QjtFQUM5QixtQkFBbUIsRUFBQTs7QUFMdkI7SUFPUSxpQkFBaUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIud2VsY29tZS1jYXJkIGlvbi1pbWcge1xuICAgIC8vIG1heC1oZWlnaHQ6IDgwdmg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuI3Nsb2dhbiB7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAgIGZsb2F0OiBsZWZ0O1xufVxuaW9uLXRvb2xiYXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cbi50aXRsZSB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICA+IHNwYW46Zmlyc3QtY2hpbGQge1xuICAgICAgICBmb250LXNpemU6IDAuNnJlbTtcbiAgICB9XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/_rxjs@6.5.5@rxjs/_esm5/index.js");






var HomePage = /** @class */ (function () {
    function HomePage(baseData, menu, cd, Router) {
        this.baseData = baseData;
        this.menu = menu;
        this.cd = cd;
        this.Router = Router;
        this.date = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Observable"](function (observer) {
            setInterval(function () {
                var date = new Date();
                observer.next(date);
            }, 1000);
        });
        this.progress = 100;
    }
    HomePage.prototype.ngOnInit = function () {
        var $this = this;
        this.setDiffimgSize();
        window.addEventListener('orientationchange', function (event) {
            $this.setDiffimgSize();
        }, false);
        this.menu.close();
        if (this.baseData.is_first) {
            var menuItem = {
                url: '/create-department',
                sonIndex: 2,
            };
            this.baseData.setMenuExpand(menuItem);
            this.Router.navigate(['/modify-pwd']);
        }
    };
    HomePage.prototype.ionViewDidEnter = function () { };
    HomePage.prototype.setDiffimgSize = function () {
        if (screen.availWidth >= 1080) {
            this.src = "../../../assets/img/home-img/" + this.dayToBeat + "_1595X510.jpg";
        }
        else {
            if (screen.orientation.angle == 0 || screen.orientation.angle == 180) {
                this.src = "../../../assets/img/home-img/" + this.dayToBeat + "_390X311.jpg";
            }
            else
                this.src = "../../../assets/img/home-img/" + this.dayToBeat + "_1254X570.jpg";
        }
    };
    Object.defineProperty(HomePage.prototype, "dayToBeat", {
        get: function () {
            var today = new Date().getDay();
            var some = '';
            switch (today) {
                case 1:
                    some = 'A';
                    break;
                case 2:
                    some = 'B';
                    break;
                case 3:
                    some = 'C';
                    break;
                case 4:
                    some = 'D';
                    break;
                case 5:
                    some = 'E';
                    break;
                default: {
                    some = 'F';
                }
            }
            return some;
        },
        enumerable: true,
        configurable: true
    });
    HomePage.ctorParameters = function () { return [
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
    ]; };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-home',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_base_data_service__WEBPACK_IMPORTED_MODULE_2__["BaseDataService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"],
            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-home-home-module.js.map