(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header color='primary'>\n  <ion-toolbar color=\"primary\">\n    <ion-title text-center>鹰眼</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content padding>\n    <div class=\"logo-box\">\n        <img src=\"../../assets/img/logo.png\" alt=\"\" class=\"logo\" />\n    </div>\n\n    <form [formGroup]=\"registerForm\">\n        <ion-list vertical-center>\n            <ion-item *ngIf=\"status == 'registry'\">\n                <ion-label position=\"floating\">姓名</ion-label>\n                <ion-input [(ngModel)]=\"loginInfo.name\" formControlName=\"username\" clearInput=\"true\"></ion-input>\n            </ion-item>\n            <span *ngIf=\"formErrors.username\" class=\"showerr alert-danger\">{{ formErrors.username }}</span>\n\n            <ion-item>\n                <ion-label position=\"floating\">工号</ion-label>\n                <ion-input\n                    type=\"text\"\n                    [(ngModel)]=\"loginInfo.company_no\"\n                    formControlName=\"company_no\"\n                    clearInput=\"true\"\n                ></ion-input>\n            </ion-item>\n            <span *ngIf=\"formErrors.company_no\" class=\"showerr alert-danger\">{{ formErrors.company_no }}</span>\n\n            <ion-item>\n                <ion-label position=\"floating\">密码</ion-label>\n                <ion-input\n                    type=\"password\"\n                    [(ngModel)]=\"loginInfo.password\"\n                    formControlName=\"password\"\n                    clearInput=\"true\"\n                    (keyup)=\"projectNameChanged($event)\"\n                ></ion-input>\n            </ion-item>\n            <span *ngIf=\"formErrors.password\" class=\"showerr alert-danger\">{{ formErrors.password }}</span>\n\n            <ion-item *ngIf=\"status == 'registry'\">\n                <ion-label position=\"floating\">确认密码</ion-label>\n                <ion-input\n                    type=\"password\"\n                    [(ngModel)]=\"loginInfo.password_confirmation\"\n                    formControlName=\"password_confirmation\"\n                    clearInput=\"true\"\n                ></ion-input>\n            </ion-item>\n            <span *ngIf=\"formErrors.password_confirmation && status == 'registry'\" class=\"showerr alert-danger\"\n                >{{ formErrors.password_confirmation }}</span\n            >\n        </ion-list>\n\n        <div class=\"mt-30\">\n            <ion-button\n                events=\"ionBur\"\n                type=\"submit\"\n                color=\"secondary\"\n                [disabled]=\"!registerForm.value.company_no \n                       || formErrors.company_no \n                       || !registerForm.value.password\"\n                expand=\"block\"\n                *ngIf=\"status == 'login'\"\n                (click)=\"doLogin()\"\n                >登录\n            </ion-button>\n            <ion-button\n                *ngIf=\"status == 'registry'\"\n                color=\"secondary\"\n                [disabled]=\"!registerForm.value.company_no \n                            || !registerForm.value.username \n                            || !registerForm.value.password \n                            || formErrors.password_confirmation\n                            || formErrors.username\n                            || formErrors.company_no\n                            || formErrors.password\n                            || !registerForm.value.password_confirmation\"\n                type=\"submit\"\n                expand=\"block\"\n                (click)=\"doRegistry()\"\n            >\n                注册\n            </ion-button>\n            <ion-button fill=\"clear\" *ngIf=\"status == 'login'\" color=\"light\" (click)=\"tabStatus('registry')\"\n                >注册账号</ion-button\n            >\n            <ion-button fill=\"clear\" *ngIf=\"status != 'login'\" color=\"light\" (click)=\"tabStatus('login')\"\n                >去登录</ion-button\n            >\n        </div>\n    </form>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/login/login.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/_@angular_forms@8.2.14@@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/_@ionic_angular@4.11.13@@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/pages/login/login.page.ts");







var routes = [
    {
        path: 'login',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"],
    },
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ReactiveFormsModule"]],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]],
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/pages/login/login.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: transparent;\n  z-index: 2; }\n\n.logo-box {\n  margin-top: 3rem;\n  width: 100%;\n  text-align: center; }\n\n.logo-box .logo {\n    width: 5rem;\n    display: inline-block;\n    margin-bottom: 0.5rem; }\n\n.showerr {\n  text-align: left;\n  font-size: 12px;\n  color: #f00;\n  padding-left: 15px;\n  background: 0; }\n\n.custom-loading {\n  color: #f00; }\n\nform {\n  width: 60%;\n  margin: 0 auto; }\n\nion-list {\n  background: transparent; }\n\nion-item {\n  --background: transparent;\n  color: #f4f5f8; }\n\nion-input input {\n  color: #f00; }\n\n@media screen and (min-width: 800px) {\n  .logo-box {\n    margin-top: 1rem; }\n  form {\n    width: 300px; } }\n\n@media screen and (min-width: 1080px) {\n  .logo-box {\n    margin-top: 6rem; }\n  form {\n    width: 300px; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS9zcmMvYXBwL3BhZ2VzL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUFhO0VBQ2IsVUFBVSxFQUFBOztBQUdkO0VBQ0ksZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxrQkFBa0IsRUFBQTs7QUFIdEI7SUFLUSxXQUFXO0lBQ1gscUJBQXFCO0lBQ3JCLHFCQUFxQixFQUFBOztBQUk3QjtFQUNJLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixhQUFhLEVBQUE7O0FBRWpCO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksVUFBVTtFQUNWLGNBQWMsRUFBQTs7QUFHbEI7RUFDSSx1QkFBdUIsRUFBQTs7QUFFM0I7RUFDSSx5QkFBYTtFQUNiLGNBQWMsRUFBQTs7QUFHbEI7RUFHUSxXQUFXLEVBQUE7O0FBSW5CO0VBQ0k7SUFDSSxnQkFBZ0IsRUFBQTtFQUVwQjtJQUNJLFlBQVksRUFBQSxFQUNmOztBQUdMO0VBQ0k7SUFDSSxnQkFBZ0IsRUFBQTtFQUVwQjtJQUNJLFlBQVksRUFBQSxFQUNmIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgei1pbmRleDogMjtcbn1cblxuLmxvZ28tYm94IHtcbiAgICBtYXJnaW4tdG9wOiAzcmVtO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAubG9nbyB7XG4gICAgICAgIHdpZHRoOiA1cmVtO1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDAuNXJlbTtcbiAgICB9XG59XG5cbi5zaG93ZXJyIHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBjb2xvcjogI2YwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XG4gICAgYmFja2dyb3VuZDogMDtcbn1cbi5jdXN0b20tbG9hZGluZyB7XG4gICAgY29sb3I6ICNmMDA7XG59XG5cbmZvcm0ge1xuICAgIHdpZHRoOiA2MCU7XG4gICAgbWFyZ2luOiAwIGF1dG87XG59XG5cbmlvbi1saXN0IHtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1pdGVtIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIGNvbG9yOiAjZjRmNWY4O1xufVxuXG5pb24taW5wdXQge1xuICAgIC8vIC0tY29sb3I6I2YwMDtcbiAgICBpbnB1dCB7XG4gICAgICAgIGNvbG9yOiAjZjAwO1xuICAgIH1cbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogODAwcHgpIHtcbiAgICAubG9nby1ib3gge1xuICAgICAgICBtYXJnaW4tdG9wOiAxcmVtO1xuICAgIH1cbiAgICBmb3JtIHtcbiAgICAgICAgd2lkdGg6IDMwMHB4O1xuICAgIH1cbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTA4MHB4KSB7XG4gICAgLmxvZ28tYm94IHtcbiAgICAgICAgbWFyZ2luLXRvcDogNnJlbTtcbiAgICB9XG4gICAgZm9ybSB7XG4gICAgICAgIHdpZHRoOiAzMDBweDtcbiAgICB9XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/pages/login/login.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage, loginInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginInfo", function() { return loginInfo; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/_tslib@2.0.3@tslib/tslib.es6.js");
/* harmony import */ var _services_base_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/base-data.service */ "./src/app/services/base-data.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/_@angular_core@8.2.14@@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/_@angular_common@8.2.14@@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/_@angular_router@8.2.14@@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/_@angular_forms@8.2.14@@angular/forms/fesm5/forms.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var src_app_services_menu_permission_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/menu-permission.service */ "./src/app/services/menu-permission.service.ts");








var LoginPage = /** @class */ (function () {
    function LoginPage(http, baseData, Router, fb, el, effectCtrl, menuPermission) {
        this.http = http;
        this.baseData = baseData;
        this.Router = Router;
        this.fb = fb;
        this.el = el;
        this.effectCtrl = effectCtrl;
        this.menuPermission = menuPermission;
        this.status = 'login';
        this.loginInfo = new loginInfo('', '', '', '');
        // 表单验证不通过时显示的错误消息
        this.formErrors = {
            username: '',
            company_no: '',
            password: '',
            password_confirmation: '',
        };
        // 为每一项表单验证添加说明文字
        this.validationMessage = {
            username: {
                minlength: '用户名长度最少为2个字符',
                maxlength: '用户名长度最多为10个字符',
                required: '请填写用户名',
            },
            company_no: {
                required: '请填写工号',
                pattern: '不是工号格式',
            },
            password: {
                required: '请输入密码',
            },
            password_confirmation: {
                required: '请再次输入密码',
                atypism: '两次输入不一致',
                notPwd: '请先输入密码',
            },
        };
    }
    // 构建表单方法
    LoginPage.prototype.buildForm = function () {
        var _this = this;
        // 通过 formBuilder构建表单
        this.registerForm = this.fb.group({
            /* 为 username 添加3项验证规则：
             * 1.必填， 2.最大长度为10， 3.最小长度为3， 4.不能以下划线开头， 5.只能包含数字、字母、下划线
             * 其中第一个空字符串参数为表单的默认值
             */
            username: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(2)]],
            company_no: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern(/['X']['D'][0-9][0-9][0-9]/g)]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]],
            password_confirmation: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]],
        });
        // 每次表单数据发生变化的时候更新错误信息
        this.registerForm.valueChanges.subscribe(function (data) {
            _this.onValueChanged(data);
            // console.log(data);
            if (data.password_confirmation && !data.password) {
                _this.formErrors['password_confirmation'] += _this.validationMessage['password_confirmation']['notPwd'];
            }
            if (data.password_confirmation && data.password && data.password_confirmation !== data.password) {
                _this.formErrors['password_confirmation'] += _this.validationMessage['password_confirmation']['atypism'];
            }
        });
        // 初始化错误信息
        this.onValueChanged();
    };
    // 每次数据发生改变时触发此方法
    LoginPage.prototype.onValueChanged = function (data) {
        // 如果表单不存在则返回
        if (!this.registerForm)
            return;
        // 获取当前的表单
        var form = this.registerForm;
        // 遍历错误消息对象
        for (var field in this.formErrors) {
            // 清空当前的错误消息
            this.formErrors[field] = '';
            // 获取当前表单的控件
            var control = form.get(field);
            // 当前表单存在此空间控件 && 此控件没有被修改 && 此控件验证不通过
            if (control && control.dirty && !control.valid) {
                // 获取验证不通过的控件名，为了获取更详细的不通过信息
                var messages = this.validationMessage[field];
                // 遍历当前控件的错误对象，获取到验证不通过的属性
                for (var key in control.errors) {
                    // 把所有验证不通过项的说明文字拼接成错误消息
                    this.formErrors[field] += messages[key] + '\n';
                }
            }
        }
    };
    LoginPage.prototype.ngOnInit = function () {
        this.buildForm();
        var userInfo = sessionStorage.getItem('USERINFO');
        if (userInfo) {
            sessionStorage.removeItem('USERINFO');
            sessionStorage.removeItem('PERMISSION');
        }
    };
    LoginPage.prototype.ngAfterViewInit = function () {
        this.rememberPwdBug();
    };
    LoginPage.prototype.rememberPwdBug = function () {
        var _this = this;
        setTimeout(function () {
            var inputGroup = _this.el.nativeElement.querySelectorAll('ion-input');
            inputGroup.forEach(function (element) {
                element.children[0].style = '';
            });
        }, 2000);
    };
    LoginPage.prototype.doLogin = function () {
        var _this = this;
        this.effectCtrl.showLoad({ spinner: null, duration: 0, message: '正在登陆……', translucent: false }).then(function () {
            var params = JSON.parse(JSON.stringify(_this.loginInfo));
            delete params.name;
            delete params.password_confirmation;
            _this.baseData.post({ url: '/login', params: params }, true).subscribe(function (data) {
                _this.effectCtrl.loadCtrl.dismiss();
                //TODO  BUG
                var base = data;
                if (base.status == 0) {
                    _this.effectCtrl.showAlert({
                        message: '登陆失败！',
                        header: '提示',
                        buttons: ['确定'],
                        subHeader: '',
                    });
                }
                else {
                    _this.baseData.userInfo = base.data;
                    var fn = _this.flatTreePermissions();
                    _this.baseData.permissionList = JSON.parse(JSON.stringify(fn(base.permission)));
                    sessionStorage.setItem('USERINFO', JSON.stringify(_this.baseData.userInfo));
                    sessionStorage.setItem('PERMISSION', JSON.stringify(_this.baseData.permissionList));
                    fn = null;
                    _this.baseData.permissionList.forEach(function (element) {
                        if (element.type === 'menu')
                            _this.menuPermission.permissions.push(element);
                    });
                    //判断是否是第一次登录
                    _this.baseData.is_first = base.is_first;
                    //判断是否是验货人
                    _this.baseData.is_Inspector = base.is_Inspector;
                    _this.Router.navigate(['/home']);
                    _this.baseData.setMenuChange(true);
                }
            });
        });
    };
    /**
     * 将Tree结构的数据扁平化
     */
    LoginPage.prototype.flatTreePermissions = function () {
        var value = [];
        return function flat(permissions) {
            permissions.forEach(function (permission) {
                value.push(permission);
                if (permission.children && permission.children.length)
                    flat(permission.children);
            });
            return value;
        };
    };
    LoginPage.prototype.doRegistry = function () {
        var _this = this;
        this.effectCtrl.showLoad({ spinner: null, duration: 0, message: '正在注册……', translucent: false }).then(function () {
            var params = JSON.parse(JSON.stringify(_this.loginInfo));
            delete params.password_confirmation;
            _this.baseData.post({ url: '/register', params: params }, true).subscribe(function (data) {
                _this.baseData.printDebug && console.log(data);
                _this.effectCtrl.loadCtrl.dismiss();
                var base = data;
                if (base.status == 'fail') {
                    _this.effectCtrl.showAlert({
                        message: '注册失败',
                        header: '提示',
                        buttons: ['确定'],
                        subHeader: '',
                    });
                }
                else {
                    _this.effectCtrl.showAlert({
                        message: '注册成功',
                        header: '提示',
                        backdropDismiss: false,
                        buttons: [
                            {
                                text: '确定',
                                handler: function () {
                                    _this.status = 'login';
                                },
                            },
                        ],
                    });
                }
            });
        });
    };
    LoginPage.prototype.tabStatus = function (status) {
        this.status = status;
    };
    LoginPage.prototype.ionViewCanLeave = function () {
        this.effectCtrl.clearEffectCtrl();
        console.log('ionViewCanLeave');
    };
    LoginPage.prototype.projectNameChanged = function (e) {
        var keycode = window.event ? e.keyCode : e.which;
        if (keycode == 13) {
            //回车键
            this.doLogin();
        }
        if (keycode == 27) {
        }
    };
    LoginPage.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _services_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"] },
        { type: src_app_services_menu_permission_service__WEBPACK_IMPORTED_MODULE_7__["MenuPermissionService"] }
    ]; };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-login',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/_raw-loader@3.1.0@raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./login.page.scss */ "./src/app/pages/login/login.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _services_base_data_service__WEBPACK_IMPORTED_MODULE_1__["BaseDataService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"],
            src_app_services_menu_permission_service__WEBPACK_IMPORTED_MODULE_7__["MenuPermissionService"]])
    ], LoginPage);
    return LoginPage;
}());

var loginInfo = /** @class */ (function () {
    function loginInfo(name, company_no, password, password_confirmation) {
        this.name = name;
        this.company_no = company_no;
        this.password = password;
        this.password_confirmation = password_confirmation;
    }
    return loginInfo;
}());



/***/ })

}]);
//# sourceMappingURL=pages-login-login-module.js.map